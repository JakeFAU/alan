# Investigation authoring observations

The implemented bounded workload fits the existing public authoring basis. No runtime, scheduler, reducer, store, schema limit, operation version or public authoring API changed. `examples/investigation` imports only public packages and the existing public evidence example. The CLI alone uses the pre-existing `internal/boundary.FromEnvironment` observational qualification hook, exactly as `alan-evidence` does; it adds no program policy or new boundary mechanism.

## Flat evidence and retained candidates

Smallest workload: synthesize from two helper records, retain those records, then synthesize from four helper records after one revision. `schema.Record` has scalar fields, not variable collections. The selected solution is finite author-time expansion into `e1_` through `e4_` fields. Each slot has the existing evidence helper's seven fields. The result has 37 fields, and the outer report has 38, below the unchanged 128-field limit. Non-answer slots retain their explicit helper disposition; never-used slots are `unused` with typed empty fields. No JSON-in-string collection or new schema type is needed.

Candidate citation provenance is not delegated to a model: the coordinator returns the validated helper slots themselves. Semantic support and relevance remain independent grading questions. An initial candidate uses e1/e2; a revised candidate may use all four slots without discarding earlier facts.

## Model input formatting

Smallest workload: transmit a question plus two evidence records and later a prior candidate/review reason to a model. There is no authored string interpolation operation. The existing OpenAI adapter already serializes ordinary scalar records into canonical JSON model input. The application supplies declared fields plus a retained `instructions` string. No formatting opcode or adapter policy was added.

## Finite revision and separate participants

Smallest workload: receive `revise`, check a persisted limit, send two new requests, then reject another `revise`. The coordinator uses forward branches over two author-time-expanded rounds. Four separately provisioned one-shot evidence helpers provide fresh effect identities. The ordinary reviewer has two finite receive/request/reply sections, with distinct pending identity variables. Both helper messages are authored before either receive. A public test leaves the first helper unknown while the second finishes, showing independent progress.

The fixed participant ceilings are coordinator 3 model requests, reviewer 2, and each of four helpers 2 model/1 lookup. `MaxRevisions=0` prevents the second pair from receiving work. Ordinary request updates persist spent counters atomically with effect intent; no hierarchy-wide runtime budget was introduced.

## Definite assignment at a budget exit

Smallest input: an authored reviewer branches to its reply label on exhausted budget before awaiting a model response, while the reply contains model-selected subquestions. The first compiling test failed with `steps/8:send:coordinator: value "subquestion1" is not definitely available`. This is a useful authoring check, not a missing runtime capability. The selected solution initializes all public reply fields to typed defaults, then assigns the explicit budget/invalid decision and reason on those paths. No compiler relaxation was required.

## Public composition with useful outer policy

The outer report receives the unchanged investigation result through its port. Ordinary `Set`/`IfEqual` steps derive `report_outcome=publish` only for an accepted answer and `needs_attention` otherwise. It forwards every investigation field unchanged plus that routing field. It accesses no child projection, SQL or instructions and adds no effect/model cost. A test first failed on the forwarding-only wrapper, then passed with distinct accepted/stopped outcomes.

## Inspection and source retention

The example needs configuration, counters, pending identities, results and a consistent operator snapshot. Existing `runtime.Inspect` supplies one public snapshot; the application decodes its public rows and derives every summary from that snapshot, following the Phase 1E evidence example's validated pattern. This duplicates a small public-row decoding helper rather than adding a convenience API to the runtime.

The CLI snapshots each manifest document independently, verifies its SHA-256 and byte length, and retains the original bytes/ID. Manifest paths are relative to the directory containing `corpus/`. `effects.Asset.Version` remains the content hash required by the existing contract; editorial manifest version `1` is not substituted for it. Reopen/replay do not read the manifest or source files. The baseline option provisions the unchanged public `evidence.Provision` with exactly the same assets.
