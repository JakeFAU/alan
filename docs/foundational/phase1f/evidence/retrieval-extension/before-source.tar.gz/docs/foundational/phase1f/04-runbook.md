# Investigation application runbook

This application reuses the current single-host executor, immutable programs, static grants and direct Responses/lookup adapters. Requirements remain Go1.27.3, CGO and a C compiler. There is no second scheduler or provider-owned workflow. One active executor owns a store.

## Start, inspect and reopen

Choose an available model and authorize its spend before running. Init, inspection and replay do not contact a model. The example below uses the model explicitly selected for this qualification; it is a mutable provider alias, not a pinned provider implementation.

```sh
go build -buildvcs=false -o /tmp/alan-investigate ./cmd/alan-investigate
alan_investigation_dir=$(mktemp -d)
/tmp/alan-investigate init --db "$alan_investigation_dir/run.sqlite"   --question 'For Cedar agent 3.2 production Linux deployments in window C17, which of kernels 6.1 and 5.15 is supported, and what exact trigger and target version govern rollback?'   --corpus-manifest docs/foundational/phase1f/evaluation/corpus/manifest.json   --model gpt-6.1-sol --nested --max-revisions 1   --max-output-tokens 4096 --max-response-bytes 65536 --request-timeout 120s
# OPENAI_API_KEY must be in the environment for these paid commands.
/tmp/alan-investigate run --db "$alan_investigation_dir/run.sqlite"
/tmp/alan-investigate inspect --db "$alan_investigation_dir/run.sqlite"
/tmp/alan-investigate recover --db "$alan_investigation_dir/run.sqlite"
env -u OPENAI_API_KEY /tmp/alan-investigate replay --db "$alan_investigation_dir/run.sqlite"
```

Init refuses an existing store. Omit `--nested` for a direct ordinary caller; nested adds a report participant that derives `publish` or `needs_attention` from the investigation's public disposition. `--max-revisions 0` disables the optional round. `--baseline` instead provisions the unchanged Phase1E evidence helper with the identical corpus assets and a two-model/one-lookup ceiling; baseline and nested are mutually exclusive. The manifest snapshots each exact document separately and checks its SHA256 and byte length. Its paths are relative to the evaluation root containing `corpus/`. Runtime citation version is the content hash. Reopen never reads the original corpus paths or recompiles application source.

The investigation can make up to13 model requests and four lookups; the no-revision path at most seven and two. These are ordinary application ceilings. CLI token/response/time settings bound individual transports; they are not a dollar billing cap. The qualification controller below supplies the additional local spending gate used for measured runs. A provider request is billable even if its reply is lost.

## Spending-controlled qualification

`tools/live_control.py` wraps an already initialized store and the CLI through existing pre-transport observation barriers. Use one ledger across all authorized runs. A new user experiment can create a ledger with its explicitly authorized cap; the shipped controller currently requires the $10 profile used here. Do not reset the ledger or repeat an unknown run to evade its limit. It accepts only the selected official model/endpoint and at most4,096 output tokens, and refuses a store with prior adapter attempts.

```sh
printf '%s\n' '{"maximum_total_usd":10,"reservations":[]}' > "$alan_investigation_dir/budget.json"
python3 docs/foundational/phase1f/tools/live_control.py   --binary /tmp/alan-investigate --db "$alan_investigation_dir/run.sqlite"   --ledger "$alan_investigation_dir/budget.json" --run-id my-authorized-run   --output "$alan_investigation_dir/evidence"
```

Run this in place of the direct `run` command, before any attempt. The script reserves a conservative allowance durably before releasing each request, checks correlated source/run/epoch/sequence/attempt records, retains provider usage and unknown-cost reservations, then verifies replay without a credential or network access. It uses macOS sandbox-exec for the measured network-denial control; other platforms need an equivalent controller. The [run procedure](evaluation-run-plan.md) states the pricing/tokenization assumptions, instrumentation overhead and limits. It is a qualification tool, not a billing service. Responses with inconsistent usage cannot release an allowance.

## Reading outcomes

`View.Result` is the public caller result, or null if the obligation remains pending. `answer` is the delivered text; `initial_candidate` and `final_candidate` are diagnostic candidates. A stopped/rejected candidate is not an accepted answer. `disposition`, `review_decision`, `review_reason`, initial review fields and `revision_count` expose ordinary policy. Evidence slots e1/e2 come from the initial round; e3/e4 from the optional revision. Only helper slots marked answer contain mechanically checked source provenance. The application's reviewer is not a factual oracle; independent grading evaluates support and citation coverage separately.

`ModelRequests` and `LookupRequests` count committed intents. `Attempts` counts authorized reservations; neither is a billing count. `Results` preserves available usage and provider identifiers. `Unknown` identifies attempts without recorded outcomes; these are not automatically resent and can prevent completion. `Runs` and the full `Snapshot` expose subject/generation/epoch, program identity, retained counters, pending request IDs, histories and ledgers from one read snapshot. A successful process exit can be a quiescent wait, an explicit stop or a failed logical outcome. Inspect the records.

Physical restart renews activation authority while preserving the same logical executions, counters, pending identities and consumed observations. It creates no revision by itself. A new revision requires the ordinary coordinator to consume a valid review requesting it with budget remaining. Prior evidence remains available to the second synthesis. Unused static helpers or the reviewer's second receive may remain waiting; no child cleanup or eventual-completion guarantee is supplied.

## Reuse from a separate Go module

`examples/investigation.New(name, caller, obligation, Budgets{MaxRevisions:1})` returns `Instances author.Application` and `Port author.Port`. Merge its instances with an ordinary caller definition that sends `RequestSchema()` and receives `ResultSchema()`. `Report` wraps the identical component and exposes `ReportResultSchema()` with one additional routing field. Callers need no internal participant name, raw instruction, SQL or child-state access. The external-consumer test is a complete compiling example; the package tests run both topologies.

```sh
GOTOOLCHAIN=local go test -count=1 ./examples/investigation ./cmd/alan-investigate
GOTOOLCHAIN=local go test -count=1 -tags integration ./internal/investigationtest
```

These commands use controlled providers, not paid inference. Process qualifications use a separate provider process, acknowledged persistence barriers and actual SIGKILL; consult the qualification report for supported cuts and limitations. Focused race instrumentation can be substantially slower than ordinary tests. Historical Phase1E reproduction is separate from current-source regression and from live answer quality.
