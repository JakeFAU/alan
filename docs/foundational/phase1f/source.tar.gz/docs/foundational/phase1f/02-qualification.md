# Phase 1F qualification

Publication is in progress. Final verification, heldout measurements and whole-branch review are recorded below before this increment is committed. Earlier evidence remains immutable.

## What is being qualified

The public `investigation.New` component plans two evidence subquestions, sends both before waiting, synthesizes their public results, obtains an ordinary review, and either delivers a result, stops explicitly, or authorizes one revision. The same component runs directly and behind `Report`, which adds ordinary publication routing. The finite ceiling is 13 model requests and four lookups. No interpreter, scheduler, lifecycle authority, SQLite schema or dependency changes are part of this phase. Optional exact-span exclusions are a versioned lookup input and a public helper request, not a policy opcode.

The useful-application claim is evaluated separately from execution correctness. A model review can approve an incomplete answer. Exact citation bytes establish provenance, not entailment. A stopped diagnostic candidate is never substituted for an absent delivered answer. The frozen rubric and independent grading determine quality; the application reviewer does not.

## Baseline and source identity

The verified merged base is `e2157a8fb2837ea3d7d0232683072182a0ee832b`, whose 133 contributing files match published Phase1E source `8f95bda980504caec8c29cbe196297f61abafe7941d11ddc51effc19c9321caa`. [Historical reproduction](evidence/baseline/report.md) ran the original complete archive in isolation: 462 default and 655 integration/race pass events, both vets, formatting, dependency verification and seven comparator controls. Its exact 15/20/32 finite research payloads and six declared conformance projections reproduce. Raw process ledgers contain ephemeral data and are not asserted byte-equal.

Current-source regression is a separate comparison. `source-manifest.json` identifies contributing source and fixture bytes; `source.tar.gz` supplies them and the pinned SQLite dependency proxy. `archive-manifest.json` identifies all archive members. Generated evidence and reports are retained alongside the archive to avoid recursive self-hashing. A working-tree digest does not claim that the pre-publication Git HEAD already contained those files. The original source and failed inputs for each amendment remain available.

## Live gate and experimental design

The old Phase1E gate is now [completed with actual OpenAI responses](evidence/live-phase1e/report.md): explicit `gpt-6.1-sol`, authorized project credential, $10 total qualification limit, two model requests and one lookup, 401 input/265 output tokens and $0.003452 estimated token cost. The supported WAL answer cites exact retained bytes. Credential-free, network-denied replay passed without changing inspection. The original Phase1E NOT RUN report is preserved as historical evidence.

The frozen evaluation contains eight documents/25 lines and four development plus four heldout questions, covering supported answers, ambiguity, missing evidence and contradiction. Each asks two aspects. Model aliases can change; provider IDs, returned model/tier, usage, immutable requests and responses are retained. Both systems receive identical question/corpus bytes and model settings, with alternating execution order. The simple helper gets at most two model/one lookup requests; investigation gets up to thirteen/four. This is not an equal-compute comparison. Instrumented latency includes spending barriers and executor work.

See [the frozen run procedure](evaluation-run-plan.md) for the 4,096-token/65,536-byte/120-second per-request profile and conservative spending assumptions. The local controller reserves before releasing the existing pre-transport barrier; it does not decide program policy. Missing or inconsistent usage retains the allowance. Prices and tokenization margins are disclosed assumptions, not an invoice guarantee or provider-side billing cap. Unknown work is not rerun.

Three development versions are retained: initial composition, a three-prompt correction, and a public exclusion-input extension. Each is measured separately; development-informed results are not blind evidence. The heldout implementation, prompts, configuration and order are frozen before publication of its previously committed bytes. Related synthetic templates and four heldout cases support only narrow descriptive observations.

## Execution and composition evidence

| Claim | Evidence | Kind and limit |
| --- | --- | --- |
| Same investigation can run alone or nested | External-module consumer, public port/schema checks and direct/nested controlled outcomes | Successful bounded reachability and interface checks; no arbitrary-depth equivalence theorem |
| An independent sibling progresses during a held provider call | Actual CLI helper2 terminal commit while helper1's provider has durably applied and withheld its response; both PIDs alive, correlated in-flight authorization | One causally synchronized schedule, not fairness |
| Review/revision state survives death | SIGKILL after first and second review result recording, before settlement; reopen consumes retained results, preserves budget/pending IDs, completes ordinary nested publication | Two selected crash cuts; source files removed, actual successor ordinary computation |
| Unknown provider outcome cannot create a revision | Held request remains the same unknown intent after restart; completed sibling and budget remain, no additional provider contact | Explicit blocked completion, not eventual recovery |
| Older messages cannot satisfy newer review work | Actual redelivery of consumed helper/review messages during pending review2 retains original bindings and all projections | Supported duplicate message settlement; arbitrary late external candidate injection is not exposed or tested |
| Replay has no dispatch authority | Registry-free replay with key/provider unavailable, every participant/projection checked, complete inspection and provider ledger unchanged | Historical consistency plus independent transport evidence; not independent reducer equivalence |
| Monitors detect relevant faults | Nine process controls, including historical acknowledgment substitution and an actual extra HTTP dispatch through a faulty replay wrapper | Unchanged monitors reject original validly framed faults; no claim every defect is detected |
| Prior semantics remain reference evidence | Exact finite research payload comparison and six declared public/model conformance streams | Existing bounded scenarios, not new exhaustive composition searches |

The [process report](evidence/task3/report.md), [source/log manifest](evidence/task3/manifest.json) and [independent review](evidence/task3/review.md) retain full configurations, provider corpus, filters, actual epochs/sequences, operations, PID exits, source deletion, raw logs and counterexamples. Three selected scenarios contain three CLI SIGKILLs per suite. Race runs instrument both children. A second-review interruption occurs after revised synthesis; it is not described as a crash inside an earlier revision helper. No sleep establishes the causal cut.

## Retained failures and limits

The original fixture used editorial version `1` where assets require content SHA-256. A custodian corrected 42 version references and retained all original bytes; corpus/questions and semantic gold did not change. Correction occurred during implementation but before evaluation output. Earlier attestation wording saying pre-implementation is too strong; the original freeze preceded implementation, while the correction did not. This timing clarification does not rewrite frozen records.

The spending controller's first usage reconciler could release an allowance for malformed token totals. Independent review supplied the original negative/inconsistent inputs; the corrected reconciler and unchanged controls retain reservation. Two process-harness probes incorrectly treated current activation epochs as immutable across reopen. Original failures remain; current authority may advance while historical authorization stays fixed. Neither correction changed runtime behavior or semantic bounds.

Initial development exposed a validly sized but overlong lexical query, repeated header retrieval, and confusion between missing retrieved evidence and corpus-wide absence. The original prompts, outputs and independent judgments remain. Prompt clarification alone did not solve repeated retrieval. The optional exclusion protocol removes only explicitly named exact spans and guarantees neither relevance nor complete evidence. No failed run or valid input is discarded.

One active executor per store, trusted adapters, static provisioning/grants, one PC per run, immutable retained artifacts and local process-crash storage assumptions remain. No distributed ownership, dynamic spawning, business deduplication, migration, provider catalogue expansion, stable SDK, UI, power-loss test, unbounded fairness or general semantic equivalence is claimed. A fresh authorized revision is distinct from repeating an uncertain operation. Dormant static helpers may remain waiting. No production-readiness claim follows from review approval.
