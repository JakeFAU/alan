package main
import (
 "context"
 "encoding/json"
 "fmt"
 "io"
 "net/http"
 "net/http/httptest"
 "strings"
 "time"
 "github.com/JakeFAU/alan/adapters/openai"
 "github.com/JakeFAU/alan/effects"
 "github.com/JakeFAU/alan/schema"
)
func main() {
 const secret="review-fake-secret"
 escaped:=`review-fake-\u0073ecret`
 nested:=`"`+escaped+`"`
 for i:=0;i<7;i++ { b,_:=json.Marshal(nested); nested=string(b) }
 valid:=`{"status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"{\"answer\":\"ok\"}"}]}]}`
 cases:=[]struct{name,body,header string; status int}{
 {"control",valid,"normal-id",200},
 {"escaped_header",valid,escaped,200},
 {"nested_json_credential",`{"error":`+nested+`}`,"normal-id",401},
 {"case_conflicting_status",strings.Replace(valid,`"status":"completed"`,`"status":"incomplete","Status":"completed"`,1),"normal-id",200},
 }
 in,_:=(schema.Record{"instructions":{Kind:"string",MaxBytes:100},"input":{Kind:"string",MaxBytes:100}}).Retain()
 out,_:=(schema.Record{"answer":{Kind:"string",MaxBytes:100}}).Retain()
 for _,tc:=range cases {
 contacts:=0
 s:=httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){contacts++;io.Copy(io.Discard,r.Body);w.Header().Set("x-request-id",tc.header);w.WriteHeader(tc.status);io.WriteString(w,tc.body)}))
 a,e:=openai.New(openai.Config{APIKey:secret,Model:"explicit-test-model",Endpoint:s.URL,MaxOutputTokens:20,MaxResponseBytes:65536});if e!=nil{panic(e)}
 p,e:=a.Prepare(effects.Request{ID:"local",Key:"namespaced-key",Capability:"model",Effect:"answer",Input:in,Output:out,Payload:map[string]schema.Value{"instructions":schema.Text("Answer briefly"),"input":schema.Text("Question")}});if e!=nil{panic(e)}
 ctx,cancel:=context.WithTimeout(context.Background(),3*time.Second)
 c:=a.Execute(ctx,p);cancel();s.Close()
 headerDecoded:="";_ = json.Unmarshal([]byte(`"`+c.RequestID+`"`),&headerDecoded)
 var raw map[string]json.RawMessage; _=json.Unmarshal([]byte(c.Response),&raw)
 recoverable:=string(raw["error"])
 layers:=0
 for layers<12 {var decoded string;if json.Unmarshal([]byte(recoverable),&decoded)!=nil {break};recoverable=decoded;layers++}
 result:=map[string]any{"case":tc.name,"input_body":tc.body,"input_header":tc.header,"candidate":c,"contacts":contacts,"header_decodes_to_credential":headerDecoded==secret,"nested_decodes_to_credential":recoverable==secret,"decoded_layers":layers}
 b,_:=json.Marshal(result);fmt.Println(string(b))
 }
}
