package main
import (
 "context"
 "database/sql"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "github.com/JakeFAU/alan/author"
 "github.com/JakeFAU/alan/effects"
 runtime "github.com/JakeFAU/alan/runtime"
 "github.com/JakeFAU/alan/schema"
)
type adapter struct{}
func (adapter) Prepare(r effects.Request)(effects.Prepared,error){return effects.Prepared{Request:r,Protocol:"review/v1",MaxResponseBytes:4096},nil}
func (adapter) Execute(_ context.Context,p effects.Prepared)effects.Candidate{return effects.Candidate{ID:p.Request.ID,Key:p.Request.Key,Disposition:"validated",Payload:map[string]schema.Value{"answer":schema.Text("ok")}}}
func check(e error){if e!=nil{panic(e)}}
func main(){
 ctx:=context.Background()
 root:=".superpowers/sdd/00-plan/evidence/task-3/independent-review"
 path:=filepath.Join(root,"ledger-original.db")
 a,e:=author.Compile(author.Definition{Name:"review",Effects:map[string]author.Effect{"call":{Capability:"model",Input:schema.Record{"input":{Kind:"string",MaxBytes:100}},Output:schema.Record{"answer":{Kind:"string",MaxBytes:100}}}},Steps:[]author.Step{author.Request("request","call",map[string]author.Expr{"input":author.String("question")},nil),author.Await("call","request",map[string]string{"answer":"answer","valid":"valid"}),author.Success()}});check(e)
 p,e:=(author.Application{"agent":{Artifact:a}}).Provision();check(e)
 s,e:=runtime.Create(ctx,path,p,runtime.DefaultLimits());check(e)
 _,e=s.Run(ctx,runtime.RunOptions{MaxSteps:20,MaxDispatch:20,Adapters:map[string]effects.Adapter{"model":adapter{}}});check(e);check(s.Close())
 _,e=runtime.Inspect(ctx,path,runtime.DefaultLimits());check(e)
 _,e=runtime.Replay(ctx,path,runtime.DefaultLimits());check(e)
 raw,e:=os.ReadFile(path);check(e)
 corruptPath:=filepath.Join(root,"ledger-orphan.db");check(os.WriteFile(corruptPath,raw,0600))
 db,e:=sql.Open("sqlite3",corruptPath);check(e)
 // Delete both outgoing edges, leaving the runtime-adapter observation and retained result.
 _,e=db.Exec("DELETE FROM settlements; DELETE FROM admissions WHERE domain='adapter'");check(e);check(db.Close())
 inspection,inspectErr:=runtime.Inspect(ctx,corruptPath,runtime.DefaultLimits())
 _,replayErr:=runtime.Replay(ctx,corruptPath,runtime.DefaultLimits())
 reopened,openErr:=runtime.Open(ctx,corruptPath,runtime.DefaultLimits());if reopened!=nil{reopened.Close()}
 b,e:=json.Marshal(map[string]any{"inspect_error":fmt.Sprint(inspectErr),"inspect_observations":len(inspection.Tables["observations"]),"inspect_adapter_results":len(inspection.Tables["adapter_results"]),"inspect_admissions":len(inspection.Tables["admissions"]),"inspect_settlements":len(inspection.Tables["settlements"]),"replay_error":fmt.Sprint(replayErr),"open_error":fmt.Sprint(openErr)});check(e);fmt.Println(string(b))
}
