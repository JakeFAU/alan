package openai

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
)

// uniqueJSON rejects duplicate fields at every object depth before typed decoding.
func uniqueJSON(raw []byte) error {
	d := json.NewDecoder(bytes.NewReader(raw))
	d.UseNumber()
	if e := uniqueValue(d, 0); e != nil {
		return e
	}
	if _, e := d.Token(); e != io.EOF {
		return errors.New("trailing JSON")
	}
	return nil
}
func uniqueValue(d *json.Decoder, depth int) error {
	if depth > 64 {
		return errors.New("JSON nesting limit")
	}
	t, e := d.Token()
	if e != nil {
		return e
	}
	delim, ok := t.(json.Delim)
	if !ok {
		return nil
	}
	switch delim {
	case '{':
		seen := map[string]bool{}
		for d.More() {
			key, e := d.Token()
			if e != nil {
				return e
			}
			k, ok := key.(string)
			if !ok || seen[k] {
				return errors.New("duplicate JSON field")
			}
			seen[k] = true
			if e = uniqueValue(d, depth+1); e != nil {
				return e
			}
		}
	case '[':
		for d.More() {
			if e = uniqueValue(d, depth+1); e != nil {
				return e
			}
		}
	default:
		return errors.New("invalid JSON delimiter")
	}
	_, e = d.Token()
	return e
}

// Decode before redaction so escaped credential echoes are not retained in a
// reversibly encoded form. JSON nested in output_text is sanitized as well.
func (a *Adapter) redactEvidence(raw string, depth int) string {
	direct := a.redact(raw)
	if depth > 4 {
		return direct
	}
	var v any
	d := json.NewDecoder(bytes.NewBufferString(direct))
	d.UseNumber()
	if d.Decode(&v) != nil {
		return direct
	}
	changed := false
	var visit func(any) any
	visit = func(value any) any {
		switch x := value.(type) {
		case string:
			clean := a.redactEvidence(x, depth+1)
			if clean != x {
				changed = true
			}
			return clean
		case []any:
			for i := range x {
				x[i] = visit(x[i])
			}
		case map[string]any:
			clean := map[string]any{}
			for k, v := range x {
				key := a.redact(k)
				if key != k {
					changed = true
				}
				clean[key] = visit(v)
			}
			return clean
		}
		return value
	}
	v = visit(v)
	if !changed {
		return direct
	}
	b, e := json.Marshal(v)
	if e != nil {
		return "[REDACTED]"
	}
	return string(b)
}
