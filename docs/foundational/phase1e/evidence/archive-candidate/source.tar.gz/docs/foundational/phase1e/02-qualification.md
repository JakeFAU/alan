# Phase 1E qualification

Application authors use named finite steps, typed fields, ordinary ports and effect requests through public Go packages. The reusable evidence helper composes planning/synthesis and a retrieval worker. In the controlled process qualification, the actual CLI answers **“WAL retains a durable log.”** to “What does WAL retain?”, citing retained `selected-corpus` version `bcdf04a60c21be85488f48d87ad918f0d06423b517de5660ea05db7b104c17be`, bytes `[0,26)`. It recovers that answer after process death without repeating the completed operation. This uses the real OpenAI Responses serializer/parser against a controlled HTTP provider. **Live provider gate: NOT RUN.** Full-source verification has passed; archive reproduction and independent whole-branch review remain the final gates.

## Historical baseline reproduction

Source commit `d708493646aeae3c1e70a03cf2bb2d7db974c127` has the same tracked tree as the published Phase 1D.1 source. The immutable archived source reproduced its retained 58-file manifest, aggregate SHA-256 `9fef40370632bdf7416d5bdb2e8472f31ae2adc80ae5145cd7c9c90ccfe63e63`. Full normal and race suites each passed 357 test/subtest events. All ordered finite-semantics (15), composition (20) and supervision (32) qualification payloads matched the historical final evidence. See [baseline report](evidence/baseline/report.md), commands, raw logs and comparison records alongside it. Historical files were not rewritten. The current runtime/model bridge changes only two external-key assertions to apply the new namespace encoding; its local execution and lifecycle monitors remain intact. The finite model sources and earlier phase documentation/evidence are unchanged.

## Namespace correction

The original two-store input produced four endpoint contacts but one mutation: identical local intent identities collided at the shared endpoint. With namespace/key version 2, the same scenario produces four contacts and two mutations. Reopening each original store preserves its key. Rename/copy preserves identity; a copy is not a separately provisioned store. The retained pre-fix source and databases are in [task1 evidence](evidence/task1/manifest.json). Full current-source tests at this boundary passed 368 test/subtest events, separately from historical reproduction; focused races also passed. See [slice report](evidence/task1/report.md).

## Compiler review counterexamples

The first compiler implementation passed its supplied default and integration suites, but independent public-consumer probes found two wrong results. A true branch ending in a reachable forward label fell into the false branch; distinct invalid UTF-8 variable names became the same serialized identifier. Run and Replay both reproduced each wrong result, illustrating why replay consistency alone is not compiler conformance. The [review](evidence/task2/review-round1.md), original inputs/artifacts and complete pre-fix Go/module source are retained in [task2 evidence](evidence/task2/manifest.json). Both defects are corrected and [scoped re-review](evidence/task2/rereview-round1.md) accepts R1/R2. The original public probes and new executable regressions verify the intended branch result and UTF-8 rejection; valid Unicode remains distinct. Full suites before the fix passed 405 default/414 integration test events; the fix then passed 72 focused author/runtime/schema events and targeted metadata/legacy checks. These intermediate counts are not the final Phase 1E qualification.

## Adapter review counterexamples

The initial adapter slice passed its supplied protocol/ownership/recovery suites. Independent probes then found reversible fake-credential echoes in escaped headers and deeply encoded error strings, a case-alias JSON field that overrode a canonical incomplete status, and Inspect accepting an orphan adapter observation. Open and Replay already rejected the orphan. These are retained in [the review](evidence/task3/review-round1.md) with [original probes, databases and pre-fix source](evidence/task3/manifest.json). Fail-closed sanitization, exact provider-key validation and reducer-free reverse-link checks correct these inputs. [Scoped re-review](evidence/task3/rereview-round1.md) accepted all three findings; covering tests and targeted races pass. Sanitization can omit benign unusually encoded evidence, a documented cost. No real credential or live OpenAI call was used.

## Ordinary evidence application

The reusable public helper returns ordinary instances plus a request/result port. A separate-module consumer composes two helpers without internal imports or child-state access. Controlled Responses HTTP requests exercise lookup, clarification, insufficient evidence, malformed/refused/incomplete results, wrong tools, exhausted budgets and exact citation mismatches. For `How does WAL work?`, the controlled answer is `WAL records changes before updating the main database.`, citing retained document `durability`, version `c2d44001abf76e7220188c766c6ca6b4080dd56afbff64ac2bcc48510af84437`, bytes `[0,82)`. This is a controlled response, not live inference. See [application report](evidence/task4/report.md) and [runbook](04-application-runbook.md).

Independent review found that the application inspection facade combined two different read transactions while a runner was advancing. The retained counterexample shows a public clarification result alongside a caller snapshot from before its Receive. [Original review](evidence/task4/review-round1.md), input and pre-fix source are retained. The correction derives all fields from one runtime snapshot; [scoped re-review](evidence/task4/rereview-round1.md) passed. Historical replay verification remains a separate command. The original runtime snapshot was already coherent.

## Process qualification

The [process report](evidence/task5/report.md) records actual CLI SIGKILL after model-result recording and after lookup-result recording, plus provider-accepted/no-result ambiguity. Recovery uses retained artifacts, budgets, pending identities and corpus bytes after the original file is deleted. Two independently logged model contacts and one observed lookup produce the answer above. Unknown model work remains Unknown and is not repeated.

The controller observes actual lookup completion before the tool-result crash and arms the original lookup authorization on recovery; successful recovery reaches no such re-entry. Offline CLI replay has no credential/provider/source file or registry, preserves every retained table/projection, and leaves independent contacts unchanged. Its zero adapter invocation claim is based on the registry-free replay API and code path, not a fabricated dynamic counter. A faulty wrapper directly executes the original real model request after replay, producing an extra contact that the unchanged monitor rejects.

Additional real process fixtures cover held-model capacity 1/2, peer commit and caller delivery before model release, fast lookup/fixture settlement, physical SIGTERM drain, and late evidence after ordinary source closure. These last capacity cases use a disclosed generic test owner calling automatic Run; application crash cases use the actual CLI. External cancellation is a controller injection, not supervisory policy. The original harness incorrectly ordered an independent fast lookup after caller consumption; that trace/source is retained, and the monitor now accepts allowed fast ordering while preserving the required held-model/peer/caller chain.

Independent process review accepted the observed traces but found a false-identity oracle gap: the real crash filters wildcarded the sequence, and the durable checker accepted sequence 16 for a retained intent at sequence 15. The original traces had correct sequences. The [original review and input](evidence/task5/review-round1.md), complete pre-fix source, and passing pre-review suites remain retained. The correction binds the event to both retained adapter and committed intent evidence; [scoped re-review](evidence/task5/rereview-round1.md) passed the original substitution and additional inconsistent-evidence probes.

These qualify selected process crashes under the stated local storage assumptions. They are not power-loss, disk-failure, distributed-partition or unbounded liveness tests. Scope and exact fixture configuration/artifacts/identities are retained in the machine records.

## Live provider gate

**NOT RUN.** No configured OpenAI credential or explicit model ID was available during initial inspection. No live result or provider usage is claimed. Controlled protocol/application qualification will be reported separately, with a runnable opt-in live command.

## Current-source verification

The complete frozen source/input identity is `fc1e319d8a81ff5269afabc0b98e1876b9a9a561a2b7595ce986296b78e225e1`: 129 files covering Go sources, tests/testdata, embedded corpus, module metadata, qualification tools and their frozen comparison inputs. [source-manifest.json](source-manifest.json) records every file hash. Its freeze HEAD is `0c7151ba6d1044f72017ec48b5ff7c539d0a8b71` plus the explicitly identified then-uncommitted qualification tools/fixtures. It is a working-tree digest, not a claim that the earlier commit contained those files.

Actual platform: macOS 27.2 arm64, Go 1.27.3, CGO enabled, Apple C compiler. [Environment and dependency commands](evidence/environment.json) retain exact versions and module hashes. No new dependency was added: `github.com/mattn/go-sqlite3 v1.14.52` remains pinned. Installed Go/C toolchains are not bundled.

| Command | Actual result |
| --- | --- |
| `go test -json -count=1 ./...` | PASS, 462 passing test/subtest events, 14.571s |
| `go test -json -count=1 -tags integration ./...` | PASS, 601 passing test/subtest events, 15.217s |
| `go test -json -count=1 -race -tags integration ./...` | PASS, 601 passing test/subtest events, 102.351s; actual children built with `-race` |
| Python comparison controls | PASS, seven tests, including deliberately changed behavior/provenance/order/projection inputs |
| `go vet ./...`, `go vet -tags integration ./...` | PASS |
| `gofmt -l author schema runtime effects adapters cmd internal research examples` | Empty output |
| `go mod verify`, `git diff --check` | PASS |

Commands use `GOTOOLCHAIN=local`, offline module resolution and `-mod=readonly` for full Go runs. Exact commands, environment, exit codes, raw hashes, package results and source-before/after checks are in `evidence/final-{default,normal,race}.command.json`; raw Go JSON and extracted causal records are retained alongside them. [Static/comparison results](evidence/final-checks.json) preserve the actual commands. Counts are passing Go test/subtest events, not distinct safety properties.

Current-source comparison is deliberately separate from historical reproduction: 15 finite-semantics payloads are exactly equal; 20 composition and 32 supervision records preserve exact ordered behavior after validated provenance fields change. The semantic source manifest differs only in the two namespace-aware assertions in `runtime_conformance_test.go`. The six runtime/model fixtures retain matching model streams and 63 public projections across 81 checkpoints. Raw runtime snapshots are not equal: schema/namespace/new empty ledgers, external keys and ephemeral endpoints/PIDs differ. No raw equality is claimed for those fixtures. [Comparison audit and controls](evidence/evidence-tools/report.md) retain decoded differences and the initially over-strict comparison failure. The comparator also rejected a controller invocation made before current race evidence was complete; that mixed-source rejection remains recorded and was rerun after completion without changing its predicate.

Earlier passing suites remain under their own identities in slice evidence. The c67d… run precedes comparison-tool correction; 893577… precedes the actual-filter oracle correction. Neither is relabeled as the final source. Historical phase files and finite-model searches are unchanged; selected current-runtime key expectations changed explicitly.

## Remaining gates

Independent whole-branch review and credential-free archive reproduction. All five implementation slices have passed separate scoped reviews, including their corrected findings; those approvals do not replace the final gate.
