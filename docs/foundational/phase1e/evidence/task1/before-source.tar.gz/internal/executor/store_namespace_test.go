package executor

import (
 "encoding/json"
 "fmt"
 "net/http"
 "net/http/httptest"
 "os"
 "path/filepath"
 "testing"

 resource "github.com/JakeFAU/alan/internal/fixture"
)

// Removing store isolation must produce one mutation for two independent programs.
func TestStoreNamespacesSeparateSharedEndpointAndSurviveReopen(t *testing.T) {
 dir := t.TempDir()
 if retained := os.Getenv("ALAN_NAMESPACE_EVIDENCE"); retained != "" { dir = retained; if err := os.MkdirAll(dir,0700); err != nil { t.Fatal(err) } }
 endpointPath := filepath.Join(dir,"endpoint.sqlite")
 endpoint, err := resource.Open(t.Context(),endpointPath,"namespace-endpoint")
 if err != nil { t.Fatal(err) }; defer endpoint.Close()
 server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request) {
  var req resource.Request
  if err := json.NewDecoder(r.Body).Decode(&req); err != nil { t.Error(err); return }
  receipt, err := endpoint.Apply(r.Context(),req)
  if err != nil { t.Error(err); w.WriteHeader(500); return }
  // Retain unknown local outcomes so reopen must retransmit the original request.
  _ = receipt
  w.WriteHeader(http.StatusServiceUnavailable)
 })); defer server.Close()
 p := externalProvision(t,server.URL,"idempotent")
 raw,_ := json.MarshalIndent(p,"","  "); if err := os.WriteFile(filepath.Join(dir,"provision.json"),raw,0600); err != nil { t.Fatal(err) }
 var keys [2]string
 for i := range 2 {
  path := filepath.Join(dir,fmt.Sprintf("store-%d.sqlite",i))
  s,err := Create(t.Context(),path,p,DefaultLimits()); if err != nil { t.Fatal(err) }
  report,err := s.Run(t.Context(),RunOptions{MaxSteps:100,MaxDispatch:100}); if err != nil { s.Close(); t.Fatal(err) }
  if len(report.UnknownExternal)!=1 || report.UnknownExternal[0]!=`["client",1,1,0]` { t.Fatalf("local identity changed: %+v",report) }
  attempt,err := loadExternalAttempt(t.Context(),s.conn,report.UnknownExternal[0]); if err != nil { t.Fatal(err) }; keys[i]=attempt.Request.Key
  if err := s.Close(); err != nil { t.Fatal(err) }
  s,err=Open(t.Context(),path,DefaultLimits()); if err != nil { t.Fatal(err) }
  if _,err=s.Run(t.Context(),RunOptions{MaxSteps:100,MaxDispatch:100}); err != nil { t.Fatal(err) }
  again,err:=loadExternalAttempt(t.Context(),s.conn,report.UnknownExternal[0]); if err != nil { t.Fatal(err) }
  if again.Request!=attempt.Request { t.Fatal("reopen changed immutable request") }
  if err := s.Close(); err != nil { t.Fatal(err) }
 }
 snapshot,err:=resource.Inspect(t.Context(),endpointPath); if err != nil { t.Fatal(err) }
 raw,_=json.MarshalIndent(snapshot,"","  "); if err:=os.WriteFile(filepath.Join(dir,"endpoint-inspection.json"),raw,0600); err!=nil { t.Fatal(err) }
 if snapshot.Contacts!=4 || len(snapshot.Applications)!=2 || snapshot.Total!=10 || keys[0]==keys[1] { t.Fatalf("independent stores collided: keys=%q contacts=%d mutations=%d total=%d",keys,snapshot.Contacts,len(snapshot.Applications),snapshot.Total) }
 for i,key:=range keys { if snapshot.Requests[2*i].Key!=key || snapshot.Requests[2*i+1].Key!=key { t.Fatal("endpoint did not observe preserved reopen key") } }
}
