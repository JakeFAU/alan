from pathlib import Path
import difflib, hashlib, json, struct, tarfile
root=Path.cwd(); out=root/'.superpowers/sdd/00-plan/evidence/final-fix'; original=root/'.superpowers/sdd/00-plan/evidence/final-review/original-source'
old=json.loads((original/'source-manifest.json').read_text())
newpath='adapters/openai/final_review_regression_test.go'
paths=sorted({Path(f['path']) for f in old['files']}|{Path(newpath)})
digest=hashlib.sha256(); files=[]; changes=[]
oldmap={f['path']:f for f in old['files']}
for path in paths:
 name=str(path); data=(root/path).read_bytes(); encoded=name.encode(); sha=hashlib.sha256(data).hexdigest()
 digest.update(struct.pack('>Q',len(encoded))+encoded+struct.pack('>Q',len(data))+data)
 files.append(dict(path=name,bytes=len(data),sha256=sha))
 if name not in oldmap or sha!=oldmap[name]['sha256']: changes.append(name)
expected=['adapters/openai/final_review_regression_test.go','adapters/openai/openai.go','adapters/openai/protocol.go','examples/evidence/evidence_test.go']
assert changes==expected,(changes,expected)
(out/'after-source-manifest.json').write_text(json.dumps(dict(source_sha256=digest.hexdigest(),before_source_sha256=old['source_sha256'],files=files,changed_paths=changes,identity='Same executable-source input set and uint64-big-endian aggregation as original frozen manifest, plus new FR1 regression test.'),indent=2)+'\n')
owned=changes+['docs/foundational/phase1e/01-authoring-effects-contract.md']
patch=[]
with tarfile.open(original/'source.tar.gz','r:gz') as archive:
 for name in owned:
  before='' if name==newpath else archive.extractfile(name).read().decode()
  after=(root/name).read_text()
  if name in oldmap: assert hashlib.sha256(before.encode()).hexdigest()==oldmap[name]['sha256']
  patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='frozen/'+name,tofile='after/'+name))
(out/'against-frozen.patch').write_text(''.join(patch))
with tarfile.open(out/'after-changed-source.tar.gz','w:gz') as archive:
 for name in owned: archive.add(root/name,arcname=name)
(out/'after-changed-hashes.json').write_text(json.dumps([dict(path=name,sha256=hashlib.sha256((root/name).read_bytes()).hexdigest()) for name in owned],indent=2)+'\n')
print('after source',digest.hexdigest(),'files',len(files),'changed',changes)
