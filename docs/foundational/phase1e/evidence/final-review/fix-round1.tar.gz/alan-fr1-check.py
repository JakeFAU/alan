from pathlib import Path
import os, subprocess, json, tempfile, hashlib
root=Path.cwd(); out=root/'.superpowers/sdd/00-plan/evidence/final-fix'
env=os.environ.copy(); env.update(GOTOOLCHAIN='local',GOCACHE='/tmp/alan-phase1e-go-build',GOPROXY='off',GOSUMDB='off',PYTHONDONTWRITEBYTECODE='1')
commands=[('race',['go','test','-race','-tags=integration','-count=1','-v','./adapters/openai','./examples/evidence','-run','TestFinalReviewOutputItemStatus|TestResponses|TestReview|TestControlledApplication']),('vet',['go','vet','-tags=integration','./adapters/openai','./examples/evidence']),('gofmt',['gofmt','-l','adapters/openai/openai.go','adapters/openai/protocol.go','adapters/openai/final_review_regression_test.go','examples/evidence/evidence_test.go']),('original-probe',['go','run','.superpowers/sdd/00-plan/evidence/final-review/probe.go',tempfile.mkdtemp(prefix='alan-fr1-original-probe-')])]
records=[]
for name,args in commands:
 p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 path=out/(name+'.log');path.write_bytes(p.stdout)
 records.append(dict(name=name,argv=args,exit_code=p.returncode,log=str(path.relative_to(root)),sha256=hashlib.sha256(p.stdout).hexdigest()))
 print(name,'exit',p.returncode,'bytes',len(p.stdout),flush=True)
 (out/'checks.json').write_text(json.dumps(dict(environment={k:env[k] for k in ['GOTOOLCHAIN','GOCACHE','GOPROXY','GOSUMDB','PYTHONDONTWRITEBYTECODE']},commands=records),indent=2)+'\n')
 if p.returncode: raise SystemExit(p.returncode)
 if name=='gofmt' and p.stdout: raise SystemExit('unexpected formatting output')
