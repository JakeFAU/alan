from pathlib import Path
p=Path('adapters/openai/openai.go')
s=p.read_text().replace('Type, Role string\n\t\t\tContent', 'Type, Role string\n\t\t\tStatus     json.RawMessage\n\t\t\tContent',1)
s=s.replace('\tfor _, item := range body.Output {\n\t\tswitch item.Type {','''\tfor _, item := range body.Output {
\t\t// Omission is supported for compatibility; present status must be terminal.
\t\t// RawMessage distinguishes an omitted field from explicit null.
\t\tif len(item.Status) > 0 {
\t\t\tvar status string
\t\t\tif json.Unmarshal(item.Status, &status) != nil || status != "completed" {
\t\t\t\tc.Disposition = "protocol_invalid"
\t\t\t\treturn c
\t\t\t}
\t\t}
\t\tswitch item.Type {''',1)
p.write_text(s)
p=Path('adapters/openai/protocol.go')
s=p.read_text().replace('protocolObject(item, "type", "role", "content")','protocolObject(item, "type", "role", "status", "content")',1)
p.write_text(s)
p=Path('docs/foundational/phase1e/01-authoring-effects-contract.md')
s=p.read_text()
needle='They never become validated application success.'
s=s.replace(needle,needle+' A successful response requires a completed top-level status. Accepted message and reasoning items may omit status as an explicit compatibility subset; if present, status must be the JSON string `"completed"`. Explicit incomplete/in_progress, null, malformed, empty or unknown item statuses and noncanonical status-key case aliases (including Unicode case-fold aliases) produce `protocol_invalid` with no application payload. Original bounded nonsensitive response evidence remains retained; the existing sanitizer still applies. This parser correction applies to newly received evidence. Already recorded dispositions remain historical facts reused by recovery and offline replay; it does not reinterpret or migrate them.',1)
p.write_text(s)
