# Independent review commands and limits

Run from the frozen checkout root, source fc1e319d8a81ff5269afabc0b98e1876b9a9a561a2b7595ce986296b78e225e1.

- `GOTOOLCHAIN=local GOCACHE=/tmp/alan-phase1e-go-build GOPROXY=off GOSUMDB=off go run /tmp/alan-final-independent-review/probe.go /tmp/alan-final-independent-review/databases` — exit 0; diagnostic JSON, 32 arithmetic assertions plus three protocol status observations. Last two observations reproduce FR1. Local loopback only, synthetic credential.
- `GOTOOLCHAIN=local GOCACHE=/tmp/alan-phase1e-go-build GOPROXY=off GOSUMDB=off go run /tmp/alan-final-independent-review/ledger_probe.go /tmp/alan-final-independent-review/ledger-databases` — exit 0; known/unknown real HTTP recovery each one contact, plus three copied-ledger mutations rejected by Inspect/Open/Replay. Full before/after snapshots and replay reports retained in ledger-output.jsonl.
- `PYTHONDONTWRITEBYTECODE=1 python3 /tmp/alan-final-independent-review/audit.py` — exit 0; source/archive/raw-log verification in audit.json.

The first audit draft assumed flat string path sorting. It failed at its own sorting assertion, while every per-file hash and the aggregate matched. freeze.py deliberately sorts pathlib.Path values by components, so the review audit was corrected to compare that same declared ordering. The original reviewer script is audit-original.py; this was a reviewer-tool assumption correction, not a product source/manifest defect.

No broad suites were rerun. The retained full runs were inspected and independently hash/count audited. No live credential was read or used. No implementation, tracked tests, index, HEAD or branch changes were made. Only this requested review report/evidence directory was written. Disposable successful probe databases stay in /tmp; full before/after ledger contents are retained in JSON. Reproducing either Go diagnostic requires a fresh output directory because Create intentionally refuses existing stores.
