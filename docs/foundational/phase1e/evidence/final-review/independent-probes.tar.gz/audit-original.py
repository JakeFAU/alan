import pathlib, json, hashlib, struct, tarfile, gzip, collections, re
R=pathlib.Path.cwd();D=R/'docs/foundational/phase1e';out={}
m=json.loads((D/'source-manifest.json').read_text());h=hashlib.sha256();seen=[]
for f in m['files']:
 p=f['path'];b=(R/p).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],p
 q=p.encode();h.update(struct.pack('>Q',len(q))+q+struct.pack('>Q',len(b))+b);seen.append(p)
assert seen==sorted(set(seen)) and h.hexdigest()==m['source_sha256']
packages=[str(p.relative_to(R)) for d in ['author','schema','runtime','effects','adapters','cmd','internal','research','examples'] for p in (R/d).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
assert set(packages)<=set(seen)
out['source']={'sha256':h.hexdigest(),'files':len(seen),'package_files':len(packages),'complete':True}
a=json.loads((D/'archive-manifest.json').read_text());b=(D/'source.tar.gz').read_bytes();assert len(b)==a['Bytes'] and hashlib.sha256(b).hexdigest()==a['SHA256']
with tarfile.open(D/'source.tar.gz') as t:
 members=t.getmembers();assert len({x.name for x in members})==len(members);assert [x.name for x in members]==[f['Path'] for f in a['Files']]
 for member,f in zip(members,a['Files']):
  assert member.isfile() and not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
  raw=t.extractfile(member).read();assert len(raw)==f['Bytes'] and hashlib.sha256(raw).hexdigest()==f['SHA256']
  if member.name in seen:assert raw==(R/member.name).read_bytes()
 assert set(seen)<=set(x.name for x in members)
out['archive']={'sha256':a['SHA256'],'members':len(members),'all_source_inputs_present':True}
out['modes']={}
for mode in ['default','normal','race']:
 meta=json.loads((D/f'evidence/final-{mode}.command.json').read_text());compressed=(D/f'evidence/final-{mode}.go-test.jsonl.gz').read_bytes();raw=gzip.decompress(compressed)
 assert hashlib.sha256(raw).hexdigest()==meta['RawSHA256'] and hashlib.sha256(compressed).hexdigest()==meta['GzipSHA256'];assert meta['SourceID']==m['source_sha256'] and meta['ExitCode']==0
 events=[json.loads(x) for x in raw.splitlines()];assert not [e for e in events if e['Action']=='fail'];passes=sum(e['Action']=='pass' and bool(e.get('Test')) for e in events);assert passes==meta['PassingEvents']
 records=[json.loads(x) for x in gzip.decompress((D/f'evidence/final-{mode}.records.jsonl.gz').read_bytes()).splitlines()]
 assert all(r['SourceID']==m['source_sha256'] and r['Mode']==mode and r['RecordIndex']==i+1 for i,r in enumerate(records));assert dict(collections.Counter(r['Marker'] for r in records))==meta['Markers']
 children=[r['Evidence'] for r in records if isinstance(r['Evidence'],dict) and r['Evidence'].get('type')=='process-start']
 builds=[r['Evidence'] for r in records if isinstance(r['Evidence'],dict) and r['Evidence'].get('type')=='build']
 if mode=='race':
  assert children and all(r['race_children'] for r in children);assert builds and all('-race' in r['command'] for r in builds)
 out['modes'][mode]={'pass_events':passes,'records':len(records),'process_starts':len(children),'builds':len(builds),'raw_sha256':meta['RawSHA256']}
q=[json.loads(x) for x in (D/'qualification.jsonl').read_bytes().splitlines()];out['qualification_records']=len(q)
print(json.dumps(out,indent=2))
