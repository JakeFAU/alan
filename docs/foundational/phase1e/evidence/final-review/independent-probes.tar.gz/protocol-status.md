# Original protocol status counterexample

Original frozen source identity fc1e319d8a81ff5269afabc0b98e1876b9a9a561a2b7595ce986296b78e225e1, HEAD 0c7151ba6d1044f72017ec48b5ff7c539d0a8b71. No implementation changes by reviewer.

`probe.go` creates 32 disposable public-author/runtime Run+Replay arithmetic control cases and then invokes the real OpenAI serializer/parser against three synthetic loopback bodies. The completed control, incomplete output message, and in_progress output message all return validated with answer=candidate. Each case receives exactly one HTTP contact. No real credential or live provider is involved.

Reproduce from checkout root (choose a fresh writable store directory):

```sh
GOTOOLCHAIN=local GOCACHE=/tmp/alan-phase1e-go-build GOPROXY=off GOSUMDB=off go run .superpowers/sdd/00-plan/evidence/final-review/probe.go /tmp/alan-final-review-repro-stores
```

The diagnostic exits zero to preserve observed candidates; the incorrect classifications are explicit in the last two records of probe-output.jsonl. The original program, three exact raw HTTP response bodies, observed candidates and one-contact counts are retained. Runtime databases for successful arithmetic cases are disposable; they contain no failing compiler case.

Official protocol cross-check on 2026-10-25: https://developers.openai.com/api/reference/resources/responses/methods/create and https://developers.openai.com/api/reference/go/resources/responses expose ResponseOutputMessage.status with the alternatives completed, incomplete, and in_progress. The large create reference could not be opened by the browser text fetch (content-size limit); official search-extracted schema was available. This confirms message status is a recognized protocol field. No claim is made that the live provider was observed emitting an inconsistent top-level/item combination. A contradictory or nonterminal item should be rejected as invalid/incomplete under the explicit requirement that incomplete outputs cannot become success.
