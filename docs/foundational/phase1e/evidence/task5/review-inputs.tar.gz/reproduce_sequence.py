#!/usr/bin/env python3
"""Reproduce the retained pre-fix oracle counterexample without editing checkout files."""
import json,os,pathlib,subprocess,tempfile
here=pathlib.Path(__file__).resolve().parent
root=pathlib.Path.cwd()
if not (root/'go.mod').is_file(): raise SystemExit('Run from the ALAN checkout root')
with tempfile.TemporaryDirectory(prefix='alan-task5-review-') as temp:
 d=pathlib.Path(temp)
 source=(here/'independent_review_test.go').read_text().replace('/tmp/alan-task5-independent-review/actual-c-model-evidence.json',str(here/'actual-c-model-evidence.json'))
 probe=d/'independent_review_test.go';probe.write_text(source)
 replacements={str(root/'internal/evidencetest/independent_review_test.go'):str(probe)}
 for p in (here/'before-source').rglob('*'):
  if p.is_file():replacements[str(root/p.relative_to(here/'before-source'))]=str(p)
 overlay=d/'overlay.json';overlay.write_text(json.dumps({'Replace':replacements}))
 env=dict(os.environ,GOTOOLCHAIN='local',GOCACHE='/tmp/alan-phase1e-go-build',GOPROXY='off',GOSUMDB='off')
 raise SystemExit(subprocess.run(['go','test','-count=1','-tags','integration','-overlay',str(overlay),'-run','^TestIndependentActualCrashFilterSequenceSubstitution$','-v','./internal/evidencetest'],env=env).returncode)
