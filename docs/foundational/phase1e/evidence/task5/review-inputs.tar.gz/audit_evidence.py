import hashlib,json,pathlib
root=pathlib.Path.cwd(); out=[]
def records(name):
 p=root/'.superpowers/sdd/00-plan/evidence/task-5'/name
 return [json.loads(l.split('EVIDENCE ',1)[1]) for l in p.read_text().splitlines() if 'EVIDENCE {' in l]
def descriptors(s,table,key='descriptor'):
 return [json.loads(x[key]) for x in s['Tables'][table]]
def projection(v,subject):
 return next(x['Projection'] for x in v['Runs'] if x['ID']['Subject']==subject)
def correlated(s,ack):
 attempt=next(a for a in descriptors(s,'adapter_attempts') if a['Intent']['ID']==ack['Intent'])
 auth=next(a for a in descriptors(s,'attempts','result') if a['ID']==ack['Attempt'])
 assert attempt['Intent']['Sequence']==ack['Sequence']
 assert attempt['AuthorizationID']==auth['ID'] and auth['Allowed']
 assert auth['Source']['Epoch']==ack['Epoch']
 assert auth['Source']['Run']=={'Subject':ack['Subject'],'Generation':ack['Generation']}
 return attempt
for name in ['focused-normal.log','focused-race.log']:
 rows=records(name); count=0
 for x in rows:
  scenario=x.get('scenario','')
  if 'stopped' not in x:continue
  before=x['stopped']; after=x['after']; ack=x['barrier']; a=correlated(before['Snapshot'],ack)
  assert a==correlated(after['Snapshot'],ack)
  assert before['Snapshot']['Namespace']==after['Snapshot']['Namespace']
  assert all(s['intent_id']!=ack['Intent'] for s in before['Snapshot']['Tables']['settlements'])
  assert projection(before,ack['Subject'])['Data']['model_spent' if ack['Subject']=='assistant' else 'lookup_spent']['Number']==1
  if 'CrashRecovery' in scenario:
   assert after['ModelRequests']==2 and after['LookupRequests']==1 and after['Attempts']==3
   assert projection(after,'assistant')['Data']['model_spent']['Number']==2
   assert projection(after,'assistant/retrieval')['Data']['lookup_spent']['Number']==1
   tables=after['Snapshot']['Tables']; intents=descriptors(after['Snapshot'],'intents'); obs=descriptors(after['Snapshot'],'observations')
   # Traverse actual cross-subject causal edges; do not compare unrelated local sequences.
   plan=next(i for i in intents if i['Kind']=='adapter' and i['Obligation']=='plan')
   planobs=next(r for r in tables['observations'] if json.loads(r['descriptor'])['Operation']==plan['ID'])
   request=next(i for i in intents if i['Kind']=='message' and i['Run']['Subject']=='assistant' and i['Target']=='assistant/retrieval')
   assert planobs['consumed_sequence']<request['Sequence']
   msgsettle=next(s for s in tables['admissions'] if json.loads(s['descriptor'])['IntentID']==request['ID'])
   msgobs=next(r for r in tables['observations'] if r['id']==msgsettle['observation_id'])
   lookup=next(i for i in intents if i['Kind']=='adapter' and i['Obligation']=='lookup')
   assert msgobs['consumed_sequence']<lookup['Sequence']
   lookupobs=next(r for r in tables['observations'] if json.loads(r['descriptor'])['Operation']==lookup['ID'])
   reply=next(i for i in intents if i['Kind']=='message' and i['Run']['Subject']=='assistant/retrieval')
   assert lookupobs['consumed_sequence']<reply['Sequence']
   replysettle=next(s for s in tables['admissions'] if json.loads(s['descriptor'])['IntentID']==reply['ID'])
   replyobs=next(r for r in tables['observations'] if r['id']==replysettle['observation_id'])
   synth=next(i for i in intents if i['Kind']=='adapter' and i['Obligation']=='synthesize')
   assert replyobs['consumed_sequence']<synth['Sequence']
   path=[['assistant',planobs['consumed_sequence'],request['Sequence']],['assistant/retrieval',msgobs['consumed_sequence'],lookup['Sequence'],lookupobs['consumed_sequence'],reply['Sequence']],['assistant',replyobs['consumed_sequence'],synth['Sequence']]]
   out.append({'log':name,'scenario':scenario,'barrier_sequence':ack['Sequence'],'causal_local_sequence_path':path,'budgets':[2,1],'result':after['Result']})
  else:
   assert [(r['ID'],r['Projection']) for r in before['Runs']]==[(r['ID'],r['Projection']) for r in after['Runs']] and before['Unknown']==after['Unknown']
   assert after['ModelRequests']==1 and after['LookupRequests']==0 and not after['Results']
   out.append({'log':name,'scenario':scenario,'unknown_and_full_run_projections_preserved':True})
  count+=1
 assert count==3
 for x in rows:
  if x.get('type')=='offline-replay':
   assert x['before']==x['after']
   replay={json.dumps(r['ID'],sort_keys=True):r['Projection'] for r in x['replay']['Runs']}
   expected={json.dumps(r['ID'],sort_keys=True):r['Projection'] for r in x['before']['Runs']}
   assert replay==expected
  if x.get('scenario')=='TestRealModelLateEvidenceAfterSourceClosure':
   correlated(x['known_unsettled'],x['late'])
   aid=x['late']['Intent']
   assert any(r['Candidate']['ID']==aid for r in descriptors(x['known_unsettled'],'adapter_results'))
   assert all(s['intent_id']!=aid for s in x['known_unsettled']['Tables']['settlements'])
   assert any(s['intent_id']==aid for s in x['after']['Tables']['settlements'])
   out.append({'log':name,'scenario':x['scenario'],'known_unsettled_then_settled_original_intent':aid})
 for x in rows:
  if x.get('type')=='process-exit' and x.get('signal')=='killed':
   assert any(y.get('type')=='process-start' and y['pid']==x['pid'] for y in rows)
manifest=json.loads((root/'.superpowers/sdd/00-plan/evidence/task-5/source-manifest.json').read_text())
for f in manifest['files']:
 raw=(root/f['path']).read_bytes(); assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256']
 assert raw==(root/'.superpowers/sdd/00-plan/evidence/task-5/source'/f['path']).read_bytes()
print(json.dumps({'status':'PASS','source_manifest_verified':manifest,'checks':out},indent=2))
