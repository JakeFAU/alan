//go:build integration
package evidencetest
import("encoding/json"; "os"; "testing"; "github.com/JakeFAU/alan/examples/evidence"; "github.com/JakeFAU/alan/internal/boundary")
func TestIndependentActualCrashFilterSequenceSubstitution(t *testing.T) {
 raw,err:=os.ReadFile("/tmp/alan-task5-independent-review/actual-c-model-evidence.json");if err!=nil{t.Fatal(err)}
 var input struct { Barrier boundary.Event `json:"barrier"`; Stopped evidence.View `json:"stopped"` };if err=json.Unmarshal(raw,&input);err!=nil{t.Fatal(err)}
 original:=input.Barrier
 // Same selected fields used by paused() in actual C-model (sequence is wildcard).
 filter:=boundary.Event{Boundary:original.Boundary,Phase:original.Phase,Subject:original.Subject,Store:original.Store,Scenario:original.Scenario,Token:original.Token}
 forged:=original;forged.Sequence++
 if err:=validateAcknowledgment(forged,[]boundary.Event{filter},original.PID,map[string]bool{});err!=nil{t.Fatalf("matcher rejected substitution: %v",err)}
 validateDurableBoundary(t,input.Stopped.Snapshot,forged)
 t.Logf("CONFIRMED: actual C-model matcher and durable check accept Sequence=%d while retained intent and original ack Sequence=%d; intent=%s",forged.Sequence,original.Sequence,original.Intent)
}
