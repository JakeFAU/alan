//go:build integration
package evidencetest

import (
 "encoding/json"
 "os"
 "testing"
 "github.com/JakeFAU/alan/examples/evidence"
 "github.com/JakeFAU/alan/internal/boundary"
 "github.com/JakeFAU/alan/runtime"
)
func TestIndependentR1CurrentHelper(t *testing.T) {
 raw,err:=os.ReadFile("/Users/jacob/.codex/worktrees/alan-phase1d1-dispatch/alan/.superpowers/sdd/00-plan/evidence/task-5/independent-review/actual-c-model-evidence.json");if err!=nil{t.Fatal(err)}
 var original struct { Barrier boundary.Event `json:"barrier"`; Stopped evidence.View `json:"stopped"` };if err=json.Unmarshal(raw,&original);err!=nil{t.Fatal(err)}
 for _,tc:=range []struct{name string; mutate func(*runtime.Inspection,*boundary.Event); reject bool}{
  {"original full retained snapshot",func(*runtime.Inspection,*boundary.Event){},false},
  {"original sequence counterexample",func(_ *runtime.Inspection,e *boundary.Event){e.Sequence++},true},
  {"adapter attempt and acknowledgment agree but committed intent disagrees",func(s *runtime.Inspection,e *boundary.Event){e.Sequence++;for _,r:=range s.Tables["adapter_attempts"]{var a runtime.AdapterAttempt;json.Unmarshal([]byte(r["descriptor"].(string)),&a);if a.Intent.ID==e.Intent{a.Intent.Sequence++;b,_:=json.Marshal(a);r["descriptor"]=string(b)}}},true},
  {"committed descriptor differs despite matching sequence",func(s *runtime.Inspection,e *boundary.Event){for _,r:=range s.Tables["intents"]{if r["id"]==e.Intent{var a map[string]any;json.Unmarshal([]byte(r["descriptor"].(string)),&a);a["Target"]="other-capability";b,_:=json.Marshal(a);r["descriptor"]=string(b)}}},true},
  {"missing adapter attempt",func(s *runtime.Inspection,_ *boundary.Event){delete(s.Tables,"adapter_attempts")},true},
  {"missing committed intent",func(s *runtime.Inspection,_ *boundary.Event){delete(s.Tables,"intents")},true},
 } {t.Run(tc.name,func(t *testing.T){
  var v evidence.View;b,_:=json.Marshal(original.Stopped);if err:=json.Unmarshal(b,&v);err!=nil{t.Fatal(err)}
  e:=original.Barrier;tc.mutate(&v.Snapshot,&e)
  f:=boundary.Event{Boundary:e.Boundary,Phase:e.Phase,Subject:e.Subject,Store:e.Store,Scenario:e.Scenario,Token:e.Token}
  if err:=validateAcknowledgment(e,[]boundary.Event{f},original.Barrier.PID,map[string]bool{});err!=nil{t.Fatal(err)}
  err:=validateDurableBoundary(v.Snapshot,e)
  if (err!=nil)!=tc.reject{t.Fatalf("reject=%v error=%v",tc.reject,err)}
  t.Logf("rejected=%v error=%v",err!=nil,err)
 })}
}
