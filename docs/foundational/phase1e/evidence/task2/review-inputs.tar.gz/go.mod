module external.example/task2review

go 1.27.3

require github.com/JakeFAU/alan v0.0.0

require github.com/mattn/go-sqlite3 v1.14.52 // indirect

replace github.com/JakeFAU/alan => /Users/jacob/.codex/worktrees/alan-phase1d1-dispatch/alan
