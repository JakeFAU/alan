package main

import (
 "context"
 "fmt"
 "os"
 "path/filepath"
 "github.com/JakeFAU/alan/author"
 "github.com/JakeFAU/alan/runtime"
)
func main() {
 cases := map[string]author.Definition{
  "trailing-label": {Steps: []author.Step{
   author.IfEqual(author.Boolean(true), author.Boolean(true),
    []author.Step{author.Goto("join"), author.Label("join")},
    []author.Step{author.Failure()}),
   author.Success(),
  }},
  "utf8-identifiers": {Steps: []author.Step{
   author.Set(string([]byte{0xfe}), author.Integer(1)),
   author.Set(string([]byte{0xff}), author.Integer(2)),
   author.IfEqual(author.Var(string([]byte{0xfe})), author.Integer(1),
    []author.Step{author.Success()}, []author.Step{author.Failure()}),
  }},
 }
 for name, d := range cases {
  a, err := author.Compile(d)
  fmt.Printf("%s compile_error=%v\n",name,err)
  if err != nil { continue }
  must(os.WriteFile(filepath.Join(os.Args[1],name+".artifact.json"),a.Bytes(),0600))
  p,err := (author.Application{"probe":{Artifact:a}}).Provision(); must(err)
  path := filepath.Join(os.Args[1],name+".db")
  s,err := runtime.Create(context.Background(),path,p,runtime.DefaultLimits()); must(err)
  _,err = s.Run(context.Background(),runtime.RunOptions{MaxSteps:100,MaxDispatch:100}); must(err)
  must(s.Close())
  r,err := runtime.Replay(context.Background(),path,runtime.DefaultLimits()); must(err)
  fmt.Printf("%s expected=succeeded actual=%s projection=%+v\n",name,r.Runs[0].Projection.Status,r.Runs[0].Projection)
 }
}
func must(err error) { if err != nil {panic(err)} }
