# Task 2 independent review probes

The exact external consumer is `main.go`; it imports only public packages. Its module lives outside ALAN at `/tmp/alan-task2-review-probe`. Definitions are the input cases. Each compiles, provisions, executes, closes, and replays through the public facade. Expected terminal status is `succeeded` for both; actual is `failed` for both. `output.log` retains the original stdout; the two JSON files retain exact compiled artifacts. No production or existing test source was edited.

Original command (exit 0; this diagnostic prints mismatches rather than asserting them):

```sh
cd /tmp/alan-task2-review-probe
GOTOOLCHAIN=local GOCACHE=/tmp/alan-phase1e-go-build GOPROXY=off GOSUMDB=off go run -mod=mod . /tmp/alan-task2-review-probe > /tmp/alan-task2-review-probe/output.log
```

For rerun, copy this module to a fresh directory, ensure the replace path points to the reviewed source, and pass a fresh output directory (existing DB paths intentionally cannot be recreated). `reviewed-source.tar.gz` retains all 19 frozen owned source/test files as reviewed, with verified digests in `reviewed-source-sha256.json`. `reviewed-package.diff` retains the supplied review diff. These are current-source defect probes, not historical baseline evidence or the original author's pre-fix reproductions.
