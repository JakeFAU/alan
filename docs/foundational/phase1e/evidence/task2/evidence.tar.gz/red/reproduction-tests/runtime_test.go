//go:build integration

package runtime_test

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/JakeFAU/alan/author"
	"github.com/JakeFAU/alan/runtime"
	"github.com/JakeFAU/alan/schema"
)

func TestRuntimeRejectsInvalidAuthorIngress(t *testing.T) {
	ctx := context.Background()
	record := schema.Record{"question": {Kind: "string", MaxBytes: 10, Enum: []string{"why"}}}
	a, err := author.Compile(author.Definition{Ports: map[string]author.Port{"input": {Peer: "local", Local: true, Obligation: "question", Receive: record}}, Steps: []author.Step{author.Receive("input", map[string]string{"question": "question"}), author.Success()}})
	if err != nil {
		t.Fatal(err)
	}
	p, err := (author.Application{"worker": {Artifact: a}}).Provision()
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "input.db")
	s, err := runtime.Create(ctx, path, p, runtime.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	for _, tt := range []struct {
		name    string
		payload map[string]schema.Value
	}{
		{"type", map[string]schema.Value{"question": schema.Int(2)}}, {"enum", map[string]schema.Value{"question": schema.Text("no")}}, {"extra", map[string]schema.Value{"question": schema.Text("why"), "extra": schema.Bool(true)}},
	} {
		t.Run(tt.name, func(t *testing.T) {
			r, err := s.AdmitInput(ctx, runtime.Input{TransportID: tt.name, LogicalID: tt.name, Target: "worker", Obligation: "question", Payload: tt.payload})
			if err != nil {
				t.Fatal(err)
			}
			if r.Accepted || r.Reason != "schema_invalid" {
				t.Fatalf("invalid input admitted: %+v", r)
			}
		})
	}
	r, err := s.AdmitInput(ctx, runtime.Input{TransportID: "good", LogicalID: "good", Target: "worker", Obligation: "question", Payload: map[string]schema.Value{"question": schema.Text("why")}})
	if err != nil || !r.Accepted {
		t.Fatalf("valid input: %+v %v", r, err)
	}
	if _, err = s.Run(ctx, runtime.RunOptions{MaxSteps: 20, MaxDispatch: 20}); err != nil {
		t.Fatal(err)
	}
	if err = s.Close(); err != nil {
		t.Fatal(err)
	}
	replay, err := runtime.Replay(ctx, path, runtime.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	if len(replay.Runs) != 1 || replay.Runs[0].Projection.Status != "succeeded" {
		t.Fatalf("replay: %+v", replay)
	}
}

func TestRuntimeValidatesInitialAndFinalSchemas(t *testing.T) {
	ctx := context.Background()
	a, err := author.Compile(author.Definition{Inputs: schema.Record{"text": {Kind: "string", MaxBytes: 10}}, Outputs: schema.Record{"answer": {Kind: "string", MaxBytes: 2}}, Steps: []author.Step{author.Set("answer", author.Var("text")), author.Success()}})
	if err != nil {
		t.Fatal(err)
	}
	p, err := (author.Application{"worker": {Artifact: a, Inputs: map[string]schema.Value{"text": schema.Text("long")}}}).Provision()
	if err != nil {
		t.Fatal(err)
	}
	s, err := runtime.Create(ctx, filepath.Join(t.TempDir(), "output.db"), p, runtime.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	if _, err = s.Run(ctx, runtime.RunOptions{MaxSteps: 20, MaxDispatch: 20}); err == nil {
		t.Fatal("oversized success output accepted")
	}
	p.Runs[0].Projection.Data["text"] = schema.Int(2)
	if bad, err := runtime.Create(ctx, filepath.Join(t.TempDir(), "initial.db"), p, runtime.DefaultLimits()); err == nil {
		bad.Close()
		t.Fatal("raw provision bypassed initial schema")
	}
}

func TestRuntimeAuthoredControlPaths(t *testing.T) {
	for _, tt := range []struct {
		name   string
		choose bool
		want   int64
		status string
	}{{"then", true, 2, "succeeded"}, {"else", false, 9, "failed"}} {
		t.Run(tt.name, func(t *testing.T) {
			a, err := author.Compile(author.Definition{Values: map[string]schema.Value{"count": schema.Int(0)}, Steps: []author.Step{
				author.Repeat(0, author.Add("count", author.Var("count"), author.Integer(100))),
				author.Repeat(5, author.Add("count", author.Var("count"), author.Integer(1)), author.IfEqual(author.Var("count"), author.Integer(2), []author.Step{author.Goto("done")}, nil)),
				author.Label("done"), author.IfEqual(author.Boolean(tt.choose), author.Boolean(true), []author.Step{author.Success()}, []author.Step{author.Set("count", author.Integer(9)), author.Failure()}),
			}})
			if err != nil {
				t.Fatal(err)
			}
			p, err := (author.Application{"worker": {Artifact: a}}).Provision()
			if err != nil {
				t.Fatal(err)
			}
			path := filepath.Join(t.TempDir(), "control.db")
			ctx := context.Background()
			s, err := runtime.Create(ctx, path, p, runtime.DefaultLimits())
			if err != nil {
				t.Fatal(err)
			}
			if _, err = s.Run(ctx, runtime.RunOptions{MaxSteps: 100, MaxDispatch: 100}); err != nil {
				s.Close()
				t.Fatal(err)
			}
			if err = s.Close(); err != nil {
				t.Fatal(err)
			}
			replay, err := runtime.Replay(ctx, path, runtime.DefaultLimits())
			if err != nil {
				t.Fatal(err)
			}
			got := replay.Runs[0].Projection
			if got.Status != tt.status || got.Data["count"].Number != tt.want {
				t.Fatalf("got %+v, want %s count=%d", got, tt.status, tt.want)
			}
		})
	}
}
