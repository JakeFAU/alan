package effectfulcomposition

import "testing"

func TestEveryProfile(t *testing.T) {
	for _, p := range Profiles() {
		t.Run(p.Name, func(t *testing.T) {
			g := Explore(p)
			if err := Check(g); err != nil {
				t.Fatal(err)
			}
		})
	}
}
