package author_test

import (
	"context"
	"fmt"
	"path/filepath"
	"testing"

	"github.com/JakeFAU/alan/author"
	"github.com/JakeFAU/alan/effects"
	"github.com/JakeFAU/alan/runtime"
	"github.com/JakeFAU/alan/schema"
)

// The local control has no external world. It deliberately leaves both original
// requests unresolved, so an invocation reply cannot supply the tested identity.
type unresolvedHandoffEffect struct{}

func (unresolvedHandoffEffect) Prepare(r effects.Request) (effects.Prepared, error) {
	return effects.Prepared{Request: r, Protocol: "test/unknown", MaxResponseBytes: 256}, nil
}
func (unresolvedHandoffEffect) Execute(_ context.Context, p effects.Prepared) effects.Candidate {
	return effects.Candidate{ID: p.Request.ID, Key: p.Request.Key, Disposition: "unknown"}
}

type handoffBuilder func(author.Application, string, string, runtime.InvocationHandoff) (author.Template, error)
type handoffEdge struct {
	name, port, ob string
	at             int64
	build          handoffBuilder
}

func pairedHandoffProvision(t *testing.T, edges []handoffEdge) (runtime.Provision, error) {
	t.Helper()
	target := schema.Record{"target": {Kind: "string", MaxBytes: 1024}}
	parent := runtime.RunID{Subject: "owner", Generation: 1}
	ports := map[string]author.Port{}
	invocations := map[string]author.Template{}
	var calls, dialogue []author.Step
	var templates []string
	for _, e := range edges {
		port := author.Port{Peer: "caller", Obligation: e.ob, Send: target, Receive: target}
		child, err := author.Compile(author.Definition{Ports: map[string]author.Port{"entry": {Peer: "caller", Obligation: "issue"}, "handoff": port}, Effects: map[string]author.Effect{"original": {Capability: "unknown", Input: schema.Record{}, Output: schema.Record{}}}, Steps: []author.Step{
			author.Receive("entry", nil), author.Request("original_id", "original", nil, nil),
			author.Send("handoff", map[string]author.Expr{"target": author.Var("original_id")}),
			author.Receive("handoff", map[string]string{"target": "selected_ack"}), author.Send("entry", nil), author.Success(),
		}})
		if err != nil {
			return runtime.Provision{}, err
		}
		h := runtime.InvocationHandoff{Caller: parent, Sequence: e.at, CallerPort: e.port, EntryPort: "handoff"}
		template, err := e.build(author.Application{"source": {Artifact: child, Inputs: map[string]schema.Value{}}}, "source", "entry", h)
		if err != nil {
			return runtime.Provision{}, err
		}
		port.Peer = runtime.HandoffPeer
		ports[e.port] = port
		invocations[e.name] = template
		templates = append(templates, template.ID())
		calls = append(calls, author.Invoke("call_"+e.name, e.name, nil, nil))
		dialogue = append(dialogue, author.Receive(e.port, map[string]string{"target": "id_" + e.name}), author.Send(e.port, map[string]author.Expr{"target": author.Var("id_" + e.name)}))
	}
	// Waiting for the first actual outcome intentionally keeps the parent open.
	steps := append(calls, dialogue...)
	steps = append(steps, author.AwaitInvocation(edges[0].name, "call_"+edges[0].name, author.InvocationOutcomeBindings{Status: "status", Reason: "reason", ResponsePresent: "present"}), author.Success())
	p, err := author.Compile(author.Definition{Ports: ports, Invocations: invocations, Steps: steps})
	if err != nil {
		return runtime.Provision{}, err
	}
	provision, err := (author.Application{"owner": {Artifact: p}}).Provision()
	if err != nil {
		return provision, err
	}
	provision.Composition.Roots = []runtime.ResourceRoot{{Run: parent, Members: []runtime.RunID{parent}, Templates: templates, Capabilities: []string{"unknown"}, Limits: runtime.ResourceLimits{MaxInvocations: 2, MaxCreatedRuns: 2, MaxEffects: 2, MaxInFlight: 1, MaxDepth: 1}}}
	return provision, nil
}

func TestPhase2DPublicPairedHandoff(t *testing.T) {
	edges := []handoffEdge{{"left", "left_id", "left_identity", 1, author.NewHandoffTemplate}, {"right", "right_id", "right_identity", 2, author.NewHandoffTemplate}}
	p, err := pairedHandoffProvision(t, edges)
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "pair.sqlite")
	s, err := runtime.Create(t.Context(), path, p, runtime.DefaultLimits())
	if err != nil {
		t.Fatal("public two-edge Create:", err)
	}
	defer s.Close()
	_, err = s.Run(t.Context(), runtime.RunOptions{MaxSteps: 100, MaxDispatch: 100, MaxInFlight: 1, Adapters: map[string]effects.Adapter{"unknown": unresolvedHandoffEffect{}}})
	if err != nil {
		t.Fatal(err)
	}
	parent, err := s.Snapshot(t.Context(), runtime.RunID{Subject: "owner", Generation: 1})
	if err != nil {
		t.Fatal(err)
	}
	ids := map[string]bool{}
	for _, e := range edges {
		call := parent.Projection.Data["call_"+e.name].Text
		a, err := s.AdmitInvocation(t.Context(), call)
		if err != nil || !a.Accepted || len(a.Members) != 1 {
			t.Fatal(a, err)
		}
		child, err := s.Snapshot(t.Context(), a.Members[0])
		if err != nil {
			t.Fatal(err)
		}
		id := child.Projection.Data["original_id"].Text
		if id == "" || ids[id] || parent.Projection.Data["id_"+e.name].Text != id || child.Projection.Data["selected_ack"].Text != id || child.Projection.Status != "succeeded" {
			t.Fatalf("invalid %s handoff: %s / %s", e.name, id, fmt.Sprint(child))
		}
		ids[id] = true
		join, err := s.PrepareInvocation(t.Context(), call)
		if err != nil || join.Ready || join.Pending != "external_outcome" || len(join.Freeze.ExternalIntents) != 1 || join.Freeze.ExternalIntents[0] != id {
			t.Fatal(join, err)
		}
		t.Log(e.name, call, id, child.Projection.Data["selected_ack"].Text, join.Pending)
	}
	if _, err = runtime.Replay(t.Context(), path, runtime.DefaultLimits()); err != nil {
		t.Fatal(err)
	}
}
