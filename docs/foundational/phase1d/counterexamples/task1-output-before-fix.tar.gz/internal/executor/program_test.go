package executor

import (
	"errors"
	"testing"
)

func TestReducerFiniteGenericWork(t *testing.T) {
	p := Program{Semantics: SemanticVersion, Code: []Instruction{
		{Op: "set", Dst: "budget", A: Lit(Int(1000))},
		{Op: "emit", Dst: "pending", Effect: &Effect{Kind: "opaque-operation", Target: Lit(Text("worker")), Generation: Lit(Int(99)), Obligation: Lit(Text("ob-1")), Payload: map[string]Operand{"amount": Ref("budget")}}, Updates: map[string]Operand{"budget": Lit(Int(999))}},
		{Op: "jump", Target: 2},
	}}
	initial := Projection{Data: map[string]Value{}, Status: "open"}
	r, err := Reduce(p, initial, nil, RunID{"supervisor", 123}, 1, DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	if r.Projection.Data["budget"] != Int(1000) || initial.PC != 0 || len(initial.Data) != 0 {
		t.Fatalf("reduction mutated input or bounded ordinary integer: %+v", r)
	}
	r, err = Reduce(p, r.Projection, nil, RunID{"supervisor", 123}, 2, DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	if len(r.Intents) != 1 || r.Intents[0].Payload["amount"] != Int(1000) || r.Projection.Data["budget"] != Int(999) || r.Projection.Data["pending"] != Text(r.Intents[0].ID) {
		t.Fatalf("intent and ordinary reservation: %+v", r)
	}
	r, err = Reduce(p, r.Projection, nil, RunID{"supervisor", 123}, 3, DefaultLimits())
	if err != nil || r.Projection.PC != 2 {
		t.Fatalf("loop must yield after finite step: %+v %v", r, err)
	}
	limits := DefaultLimits()
	limits.MaxDataBytes = 1
	if _, err = Reduce(p, initial, nil, RunID{"supervisor", 123}, 1, limits); !errors.Is(err, ErrLimit) {
		t.Fatalf("want explicit limit, got %v", err)
	}
}

func TestReceiveExactCorrelationAndTerminal(t *testing.T) {
	p := Program{Semantics: SemanticVersion, Code: []Instruction{{Op: "receive", Match: &Match{Kind: "result", Provenance: "authority", Source: Lit(Text("worker")), Generation: Lit(Int(90)), Obligation: Lit(Text("ob")), Operation: Lit(Text("op"))}, Bind: map[string]string{"answer": "result"}}, {Op: "end", Outcome: "succeeded"}}}
	state := Projection{Data: map[string]Value{}, Status: "open"}
	obs := Observation{ID: "o1", Run: RunID{"inner", 50}, Kind: "result", Provenance: "authority", Source: "worker", SourceGeneration: 90, Obligation: "ob", Operation: "wrong", Payload: map[string]Value{"answer": Int(1000)}}
	if _, err := Reduce(p, state, &obs, obs.Run, 1, DefaultLimits()); !errors.Is(err, ErrIneligible) {
		t.Fatalf("wrong operation: %v", err)
	}
	obs.Operation = "op"
	r, err := Reduce(p, state, &obs, obs.Run, 1, DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	if r.Projection.Data["result"] != Int(1000) {
		t.Fatal(r)
	}
	r, err = Reduce(p, r.Projection, nil, obs.Run, 2, DefaultLimits())
	if err != nil || r.Projection.Status != "succeeded" {
		t.Fatalf("end: %+v %v", r, err)
	}
	if _, err = Reduce(p, r.Projection, nil, obs.Run, 3, DefaultLimits()); !errors.Is(err, ErrClosed) {
		t.Fatalf("closed run: %v", err)
	}
}

func TestEmitReservesArithmeticUpdateAtomically(t *testing.T) {
	delta := int64(1)
	p := Program{Semantics: SemanticVersion, Code: []Instruction{{Op: "emit", Dst: "pending", Effect: &Effect{Kind: "operation", Target: Lit(Text("target")), Generation: Lit(Int(999)), Obligation: Lit(Text("ob"))}, Updates: map[string]Operand{"spent": {Ref: "spent", Offset: &delta}}}, {Op: "end", Outcome: "failed"}}}
	initial := Projection{Status: "open", Data: map[string]Value{"spent": Int(900)}}
	r, err := Reduce(p, initial, nil, RunID{"arbitrary", 999}, 1, DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	if r.Projection.Data["spent"] != Int(901) || len(r.Intents) != 1 || initial.Data["spent"] != Int(900) {
		t.Fatalf("reservation %+v", r)
	}
	initial.Data["spent"] = Int(9223372036854775807)
	if _, err := Reduce(p, initial, nil, RunID{"arbitrary", 999}, 1, DefaultLimits()); !errors.Is(err, ErrLimit) {
		t.Fatalf("overflow must not commit: %v", err)
	}
}

func TestOrdinaryEndCannotClaimAuthorityOutcome(t *testing.T) {
	for _, outcome := range []string{"cancelled", "abandoned"} {
		t.Run(outcome, func(t *testing.T) {
			p := Program{Semantics: SemanticVersion, Code: []Instruction{{Op: "end", Outcome: outcome}}}
			if _, _, err := EncodeProgram(p); err == nil {
				t.Fatalf("ordinary program manufactured %s authority outcome", outcome)
			}
			if _, err := Reduce(p, Projection{Status: "open", Data: map[string]Value{}}, nil, RunID{"worker", 1}, 1, DefaultLimits()); err == nil {
				t.Fatal("reducer accepted authority outcome")
			}
		})
	}
}

func TestReceiveRejectsAmbiguousBinding(t *testing.T) {
	p := Program{Semantics: SemanticVersion, Code: []Instruction{{Op: "receive", Match: &Match{Kind: "input", Provenance: "input", Source: Lit(Text("sender")), Generation: Lit(Int(1)), Obligation: Lit(Text("")), Operation: Lit(Text(""))}, Bind: map[string]string{"left": "same", "right": "same"}}, {Op: "end", Outcome: "succeeded"}}}
	if _, _, err := EncodeProgram(p); err == nil {
		t.Fatal("multiple payload fields bind one destination with nondeterministic map order")
	}
}
