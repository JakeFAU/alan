package executor

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
)

const SemanticVersion = "alan/1d/v1"

var ErrLimit = errors.New("resource limit")
var ErrIneligible = errors.New("ineligible observation")
var ErrClosed = errors.New("closed run")

type Value struct {
	Kind   string
	Number int64
	Text   string
	Flag   bool
}

func Int(n int64) Value   { return Value{Kind: "int", Number: n} }
func Text(s string) Value { return Value{Kind: "string", Text: s} }

type Operand struct {
	Ref     string
	Literal *Value
	Offset  *int64
}

func Lit(v Value) Operand  { return Operand{Literal: &v} }
func Ref(s string) Operand { return Operand{Ref: s} }

type RunID struct {
	Subject    string
	Generation int64
}
type Program struct {
	Semantics string
	Code      []Instruction
}
type Instruction struct {
	Op                string
	Dst               string
	A, B              Operand
	Target, Otherwise int
	Match             *Match
	Bind              map[string]string
	Effect            *Effect
	Updates           map[string]Operand
	Outcome           string
}
type Match struct {
	Kind, Provenance                          string
	Source, Generation, Obligation, Operation Operand
}
type Effect struct {
	Kind                           string
	Target, Generation, Obligation Operand
	Payload                        map[string]Operand
}
type Projection struct {
	PC     int
	Data   map[string]Value
	Status string
}
type Observation struct {
	ID                       string
	Run                      RunID
	Kind, Provenance, Source string
	SourceGeneration         int64
	Obligation, Operation    string
	Payload                  map[string]Value
}
type Intent struct {
	ID           string
	Run          RunID
	Sequence     int64
	Ordinal      int
	Kind, Target string
	Generation   int64
	Obligation   string
	Payload      map[string]Value
}
type Reduction struct {
	Projection Projection
	Intents    []Intent
}
type Limits struct{ MaxProgramBytes, MaxDataBytes, MaxObservationBytes int }

func DefaultLimits() Limits { return Limits{1 << 20, 1 << 20, 1 << 20} }

var ErrVersion = errors.New("unsupported version")
var ErrCorrupt = errors.New("corrupt durable state")

// EncodeProgram retains exact canonical bytes separately from the semantic version.
func EncodeProgram(p Program) ([]byte, string, error) {
	if err := validateProgram(p); err != nil {
		return nil, "", err
	}
	b, err := json.Marshal(p)
	if err != nil {
		return nil, "", err
	}
	return b, programHash(b), nil
}
func programHash(b []byte) string { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }
func decode(b []byte, v any) error {
	d := json.NewDecoder(bytes.NewReader(b))
	d.DisallowUnknownFields()
	if err := d.Decode(v); err != nil {
		return err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return fmt.Errorf("trailing JSON: %w", ErrCorrupt)
	}
	return nil
}
func validateProgram(p Program) error {
	if p.Semantics != SemanticVersion {
		return ErrVersion
	}
	if len(p.Code) == 0 {
		return fmt.Errorf("empty program")
	}
	for i, in := range p.Code {
		switch in.Op {
		case "set", "add":
			if in.Dst == "" {
				return fmt.Errorf("instruction %d: empty destination", i)
			}
		case "branch", "jump":
			if in.Target < 0 || in.Target >= len(p.Code) || in.Op == "branch" && (in.Otherwise < 0 || in.Otherwise >= len(p.Code)) {
				return fmt.Errorf("instruction %d: invalid target", i)
			}
		case "receive":
			if in.Match == nil || in.Match.Kind == "" || in.Match.Provenance == "" {
				return fmt.Errorf("instruction %d: missing receive type/provenance", i)
			}

			seen := map[string]bool{}
			for field, dst := range in.Bind {
				if field == "" || dst == "" || seen[dst] {
					return fmt.Errorf("instruction %d: ambiguous or empty receive binding", i)
				}
				seen[dst] = true
			}
		case "emit":
			if in.Effect == nil || in.Effect.Kind == "" {
				return fmt.Errorf("instruction %d: missing effect", i)
			}
		case "end":
			if in.Outcome != "succeeded" && in.Outcome != "failed" {
				return fmt.Errorf("instruction %d: invalid outcome", i)
			}
		default:
			return fmt.Errorf("instruction %d: unknown opcode %q", i, in.Op)
		}
	}
	return nil
}
func validValue(v Value) bool {
	switch v.Kind {
	case "int":
		return v.Text == "" && !v.Flag
	case "string":
		return v.Number == 0 && !v.Flag
	case "bool":
		return v.Number == 0 && v.Text == ""
	}
	return false
}
func eval(o Operand, data map[string]Value) (Value, error) {
	if (o.Ref == "") == (o.Literal == nil) {
		return Value{}, fmt.Errorf("operand must have exactly one reference or literal")
	}
	var v Value
	if o.Ref != "" {
		var ok bool
		v, ok = data[o.Ref]
		if !ok || !validValue(v) {
			return Value{}, fmt.Errorf("missing or invalid data %q", o.Ref)
		}
	} else {
		v = *o.Literal
		if !validValue(v) {
			return Value{}, fmt.Errorf("invalid literal")
		}
	}
	if o.Offset != nil {
		if v.Kind != "int" {
			return Value{}, fmt.Errorf("offset requires integer")
		}
		b := *o.Offset
		a := v.Number
		if b > 0 && a > math.MaxInt64-b || b < 0 && a < math.MinInt64-b {
			return Value{}, fmt.Errorf("integer overflow: %w", ErrLimit)
		}
		v.Number += b
	}
	return v, nil
}
func stringOperand(o Operand, d map[string]Value) (string, error) {
	v, e := eval(o, d)
	if e != nil {
		return "", e
	}
	if v.Kind != "string" {
		return "", fmt.Errorf("expected string")
	}
	return v.Text, nil
}
func intOperand(o Operand, d map[string]Value) (int64, error) {
	v, e := eval(o, d)
	if e != nil {
		return 0, e
	}
	if v.Kind != "int" {
		return 0, fmt.Errorf("expected int")
	}
	return v.Number, nil
}
func checkSize(v any, max int) error {
	if max <= 0 {
		return ErrLimit
	}
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	if len(b) > max {
		return ErrLimit
	}
	return nil
}
func validateProjection(s Projection, p Program, l Limits) error {
	if s.PC < 0 || s.PC >= len(p.Code) {
		return fmt.Errorf("invalid program counter")
	}
	switch s.Status {
	case "open", "succeeded", "failed", "abandoned", "cancelled":
	default:
		return fmt.Errorf("invalid status")
	}
	if s.Data == nil {
		return fmt.Errorf("missing data")
	}
	for k, v := range s.Data {
		if k == "" || !validValue(v) {
			return fmt.Errorf("invalid data")
		}
	}
	return checkSize(s, l.MaxDataBytes)
}

// Reduce is pure and performs exactly one finite instruction. Effects are descriptors,
// never callbacks; all loops yield to a subsequent durable execution commit.
func Reduce(p Program, s Projection, o *Observation, id RunID, seq int64, l Limits) (Reduction, error) {
	if err := validateProgram(p); err != nil {
		return Reduction{}, err
	}
	if err := checkSize(p, l.MaxProgramBytes); err != nil {
		return Reduction{}, err
	}
	if err := validateProjection(s, p, l); err != nil {
		return Reduction{}, err
	}
	if s.Status != "open" {
		return Reduction{}, ErrClosed
	}
	if id.Subject == "" || id.Generation <= 0 || seq <= 0 {
		return Reduction{}, fmt.Errorf("invalid execution identity")
	}
	in := p.Code[s.PC]
	if in.Op != "receive" && o != nil {
		return Reduction{}, ErrIneligible
	}
	next := Projection{PC: s.PC + 1, Status: s.Status, Data: make(map[string]Value, len(s.Data))}
	for k, v := range s.Data {
		next.Data[k] = v
	}
	result := Reduction{Projection: next, Intents: []Intent{}}
	switch in.Op {
	case "set":
		v, err := eval(in.A, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		next.Data[in.Dst] = v
	case "add":
		a, err := intOperand(in.A, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		b, err := intOperand(in.B, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		if b > 0 && a > math.MaxInt64-b || b < 0 && a < math.MinInt64-b {
			return Reduction{}, fmt.Errorf("integer overflow: %w", ErrLimit)
		}
		next.Data[in.Dst] = Int(a + b)
	case "branch":
		a, err := eval(in.A, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		b, err := eval(in.B, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		next.PC = in.Otherwise
		if a == b {
			next.PC = in.Target
		}
	case "jump":
		next.PC = in.Target
	case "receive":
		if o == nil || o.Run != id {
			return Reduction{}, ErrIneligible
		}
		if err := checkSize(o, l.MaxObservationBytes); err != nil {
			return Reduction{}, err
		}
		m := in.Match
		source, err := stringOperand(m.Source, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		gen, err := intOperand(m.Generation, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		ob, err := stringOperand(m.Obligation, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		op, err := stringOperand(m.Operation, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		if o.Kind != m.Kind || o.Provenance != m.Provenance || o.Source != source || o.SourceGeneration != gen || o.Obligation != ob || o.Operation != op {
			return Reduction{}, ErrIneligible
		}
		for field, dst := range in.Bind {
			v, ok := o.Payload[field]
			if !ok || dst == "" || !validValue(v) {
				return Reduction{}, fmt.Errorf("invalid receive binding %q", field)
			}
			next.Data[dst] = v
		}
	case "emit":
		e := in.Effect
		target, err := stringOperand(e.Target, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		gen, err := intOperand(e.Generation, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		ob, err := stringOperand(e.Obligation, s.Data)
		if err != nil {
			return Reduction{}, err
		}
		key, _ := json.Marshal([]any{id.Subject, id.Generation, seq, 0})
		intent := Intent{ID: string(key), Run: id, Sequence: seq, Ordinal: 0, Kind: e.Kind, Target: target, Generation: gen, Obligation: ob, Payload: map[string]Value{}}
		for k, v := range e.Payload {
			x, err := eval(v, s.Data)
			if err != nil {
				return Reduction{}, err
			}
			intent.Payload[k] = x
		}
		for k, v := range in.Updates {
			if k == "" || k == in.Dst {
				return Reduction{}, fmt.Errorf("invalid update destination")
			}
			x, err := eval(v, s.Data)
			if err != nil {
				return Reduction{}, err
			}
			next.Data[k] = x
		}
		if in.Dst != "" {
			next.Data[in.Dst] = Text(intent.ID)
		}
		result.Intents = append(result.Intents, intent)
	case "end":
		next.PC = s.PC
		next.Status = in.Outcome
	}
	if err := validateProjection(next, p, l); err != nil {
		return Reduction{}, err
	}
	result.Projection = next
	return result, nil
}
