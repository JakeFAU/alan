package fixture

import (
	"context"
	"errors"
	"path/filepath"
	"testing"
)

func TestDurableResourceRetainsKeyParametersAndOriginalReceipt(t *testing.T) {
	path := filepath.Join(t.TempDir(), "resource.sqlite")
	r, err := Open(context.Background(), path, "process-one")
	if err != nil {
		t.Fatal(err)
	}
	request := Request{Key: "operation", Profile: "idempotent", Delta: 7}
	first, err := r.Apply(t.Context(), request)
	if err != nil {
		t.Fatal(err)
	}
	if first.Total != 7 || first.Mutation != 1 || first.Process != "process-one" {
		t.Fatal(first)
	}
	r.Close()
	r, err = Open(t.Context(), path, "process-two")
	if err != nil {
		t.Fatal(err)
	}
	defer r.Close()
	second, err := r.Apply(t.Context(), request)
	if err != nil || second != first {
		t.Fatalf("changed original receipt: %+v %v", second, err)
	}
	request.Delta = 8
	if _, err = r.Apply(t.Context(), request); !errors.Is(err, ErrConflict) {
		t.Fatal(err)
	}
	snapshot, err := Inspect(t.Context(), path)
	if err != nil {
		t.Fatal(err)
	}
	if len(snapshot.Applications) != 1 || snapshot.Total != 7 {
		t.Fatal(snapshot)
	}
}
func TestNonIdempotentUnsafeRepetitionIsTwoApplications(t *testing.T) {
	path := filepath.Join(t.TempDir(), "resource.sqlite")
	r, err := Open(t.Context(), path, "unsafe-experiment")
	if err != nil {
		t.Fatal(err)
	}
	defer r.Close()
	request := Request{Key: "same-key", Profile: "non-idempotent", Delta: 3}
	first, err := r.Apply(t.Context(), request)
	if err != nil {
		t.Fatal(err)
	}
	second, err := r.Apply(t.Context(), request)
	if err != nil {
		t.Fatal(err)
	}
	if first.Mutation != 1 || second.Mutation != 2 || second.Total != 6 {
		t.Fatalf("unsafe repetition not observable: %+v %+v", first, second)
	}
}
