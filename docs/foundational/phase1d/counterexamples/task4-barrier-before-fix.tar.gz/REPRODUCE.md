Original controller-oracle counterexample captured while Task4 was in progress. This is not a completed Phase1D implementation or a runtime safety violation. With the pinned Go toolchain/SQLite dependency available, run:

```sh
go test ./internal/durabletest -run "^TestReviewBarrierAcceptsWrongLogicalIdentity$" -count=1 -v
```

Expected failure logs that the original actual child.wait accepted gen2/epoch99/op-B/auth-B for expected gen1/epoch2/op-A/auth-A. The probe uses a pipe and a deliberately mismatched identity; it does not kill a process. Corrected controller regressions belong to the final source.
