package substitution
type Request struct {
	ID, Value int
	Mode      string
}

// Observation is a schema-independent retained fact. Operation and Parent must
// use one consistent identity mapping throughout a trace. Debit fields are deltas.
// Consumers must retain absence explicitly; zero values do not imply presence.
type Observation struct {
	Kind, Operation, Parent, Role string
	Request                       Request
	ID, Value                     int
	Status, Reason                string
	Present                       bool
	I, R, E                       int
}
