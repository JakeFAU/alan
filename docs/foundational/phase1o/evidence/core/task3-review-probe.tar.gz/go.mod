module task3review

go 1.27
