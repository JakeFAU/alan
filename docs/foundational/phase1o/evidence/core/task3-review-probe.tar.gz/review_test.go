package substitution
import "testing"
func TestTask3ReviewBoundaries(t *testing.T) {
 node := func(p string, d int, g string) weakNode { return weakNode{Projection:p,Demand:[3]int{d,d,0},Guards:g} }
 t.Run("nil-grammar",func(t *testing.T) {
  p:=weakProblem{X:weakFiniteGraph{Initial:[]string{"x0"},Nodes:map[string]weakNode{"x0":node("0",0,"g"),"x1":node("1",0,"g")},Edges:[]weakEdge{{ID:"A",From:"x0",To:"x1",Rule:"a"}}},K:weakFiniteGraph{Initial:[]string{"k0"},Nodes:map[string]weakNode{"k0":node("0",0,"g")}}}
  r:=checkWeakCertificate(p,weakCertificate{Pairs:[]weakPair{{X:"x0",K:"k0"}}})
  t.Logf("accepted=%t result=%+v",r.accepted(),r)
  if len(r.Input)==0 {t.Error("missing grammar must be input error, not acceptance")}
 })
 t.Run("silent-choice-endpoint-demand",func(t *testing.T) {
  p:=weakProblem{Demand:true,Guards:true,Rules:map[string]weakRule{"local":{Owner:"component",Semantic:"choose_local"},"a":{Owner:"component",Semantic:"reply",Word:[]Observation{{Kind:"a"}}}},X:weakFiniteGraph{Initial:[]string{"x0"},Nodes:map[string]weakNode{"x0":node("0",2,"g"),"x1":node("1",1,"g")},Edges:[]weakEdge{{ID:"A",From:"x0",To:"x1",Rule:"a"}}},K:weakFiniteGraph{Initial:[]string{"k0"},Nodes:map[string]weakNode{"k0":node("0",2,"g"),"kL":node("0",1,"g"),"k1":node("1",1,"g")},Edges:[]weakEdge{{ID:"L",From:"k0",To:"kL",Rule:"local"},{ID:"KA",From:"kL",To:"k1",Rule:"a"}}}}
  r:=checkWeakCertificate(p,weakCertificate{Pairs:[]weakPair{{X:"x0",K:"k0"},{X:"x1",K:"k1"}},Component:[]weakMatch{{Pair:weakPair{X:"x0",K:"k0"},Edge:"A",Path:[]string{"L","KA"},Direct:"KA"}}})
  t.Logf("accepted=%t result=%+v",r.accepted(),r)
  if !r.accepted()||len(r.Strong)!=0 {t.Error("equal endpoint demand and preserved current guards must pass named subset")}
 })
 t.Run("private-direct-strong-fields",func(t *testing.T) {
  p:=weakProblem{Demand:true,Guards:true,Rules:map[string]weakRule{"tau":{Owner:"component",Semantic:"private-calc",Private:true}},X:weakFiniteGraph{Initial:[]string{"x0"},Nodes:map[string]weakNode{"x0":node("0",2,"before"),"x1":node("0",1,"after")},Edges:[]weakEdge{{ID:"T",From:"x0",To:"x1",Rule:"tau"}}},K:weakFiniteGraph{Initial:[]string{"k0"},Nodes:map[string]weakNode{"k0":node("0",2,"before"),"k1":node("0",1,"after")},Edges:[]weakEdge{{ID:"KT",From:"k0",To:"k1",Rule:"tau"}}}}
  r:=checkWeakCertificate(p,weakCertificate{Pairs:[]weakPair{{X:"x0",K:"k0"},{X:"x1",K:"k1"}},Component:[]weakMatch{{Pair:weakPair{X:"x0",K:"k0"},Edge:"T",Path:[]string{"KT"},Direct:"KT"}}})
  t.Logf("accepted=%t result=%+v",r.accepted(),r)
  if len(r.Input)==0&&len(r.Transfer)==0&&len(r.Strong)==0 {t.Error("Direct cannot exempt genuine private steps from preserving selected public fields")}
 })
}
