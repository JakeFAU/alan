# Binding Phase 1O constraints

ALAN Phase 1O — Weak Refinement and the Callable-Join Rule Implementation Plan
For agentic workers: Execute this research assignment task by task. Use subagent-driven development or plan execution skills where available. Parallelize independent lemma attempts and adversarial review after their common definitions are frozen; keep dependent acceptance gates sequential.

Goal: Determine whether unchanged K1 weak refinement supplies the stronger local relation needed by Phase 1N's callable-join rule, or identify the exact obstruction.

Architecture: Hold K1, J, O, original components, semantic allowances and production semantics fixed. First formalize and audit the missing implication; then use only the finite relation machinery, candidate experiments and public executions needed to resolve its uncertain steps.

Tech stack: Existing Go research infrastructure, finite transition systems, explicit relation/progress certificates, and the current public authoring/runtime API when a concrete witness is justified. Use pinned repository dependencies.

Spec: This approved brief; unchanged Phase 1I K1; and Phase 1N's final ARG-1/ARG-2 disposition. Historical freezes and later qualification remain separately identified.

Work in JakeFAU/alan. Carry the work through independent review, scoped manuscript reconciliation and a reviewed draft PR. This is an execution assignment; do not return only a plan. Make routine research and implementation decisions autonomously.

The question is:
Does the existing K1 refinement contract already provide the information required by the callable-join rule, or is an additional locally checkable condition needed?

The objective is a justified answer. A proof, a precisely classified negative, or a demonstrated specification gap can each be useful. A failed guessed proof, rejected candidate or exhausted heuristic is not by itself a completed answer.
1. Baseline and global constraints
PR25 is merged at 42c837f545ae60676935c3f46e38d17d98f009df; the reviewed delivery head is 765226b88edd65536586cb06c4df3f53c85c4390. Verify current main, ancestry, applicable AGENTS.md instructions and unrelated work. Use an isolated branch/worktree or a verified clean existing worktree.

Read narrowly:
- docs/foundational/phase1i/01-substitution-contract.md, especially its separately checked local relation, event semantics, entitlement and progress clauses.
- docs/foundational/phase1n/01-contract.md, 02-lifting.md, 03-qualification.md, 05-decisions.md, and 06-review.md.
- docs/foundational/phase1n/evidence/reviews/reference-r1.md: its final ARG-1 statement and ARG-2 disposition are more precise than the earlier construction-freeze wording.
- research/substitution/model.go, candidates.go, relation.go, and the relevant callable_join*.go projection, relation and progress code.
- The exact production ownership/binding/authorization rules needed by an attempted lemma. Read public construction/raw mapping only when correspondence requires it.
Phase 1N established bounded nested preservation and a reviewed conditional constructor argument. It did not establish ARG-2. Its A/B checkers use a particular private-state-erasure relation with single-event matching; they do not search all weak relations.

Preserve:
- Original K1, A/B/helper/S, J/O construction and policies, and historical evidence.
- Production compiler, executor, schema semantics, scheduler, accounting and dependencies.
- I=R4, depth3, E0, fixed1 for the full J/O profile; J's prior debit1 and original S's sole independently timed debit.
- Stable identity/authority/bindings, the declared open eligible caller, no retirement/cancellation in the positive composition profile, no pending release, and eventual eligible service.
- PR19 formatting, PR20 mathematics, and the distinction between asymmetric refinement and symmetric exact-debit equivalence.
No new sibling, deeper tree, reporting protocol, effect, recovery matrix, production repair or generic context generator is part of this phase. Correct ordinary new proof/checker/example mistakes without changing the claim being tested. An exact historical defect must be preserved and reported, not silently repaired into the premise.

Do not merge, release, make paid provider calls or send messages to people.
File responsibilities
Location	Purpose
docs/foundational/phase1o/01-weak-contract.md	Frozen interpretation, candidate/domain boundaries, ownership and event visibility
docs/foundational/phase1o/02-arg2.md	Quantified claim, premise provenance, three bridge arguments and exact remaining gaps
Additive research/substitution/weak_refinement*.go and focused tests	Only necessary weak-relation, certificate, progress or finite-search machinery
Phase 1O qualification/runbook/review and compact evidence index	Actual results, certificates, searches, source identities and independent review
Optional separate public example and additive raw mapping	A justified independently authored witness, only after the realizability gate
Existing manuscript Markdown/TeX	Reconcile the resulting claim and limits at phase end


Follow existing naming conventions where appropriate. Do not modify the old eventwise checker to make it appear to have always checked arbitrary weak refinement. A documentation/proof-led result does not require a new solver or runtime package merely to fill this table.
Review focus
Keep five risks visible: silently strengthening K1; confusing one failed witness with nonexistence; moving between local-profile and full-contract quantifiers; inventing impossible authorization histories or candidate powers; and inferring progress from safety or a bounded search.


Controller execution: exact task briefs carry their own requirements. No worker commits, pushes, merges, renders, modifies historical sources, or spawns subagents. Controller owns final review packaging, scoped commits, one end-of-phase PDF build and draft PR. All work uses this explicit worktree. Use focused checks only; preserve outcomes and exact identities. Do not write evidence requiring the live manuscript to equal a historical checkout.
