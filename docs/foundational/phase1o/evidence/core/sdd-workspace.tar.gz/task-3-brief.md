## Task 3 — Build only the finite machinery needed by the unresolved argument
- [ ] Freeze any new checker semantics and independently justified tiny fixtures before accepting search results.
- [ ] Implement separate witness validation and, only where needed, a complete finite existence procedure.
- [ ] Validate counterexample/certificate reporting and incomplete-search behavior.
- [ ] Declare the finite candidate/search domain before running it; preserve all attempted classifications.
The existing CheckLocalRelation and CheckCallableJoinLifting remain historical eventwise witnesses. A new weak checker must implement the frozen weak clauses, not call the old checker under a new name.

Keep two interfaces conceptually distinct:
- Witness validation: accept or reject a supplied relation and its matching paths, giving the exact failed obligation.
- Existence checking: establish EXISTS with a checked witness, NONE with a checked exclusion argument, or INCOMPLETE when the declared relation class was not exhaustively decided.
Malformed inputs or submitted authorization histories falsely claimed to be legally reachable are input/certificate errors. They are not semantic counterexamples. A finite graph may contain harmless unreachable nodes; obligations begin from its legal initial states.

For a claimed NONE result, justify completeness for the declared finite graphs and relation class. A suitable greatest-fixed-point or simulation-game procedure may be enough; a new generic verification framework or external solver dependency is not required. A negative certificate may be branching rather than a single linear trace.

Permit all admissible alternative paths and pairs. Derive any sufficient weak-path bound from the finite semantics. A timeout, arbitrary path/state cap, greedy mismatch or failed canonical erasure is INCOMPLETE or a rejected witness, never proof of nonexistence.

Certificate validation should be independent of the search algorithm. A second copy of the same algorithm is weak evidence. Freeze expected outcomes for a small independently understood fixture set, including:
1. A valid noncanonical relation with alternative matching paths.
2. Missing bilateral environment readiness despite agreeing outputs.
3. A private divergent cycle with a safety witness but failed progress.
4. An extra visible event incorrectly treated as a private stutter.
5. A submitted authorization history claimed reachable but inconsistent with legal transition provenance, rejected as an invalid certificate.
These qualify the machinery; they need not be publicly authorable ALAN candidates. Do not predetermine a disputed guard case's answer before resolving its semantic interpretation.
Candidate experiments
Use a small declared family of independent private-state encodings, instruction splitting/grouping or private calculations near the unresolved boundary. Keep the original e/helper operation vocabulary, requests, effects and allowances.

Sharing a fixed protocol kernel is legitimate when established as a rule of the original candidate domain. Document what the kernel guarantees. A generator that inherits ARG-1 readiness or guard stability by construction cannot establish that those properties follow from a weaker premise.

In particular, CandidateGraph currently filters shared Successors transitions. Merely extending A/B with more private PCs may be a useful positive control but provides little evidence about the missing implication. Prefer a nontrivial relation over independently represented private state when an experiment is needed.

For every purported witness, record separately:
- admissibility and exact environment/input scope;
- original weak conformance and its explicit witness;
- separate readiness/progress results;
- strong-certificate existence, nonexistence or incompleteness;
- any subsequent frozen-J behavior.
Use a new candidate-parametric composition adapter only if needed. It must retain frozen J/O semantics and justify its mapping. Check its K1/A/B instances against the existing products before trusting new-candidate failures. An adapter defect is not a substitution counterexample.
