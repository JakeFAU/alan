# Phase 1O — ARG-2 bridge argument

Status: **DONE_WITH_CONCERNS — integrated source argument submitted for independent
semantic review**. Under the declared A_op domain, W's original joint branch/
ticket transition legality, separate Progress and E_N, the proposed derivation
closes ARG-2 for all frozen F/P readings. This is not a machine-checked result,
compiler theorem, new qualification run, candidate acceptance or phase-completion
verdict. Independent review must challenge the accounting interpretation and
history-indexed all-successor construction, rather than infer approval from
agreement between the two independently frozen follow-up attempts.

Definitions, domain boundaries and visibility/projection names are frozen in
[01-weak-contract](01-weak-contract.md) (SHA-256
`ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`).
The inherited source base is `bec75fa3db8cdafb6295f3d0e8ebb619400c1f36`.
The final [Phase 1N ARG-1/ARG-2 disposition](../phase1n/evidence/reviews/reference-r1.md)
controls the target; successful historical A/B eventwise checks are not the weak
premise or an arbitrary-relation search.

## 1. Quantified target and current disposition

For each stated interpretation sigma, the composition-relevant claim is

```text
forall X in A_op:
  (exists Rw. W_N^sigma(X,Rw)) and Progress_N(X)
    => exists Rg. ARG1Compatible_N(X,Rg), under E_N.
```

Rg need not extend a supplied Rw. It may use other reference pairs and paths.
At every included pair `(x,k)`, however, each X event must match a path **from
that k** ending in the same relation; either-side declared environment moves
require immediate counterparts and related successors. Nonfunctional relations
are permitted; separately favorable completed traces do not establish one.

D_N is the depth2/cap3/residual I=R3/q restriction of D_full. Restricting a
coherent full relation and its configuration-wise progress obligations supplies
the profile premise. A profile-only negative cannot refute the full-premise
implication. Composition uses E_N, with J's prior debit1, full I=R4, original S as
the sole q debit, stable authority/bindings, open eligible callers, no closure,
retirement or pending release, and adequate finite operational limits. Local
closure safety remains in W_N; this does not add closure to the composition
history class. See [K1](../phase1i/01-substitution-contract.md) §§Tickets and Local
relation and [N environment](../phase1n/01-contract.md) §Environment.

| Domain / reading | Integrated source argument submitted here | Remaining qualification |
| --- | --- | --- |
| A_op, P_stage, either F | A supplies endpoint demand and stable weak paths; B supplies caller readiness; C extends legal authorization histories under E_N. | Independent semantic review; separate Progress_N and reference/product premises remain required. |
| A_op, F_event/P_boundary | Same chain, deriving logical demand from synchronized visible ticket histories rather than all-field equality. | Uses K's fixed logical-ticket update rules; no arbitrary private-control equality is inferred. Independent review remains required. |
| A_op, F_fact/P_boundary | A constructs a fresh history-indexed demand-aligned relation from W's original joint ticket legality; B and C then supply caller and authorization transfer. | Independent review of the accounting premise and every-successor fork/merge argument; history annotations must not change X. |
| A_graph without owner framing | G_q below witnesses failure of local caller-readiness implication. | Outside A_op/A_pub; not a J contextual counterexample. |
| A_pub | The inspected API supports the fixed owner boundary. | No A_op=A_pub or general compiler/runtime correspondence theorem; any concrete witness needs its own mapping and bounds. |

The three A_op rows are proposed derivations, not independent ARG-2 acceptance.
The accounting laws used are already in W item 4, which imports K1 safety at all
prefixes, including its branch/ticket transitions; they are not added equality
with a supplied Rw. An ARG-1-compatible relation yields the conditional lifting
rule. K_join/G_outer preservation additionally uses the separately qualified
reference products; these bridge arguments do not establish that premise.

## 2. Bridge A: reference paths, current guards and exact demand

The fixed [reference reducer](../../../research/substitution/model.go) contains
no arbitrary hidden implementation. Every transition at lines 181–426 except
`choose_local`/`choose_helper` carries a mandatory ordered protocol fact:
commitment, exact admission/debit/request creation, request consumption, reply
commitment/disposition, terminal/freeze, publication, delivery, selection, pending
receive, q debit or closure. Preserve multiplicity, original identities, payload,
presence and exact reasons; terminal facts include successor Freeze even when
the coarse event Status is empty.

Under F_event, a fixed semantic event therefore matches that event alone, or a
candidate pure private step matches the empty path. Under F_fact, only a choice
may additionally be silent. At most one choice occurs in a local reference
execution: both leave `choose`, with no return rule. No hidden helper round trip,
early selection, extra debit or publication can be inserted to reach a convenient
endpoint. Accepted admission/debit/request creation and terminal/freeze keep their
original atomic groups. Runtime grouping of ordered model facts creates no new
durable interleaving inside a transaction.

For current J/protocol guards, retain original commitment/disposition predicates,
source terminal/closure, ledger/depth, request/reply/publication/delivery/selection
facts and fixed J/S/caller control. The guard rules are in
[model.go](../../../research/substitution/model.go) lines 138–177, 222–259,
331–423 and [invocation_join.go](../../../research/substitution/invocation_join.go)
lines 124–145, 174–225. Neither choice changes those facts. Excluding or enabling
a still-uncommitted helper changes a possible future candidate action; it does
not create an enabled helper authorization/admission. At the choice region,
entry input is consumed, e has no reply/freeze and h has no commitment. The only
independent local environment moves are q and closure, each commuting with
choice without changing its guards. Thus every allowed extra choice preserves
the relevant **current** constructor/protocol guards. Intermediates need not be
related endpoints, and their equality is not assumed.

Exact future demand is a separate requirement. K1 counts h until its contract
branch excludes it; commit costs zero, accepted admission transfers demand to
spent, refusal/exclusion removes only unrealizable demand, and no charge is
refunded. `choose_local` lowers future demand while preserving all those current
guards. A preserved prefix inequality is not equal demand between related states.
The frozen [weak-path definition](01-weak-contract.md) §7 says each stutter
preserves facts on which the relevant current constructor/protocol guard depends.
Together with [N R1](../phase1n/evidence/reviews/reference-r1.md) lines 148–155,
this is the source of the endpoint-demand/current-guard distinction used here.
Actual local exclusion is a semantic choice with a demand update, even when its
label is hidden; it is not asserted to preserve every raw projection field.
Review must check this reading of R1's “every guard listed here” condition rather
than silently replace it with either unrestricted stuttering or all-field
intermediate equality.

For P_stage, endpoint demand equality is already in W; retain Rw and its future
successors. For F_event/P_boundary, generate a subrelation from aligned initials
by coherent W-successor choices for every required move. Paired histories then
have the same complete event word, including choices. Fixed initial tickets and
K's deterministic ticket updates on that word give equal logical demand by
induction, without all-field private-state erasure. Both constructions preserve
future obligations because every chosen successor stays in the same relation.

For F_fact/P_boundary, silent exclusion breaks that shared-visible-history
induction. The two frozen demand follow-ups instead construct a new coherent
relation. They do not merely intersect Rw with equal-demand pairs.

### Existing joint accounting premise

W item 4 explicitly imports [K1 safety](../phase1i/01-substitution-contract.md),
including lines 44–49, 71–117 and 151–176. The account is a legal trajectory of
original tickets **jointly with original semantic actions**: e/h/q start with
the fixed demand; commitment changes possible to committed; acceptance spends
once; refusal excludes the original unspent ticket/subtree; local choice after
input consumption excludes h before the no-helper mode action. Chosen helper
selection precedes e's mode action. There is no resurrection or refund.
P_boundary relaxes equality with Rw's bookkeeping, not these own-history laws.

A mere monotone counter or `spent + demand <= limit` is insufficient. Nor is
demand defined as “some future machine execution invokes h”: even a local-only
program starts with h possible, and closure does not automatically erase
possible tickets. A stale private flag cannot replace the original logical
account. Evidence of an actual candidate's W4 conformance must establish these
existing laws; requiring that evidence does not add an ARG-1 relation premise.

The account may be explicit in the semantic state or interpreted along its
original causal history, without requiring a unique private-PC-to-account
function. Hidden choice remains an actual semantic accounting transition. Its
past is fixed, not reassigned after a future branch. If an already lawful action
abstraction contains that choice, preserve its fixed grouping; no new candidate
checkpoint, callback, observation or event fusion is introduced.

### Normalized relation and all-futures closure

From each original initial pair maintain (i) X's actual accounted history,
(ii) a current witness `(x,k)` in Rw, advanced from that k by W, and (iii) a
separately maintained reference execution g. The latter may leave Rw; it is not
reselected from scratch after seeing the next event.

| X's original accounted boundary | Maintained g |
| --- | --- |
| Before accepted e input consumption | Corresponding original entry/receive state and tickets; exact entry refusal excludes its subtree. |
| Input consumed, h possible and uncommitted, no e mode action | Reference `choose`, even if X or k has privately prepared/chosen helper. Both future branches remain available and demand is unchanged. |
| Actual lawful local exclusion of uncommitted h | Take `choose_local` at that accounting boundary; retain local mode through further private work. |
| Original h commitment while possible | Take `choose_helper`, then the same original commitment with its immutable payload/handle and zero debit. |
| Original h committed/admitted/refused/selected | Follow those exact mandatory facts; retain refusal separately from local exclusion and wait for original h selection before mode/failure. |
| Original mode action and later protocol | Match its prescribed fact and suffix; the original local/helper history has resolved the branch. |

Let Rg contain all resulting pairs across original initial configurations and
all legal X/environment histories. Retain history distinctions where needed.
The induction obligations apply to **every actual outgoing X edge from every
included history/pair**, not just the trace that generated it:

- Private work without accounting change leaves g unchanged, while its Rw
  witness advances as permitted. Tentative private branch flags do not force
  reference branch selection or semantic exclusion.
- Actual local exclusion is post-input and pre-mode, with no h commitment, so
  g can choose local. Every later helper commitment would resurrect an excluded
  ticket and violate W4 on that actual continuation. This supplies future
  compatibility without predicting X's eventual branch.
- Actual helper commitment requires h possible, so g can choose helper and
  perform it. A no-helper mode action requires local exclusion already present
  or included in that existing semantic abstraction, so g is at local mode or
  takes its adjacent choice. W supplies the exact mode/payload/terminal facts.
- After helper commitment or a mode fact, no silent branch ambiguity remains.
  The current Rw witness and g share mandatory histories; its match therefore
  transfers to the corresponding g region with the original ticket updates.
- Before branch resolution, q and closure commute with both choices. After
  commitment/reply/freeze, environment guards depend on mandatory facts shared
  by k and g. W's immediate bilateral counterpart is therefore available from
  g with the same X successor, exact debit/refusal and accounting update. No
  preparatory private step postpones service. Closure preserves its actual
  tickets; scarce entry/helper refusals remain exact, atomic cases.

**Forks.** If X retains legal local and helper futures while h is possible, g
stays at choose and supports both. An early local k that cannot support the
helper continuation is a bad supplied pair, not nonconformance of X when a
suitable other relation exists. Extra unchosen reference alternatives are
allowed by asymmetric refinement; the construction adds no choice to X.

**Merges.** If possible-h and excluded-h histories reach the same raw X state,
all outgoing X edges remain available on each history. A helper-commit edge
would violate W4 when appended to the excluded history, regardless of the other
history. The normalizer cannot hide that edge. If all continuations are legal,
the preceding cases work for both pairs. History indexing records original
semantic/accounting evidence; it neither filters transitions nor changes the
program, input or service obligations. Where the semantic projection is already
state-determined, ordinary state pairs suffice; otherwise the relation is on
those existing history-distinguished semantic states. This representation point
is an explicit independent-review obligation, not permission to repair X by
splitting a raw state and removing its inconvenient edges.

Initial equality and each synchronized ticket update give exact original U and
remaining cost at every Rg boundary. Each extra choice preserves current
constructor/protocol guards, while actual exclusion changes demand at its own
semantic boundary. Hence it is a matched choice, not a demand-preserving private
stutter. No admission/debit/create/request or terminal/freeze atomic group is
split, and the normalizer's sole choice is finished before e publication and
its delayed caller selection. Progress remains separate.

### Adverse attempts and what they establish

A concrete bad supplied witness illustrates the existential target. Add one
once-only private step after input consumption and before the ordinary local
branch; retain h possible at its two private boundaries u/v. Under
F_fact/P_boundary a weak Rw can anticipate `choose_local` in the request-consume
match, pair u/v with reference local mode, and match X's later lawful exclusion
by empty stutter. Its mandatory facts and environment readiness agree, but its
demand does not. Rg instead pairs u/v with choose and takes local choice at the
actual exclusion. The candidate is normalizable. Stronger readings reject the
premature witness, not that candidate with its normalized witness; no differing
candidate acceptance sets are demonstrated.

Keeping logical h possible after no-helper mode action, excluding it initially
because the program is local-only, excluding before input, or resurrecting it
after a state merge violates identified original accounting laws. A tentative
private intention is harmless; claiming an irreversible original helper choice
and then an unsupported semantic rollback is not. An added private cycle can
satisfy safety while violating separate Progress. An arbitrary q-written branch
or extra observation changes A_op's interface. These are precise dispositions,
not nonexistence conclusions from exhausted guesses. The earlier failed demand
induction and its uncertainty are preserved in the original independent report;
this construction supplies its missing step without changing the frozen contract.

## 3. Bridge B: caller framing and delayed selection

Owner framing is the independently declared A_op interface, not a consequence
of W's forward simulation. Original caller commitment/selection retain fixed
guards and updates; candidate-private instructions cannot modify them. For the
local caller, reachable original history determines the phase:

```text
closed                         -> cancelled; no commit/selection
open, e uncommitted             -> first original Invoke
open, e committed, unselected   -> original e Await
open, e selected               -> retained original envelope; ended
```

Initial construction and the sole commitment/selection/closure transitions
establish this invariant ([model.go](../../../research/substitution/model.go),
lines 106–143, 230–242, 375–423). Required commitment, delivery, selection and
closure facts therefore determine bilateral caller readiness under either P,
without requiring equality of scratch PCs. This applies on D_full and D_N.

W also forces the caller matches to be immediate. At entry commitment no member
exists; reaching a reference choice requires additional mandatory admission and
input consumption. Before original e selection, e is already refused or
frozen/published, and any chosen helper was consumed before its mode action.
No silent reference work remains at either caller position. The matching path
is the corresponding single caller transition, so W already relates its
immediate successors. By contrast, declared environment admission, reply,
publication, delivery, q and closure readiness is directly bilateral in W at
every private instruction boundary; a preparatory private step cannot postpone
it. `Environment=false` itself certifies neither ownership nor readiness.

J's common fixed phase adds its original input gate before e commitment and its
S-selection gate before e selection. For other events, monotone mandatory e
selected flags forbid an intermediate e selection on a path ending unselected.
For actual e selection, both sides already satisfy the common S gate, and its
match is immediate. Neither early reference selection nor substitution of
delivery for consumption is needed. The
[local projection](../../../research/substitution/callable_join_local.go) lines
10–38 intentionally has a scratch e Await while full J may still await S;
it does not claim the full e selection is already enabled.

### A_graph-only control: G_q

Without owner framing, define G_q as the original K1 graph with only
`outcome_consume(e)` removed whenever the original q debit is enabled. Identity
is a weak relation under every F/P reading: retained edges match identically,
and all declared environment edges remain immediate in both directions.

A reachable D_N answer/local prefix completes e through delivery before q.
The open caller awaits delivered unselected e, e has spent1 of residual3, and q
is still possible. Original K1 permits selection; G_q removes it. No alternative
ARG-1 relation can hide this: mandatory original facts force the same open Await
and delivered-unselected envelope in every related reference state.

Conditional on the reference's progress obligations, this deletion preserves
them on D_full and D_N. Whenever it removes selection, q remains an outgoing
edge; after q or exhaustion of its budget guard the deletion ceases permanently.
The graph introduces no cycle or new maximum, and eventual service does not
permit withholding continuously enabled q forever. With absent/ineligible q,
closure, or designated pending, there is no new blocked selection. This is an
analytic control, not a new executed qualification.

G_q is outside A_op because it changes the original caller guard, and no public
realization is claimed. It also does not break fixed J: by the time J may select
e, S has been selected and its accepted admission already spent q. Thus failure
of local ARG-1 readiness under A_graph is distinct from contextual failure.

## 4. Bridge C: all legal first-authorization histories

Under E_N, a coarse relation using the mandatory facts admits an authorization
extension over **history-distinguished augmented states**. For full J the lemma
is conditional on Bridges A/B supplying coarse constructor transfer. It is not
a theorem for all local closure/retirement histories or for graphs allowed to
inspect/mutate authorization records.

For every legal prefix h and original committed intent i, retain either no
first decision or its actual immutable first record A_h(i), tied to its original
commitment and source prefix. The normalized record preserves intent/operation,
kind/payload/source/target/obligation, generation-qualified source and committed
revision, original binding, revision/generation predicate results, historical
source-open/retired snapshot, disposition and exact reason. Equality is under
one fixed identity renaming; **each run retains its own raw immutable provenance**.
Raw source sequence/ordinal/epoch data is not rewritten to manufacture equal
SQL rows or step counts. See [Authority](../../../internal/executor/store.go)
lines 58–69, [Intent](../../../internal/executor/program.go) lines 80–88 and
[raw replay checks](../../../internal/executor/composition_replay.go) lines
494–526. A concrete runtime correspondence remains a separate obligation.

[AuthorizeIntent](../../../internal/executor/messages.go), lines 103–177, returns
an existing first row before consulting current source state. A new decision
requires its original commitment and no row, then checks revision and generation
before the source retirement/open tests. The original bound reply exception uses
[compositionReplyBinding](../../../internal/executor/invocation.go), lines
123–140; an invocation receives no such exception. Exact refusal reasons follow
the ordered rule, not an unordered Boolean formula.

Take all compatible **legal** history pairs whose coarse endpoints are related,
mandatory words/atomic groups align, first-authorization occurrences align, and
normalized retained records agree. Do not take a Cartesian product of arbitrary
pending/allowed/refused assignments on equal coarse states. The extension is
closed by induction from each already-related pair:

- A new first decision on either side has the same original commitment and row
  absence on the other. Equal source terminal facts and E_N's stable authority/
  binding give the same snapshot and ordered first result. Append it to both.
- A lookup returns the old corresponding record. A later End cannot recompute it.
- A coarse matched step uses the existing path from its current k. Extra choices
  preserve commitment/source facts. Actual commit or terminal changes occur in
  the same mandatory order, preserving captured prefixes and earlier decisions.
- Split admission requires the corresponding retained row on both sides and
  retains the existing current source/scope/depth/budget checks. Later service
  never resets the row; atomic transactions are not split for authorization.

This covers every legal candidate authorization schedule and every later
bilateral authorization from every included pair, including private instruction
boundaries. It selects neither a favorable order nor a new starting reference
state per event. Extra reference choices commute with authorization because
they preserve its particular predicates; this does not prove demand equality.

Let c/a/t/d denote bound reply commit/first authorize/End/admit. Both End statuses
permit `c;a;d;t`, `c;a;t;d` and `c;t;a;d`. Early authorization retains an open
snapshot; late first authorization retains a closed snapshot and uses the actual
binding exception. Prefixes `c;a;t`, `c;t;a` and unresolved `c;t` may share a
coarse state yet require different histories. J's failed End may retain its
present diagnostic; [freeze and publication](../../../internal/executor/invocation_outcome.go)
lines 220–288, 354–373, 426–440, 571–621 preserve that committed evidence.

First invocation authorization after source End instead refuses; an earlier
allowed row also does not waive later current admission guards. Such closed
source invocation schedules are not reachable for required original calls in a
W-conforming E_N composition: O stays open through J selection, J through e/S
selections, and e consumes its chosen helper before its mode action. Do not add
impossible refused dispositions to positive histories merely because the kernel
can represent them in another environment.

## 5. Progress and evidence limits

Progress_N is a separate all-mode/nondivergence premise. The bridge construction
adds at most one reference choice, and at most eight first decisions for the
fixed four possible invocations J/e/S/h and four replies. A decreasing count of
remaining first decisions excludes infinite **new authorization** steps; it is
not a private-program rank or runtime budget. Repeated lookups cannot justify
unfair withholding of required admission/service. Arbitrary private cycles
still need the candidate's own sound rank/SCC-equivalent certificate.

J's finite commitment prefix and original finite S path eventually open its
S-selection gate under E_N. Original entitlement prevents resource starvation;
S admission may occur before or after e admission without q priority. Delaying
e selection withholds no candidate input: e is frozen/refused before publication,
has no post-freeze component work, and has consumed a chosen helper before its
mode action. After the finite delay, the original service obligation resumes.
Answer/fail/absent follow their original envelopes and finite J/O suffixes.
Pending reaches the actual unmatched receive after required consumptions, with
S selected, J awaiting e and O awaiting J; no reply, freeze or release is invented.
Unfair service withholding, a private divergent cycle and designated pending are
distinct. Adequate concrete operational bounds remain a separate premise; the
historical rank or 512-step setting is not a uniform limit on arbitrary X.

## 6. Proposed conclusion, independent review and minimal validation

Combining A's coherent demand-aligned paths, B's fixed caller readiness and C's
legal authorization-history extension supplies the proposed existential
ARG1Compatible_N relation under A_op/W4/Progress_N/E_N for **all** frozen F/P
readings. A full local premise implies the profile premise by restriction. No
extra locally checked strengthening of K1 is needed **within this declared
operational domain and its already required joint accounting semantics**.
Forward word matching plus a scalar resource inequality alone would be a weaker,
different premise. A_graph's G_q control does not refute this result or show a
fixed-J contextual failure. A_op=A_pub, compiler correctness, arbitrary contexts,
distributed recovery and uniform runtime bounds remain unclaimed.

Independent semantic review must still assess:

1. W4 really imports the original joint branch/mode/ticket legality used above,
   rather than merely legal numerical values or the prefix budget inequality.
2. History indexing preserves X and checks every enabled continuation at merges;
   it does not add an unproved state-only map, choose a past per future trace,
   filter edges, or substitute a different candidate system.
3. Frozen §7's current-guard reading of N R1 clause2 permits the actual accounted
   choice while requiring equal endpoint demand. The proof does not show raw
   demand constant throughout every hidden choice. Environment successors,
   atomic groups, delayed selection, progress assumptions and authorization
   histories must remain coherent together, including late first bound replies.

No new tests, searches, public executions or qualification counts support this
source argument. Conditional Tasks3/4 need only targeted finite validations if
review accepts the derivation; there is no justified generic solver or candidate
campaign. The smallest useful instances are:

- The one-private-bit local toy above, on D_N answer `{id:1,value:0}`: explicitly
  check premature Rw and normalized Rg, h demand at u/v, and immediate q/closure
  interleavings. Add one unresolved local/helper fork to reject the premature
  local pair while validating choose; a merge-after-exclusion with a helper edge
  must fail W4 rather than be pruned. These check supplied finite certificates,
  not all possible relations. For the legal once-only toy, `2*Rank+b` is an
  analytical nondivergence certificate, not a public runtime cap.
- Exercise that same small legal construction's fail/absent/pending boundaries
  and original helper refusal so progress checks include actual required input/
  helper consumption, exact refusal and designated pending, not just outputs.
- One original J bound reply with `c;a;d;t`, `c;a;t;d`, `c;t;a;d` and both End
  statuses: retain the first snapshot, unresolved `c;t` prefix, and old result on
  post-End lookup. A kernel-only late-invocation check may contrast the exception
  but must not be called a positive-profile candidate counterexample.

These are finite clause/transcription instances, not whole-D_N conformance,
A_pub witnesses or proofs of the universal lemma. Implementation remains gated
on argument review. If a new weak checker is proposed, the task packet's five
independently expected machinery fixtures are required; these suggestions do not
waive that gate or commit to adding such a checker. Any public execution needs
an independently justified mapping and common operational bounds first. Manuscript
reconciliation and final phase qualification remain controller-owned after
independent review;
this source result is not a claim that those later obligations are complete.
