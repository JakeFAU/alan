# Phase 1O Task 2A — independent weak-path normalization attempt

Status: **partial source argument; no ARG-2 verdict and no negative candidate**.
Intermediate current-guard stability and delayed e-selection close for the fixed
reference graph. Exact endpoint demand alignment closes under P_stage (either F)
and under F_event by synchronized ticket histories. F_fact/P_boundary still
needs a coherent endpoint-demand normalization, not merely a path observation.

## Scope and exact quantifiers

Read first `task-2-brief.md`, then `constraints.md` and
`task-2-bridge-instructions.md`. Frozen definition:
`docs/foundational/phase1o/01-weak-contract.md`, SHA-256
`ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`.
Task1-r1/r2 approve that qualified definition gate, not ARG-2. HEAD checked:
`bec75fa3db8cdafb6295f3d0e8ebb619400c1f36`.

Let A_D(X,R) denote **only Bridge A's portion**: required endpoint facts and exact
future demand; ordered fixed atomic-event matching with current constructor/
protocol-guard-stable reference intermediates; and survival of delayed e
selection. Caller readiness (Bridge B), retained authorization history (Bridge C)
and Progress_D remain separate obligations. The target is

`forall X in A_op, (exists Rw. W_D^sigma(X,Rw)) and Progress_D(X)
 => exists Rg. A_D(X,Rg)`.

D_N is composition-relevant. Rg may replace supplied pairs and paths and need not
extend Rw. But at each retained pair, every enabled candidate event and each
required either-side environment event must have a successor in **one** coherent
relation. Choosing a new starting reference state separately for each future
trace is insufficient. The results use fixed K1 transitions/atomic boundaries
and A_op ownership, not an A_pub correspondence or unrestricted A_graph theorem.

## 1. Reference paths: exhaustive rule classification

In `model.go:181-426`, every reference transition except `choose_local` and
`choose_helper` changes a mandatory ordered fact: original commitment, exact
admission and its atomic debit/request creation, request consumption, reply
commitment/disposition, terminal/freeze, publication, delivery, selected
consumption, designated pending receive, q debit, or closure. Mandatory facts
include identities, payload, presence, exact status/reason and occurrences
(`01-weak-contract.md:165-171,186-240,312-335`).

* F_event: a path matching one fixed semantic event has that event alone after
  removal of genuine private stutters. K1 has no private-PC transitions. A pure
  candidate step with no visible fact matches the empty path. This deduction
  does not invoke the historical erasure/eventwise checker.
* F_fact: only the two choices at `model.go:274-287` can additionally disappear
  from the word. At most one occurs on a reference execution: both leave choose,
  and no rule returns to it. A matching path is a matched fixed event with at
  most that bookkeeping step before/after it, or a bookkeeping-only path for a
  candidate silent action.

This is at fixed contract atomic-event granularity. Accepted admission remains
one transition including charge, member creation and admitted request;
terminal/freeze remains one transition. Fixed runtime transactions containing
several ordered model facts remain fixed groups; no durable interleaving is
invented inside them. No arbitrary fusion/reordering of original actions is
licensed. An extra helper round trip cannot be hidden just because it returns
the same complement: its commitment, charge and consumption remain extra facts.

## 2. Intermediate guard preservation, not endpoint equality by assumption

Let Gamma contain the facts used by current fixed J/protocol guards: original
commitment/disposition predicates and payload/links; source freeze and root
closure; admission and request/reply stages; exact ledger and depth; publication,
delivery and selected flags; and fixed caller/S/J control in the product.
See `model.go:138-177,222-259,331-423` and
`invocation_join.go:124-145,174-225`. E_N fixes original identity/revision/
generation/binding; retained authorization histories remain Bridge C's task.

`choose_local` sets e Choice/PC and excludes the unused helper ticket.
`choose_helper` sets Choice/PC and enables the still-uncommitted helper. Neither
changes Gamma. Possible and excluded are both **not committed**, so neither
choice enables helper authorization/admission. Neither commits a reply, freezes
a source, spends resources or changes a selected flag. Helper local-commit
possibility changes; that is a candidate action, not an enabled J caller or
protocol-service action. The frozen definition requires intermediate preservation
of facts on which a current constructor/protocol guard depends, rather than
constancy of every candidate-local control value.

There is also a commuting argument for adverse environment interleavings at
this choice region. Entry input was consumed, helper is uncommitted, e has not
replied/frozen. Only q and closure can be independent local environment moves
there. Each choice commutes with either: their guards and ledger/closure updates
are unaffected, and neither environment move changes the local choice
precondition. No extra protocol event is required inside a matching path.
Closure remains a safety case, not a positive progress assumption.

Thus **every** allowed F_fact path preserves Gamma on each additional choice.
There is no guessed good path whose future compatibility is simply assumed.
Keep W's existing successor choices; this argument applies to every path used.
Intermediates need not themselves be related endpoints. This proves the
intermediate current-guard part for every frozen F/P reading **provided the
required endpoint facts are available**. Exact demand equality is separate.

## 3. Monotone retained facts versus optional-helper demand

Commit/consume, freeze/publication/delivery and q-spent facts are once-only;
dispositions/payloads are immutable once recorded, and spent I/R only increase.
A matched event may change them; extra reference choices cannot. Endpoint
agreement plus monotonicity rules out excursions, while mandatory ordered words
also prohibit extra occurrences. Net totals alone would not establish either.

Demand is different. K1 h begins possible, becomes committed/spent on the helper
branch, or excluded at local choice/refusal (`K:153-176`). Remaining possible/
committed demand never increases. Commitment is zero debit; admission transfers
one unit from future demand to spent; exclusion removes only unrealizable demand.
`choose_local` **changes exact future demand**, while preserving Gamma. The
prefix bound survives that decrease; its truth is not cross-side demand equality.
Demand is not an admission reservation: current spent/depth/open guards decide
admission. ARG-1 requires exact demand equality at related endpoints; its frozen
weak-path interpretation requires current guard dependencies at intermediates.
These are not interchangeable requirements.

Reading-specific endpoint results:

1. **P_stage, either F:** endpoint ticket/demand equality is explicit. Keep
   Rg=Rw for Bridge A. Section 2 discharges the extra intermediate condition.
   Pure candidate private steps cannot change this reading's public demand;
   an actual matched semantic choice may change it at its event boundary.
2. **F_event/P_boundary:** take the subrelation generated from aligned initial
   pairs by coherent choices of W successors for **every** required move. Each
   pair has a common complete event history, including visible choices. Initial
   logical tickets are fixed, and K's demand updates are deterministic on that
   history: commit, exact admit/refuse, local exclusion and q debit. Induction
   therefore gives equal logical demand without equating arbitrary scratch/PC
   fields. This uses K's rule that demand changes only by K1 ticket transitions,
   not a candidate-advertised counter. The generated relation includes every
   selected successor, not one completed trace.
3. **F_fact/P_boundary:** that induction stops at silent local exclusion. The
   weak projection need not compare choice/ticket bookkeeping and the visible
   word does not say when exclusion occurred. A supplied Rw can therefore leave
   the proof with post-request reference choose/local/helper alternatives whose
   mandatory facts agree but whose future possibilities differ. Intersecting
   Rw with equal demand may delete a successor needed by a later move.

The exact unproved case-3 obligation is:

> Construct one Rg whose reference branch/exclusion has exactly X's K1-accounted
> remaining demand at every pair, while every later X event and bilateral
> environment move retains a suitable successor. Alternative pairs/paths are
> allowed. Preserve the fixed initial ticket convention; do not invent a new
> demand definition or discard a still-possible helper continuation.

A plausible strategy defers reference branch selection until X irrevocably
excludes h or commits it. It still needs proof that the reference state selected
**now** supports all future branches, q/closure interleavings and private states.
Defining demand as “some future X path commits h” is not automatically sound:
K fixes initial worst-case tickets and contract-branch exclusions, not a new
language-of-futures metric. Correspondence of that strategy to K bookkeeping
must be established, not assumed.

This failed induction is not nonexistence of another Rg, a conforming negative,
or a demonstrated difference in reading acceptance sets. It does not show a
J[X] failure. Exact relation demand and current operational guards are distinct;
the positive profile has room for e, h and q in every mode.

## 4. Delayed e-selection survives the matching paths

The e selected flag is mandatory at related boundaries. For a path matching an
event other than e selection, unselected endpoints rule out an intermediate
selection: `Consumed` changes only false to true (`model.go:375-423`). Mandatory
ordered labels independently forbid adding it. Already-selected paths cannot
select twice.

For a path matching actual e selection, J's S-selection gate already holds or
the candidate full step would not exist. Related full products carry the same
S/J state, so the reference can use the same original selection. Choices cannot
change this gate. Indeed e has already published and frozen (or entry was
refused), leaving no e choice at that late stage. No early reference selection,
changed handle or substitution of delivery for consumption is needed. This
survives every allowed matching path, not just a favorable relation choice.
Caller ownership/readiness transfer remains Bridge B; Environment=false proves
neither property.

## 5. Progress, domains and finite limits remain separate

No safety relation above proves Progress_D(X). Arbitrary private control needs
its supplied well-founded/SCC-equivalent nondivergence certificate. Reference
weak expansion adds at most one choice, so cannot itself create an infinite
delay. The inherited rank/512-step setting is no uniform bound for X.

Under E_N, J's e-then-S commitment prefix and original S protocol are finite;
eventual eligible service reaches S publication/delivery/selection. Its accepted
admission is the sole q debit. Residual I=R3, depths2/3 preserve original e/h/q
capacity without a new priority. Only e caller selection is delayed. Publication
requires e frozen, and A_op permits no post-freeze e instruction needing that
selection; chosen helper consumption already precedes the mode action. Waiting
for S therefore withholds no input needed by remaining candidate work. Once the
S gate holds, caller selection receives its original eventual service.

Pending still requires X's actual unmatched receive after original request and
chosen-helper consumption, with S selected and J at original e await. A safe
prefix, unfair withheld service, and a private divergent cycle are different
cases. There is no closure progress claim. A concrete public witness must
separately derive adequate common operational bounds; no cap was guessed here.

D_N restricts aligned D_full initial configurations. Restricting a coherent full
relation and its per-configuration progress premise supplies profile premises;
a profile-only negative cannot refute full conformance. Switching domains does
not discharge the remaining demand-normalization obligation.

## 6. Experiment decision and self-review

No finite experiment is needed for the two-choice classification, Gamma
preservation, or delayed-selection lemma: these exhaust the fixed rules.
Historical A/B checks cannot decide case 3 because they fix the stronger
projection and one erasure witness.

No currently specified finite search decides the universal demand obligation
over arbitrary finite A_op implementations. Next decisive work is the coherent
lemma, or a precise candidate. For such a candidate the smallest relevant probe
is its reachable local product with K1: compare the greatest weak-simulation
relation against the greatest relation also constrained by demand and actual
guard preservation. Search alternative pairs/paths; preserve bilateral readiness
at every private boundary; prove progress separately. A greedy branch strategy
or finite arbitrary candidate-size cap cannot prove universal nonexistence.
No candidate/search/acceptance experiment is claimed or proposed solely to fill
an evidence slot.

Self-review: no fixed-erasure assumption; no endpoint-to-intermediate equality
inference; no extra protocol event or split atomic transition; no early e
selection; no retrospective entitlement deletion; no trace-specific replacement
of starting k; no progress-from-safety; no ambiguity-as-negative claim. Other
bridge reports were not read. Authorization history and caller readiness remain
independent obligations.

## 7. Exact inspected identities and actual checks

K abbreviates the first source below. All source line references are to unchanged
files at checked HEAD. Performed read-only cat/nl/sed/rg, `git rev-parse HEAD`,
scoped git status and SHA-256 checks. Exploratory rg calls naming nonexistent
speculative filenames exited 2 and supplied no evidence. The first report-write
attempt was denied by the workspace sandbox; the retry requested access only
to this assigned report. No tests, solver/search, runtime runs, renders, commits,
pushes, production/manuscript changes or delegation occurred. The sole authored
file is this report. These are source arguments for review, not machine proofs.

| Source | SHA-256 |
| --- | --- |
| `docs/foundational/phase1i/01-substitution-contract.md` | `cadd87220e6b9a06ccb597dc808b31ddae072d486d13feb703e0fb480294d865` |
| `docs/foundational/phase1n/01-contract.md` | `001c1fe5cd7be722aa75ae00a2be84ec702b51783a5595754d38ec8e6b2d8fd9` |
| `docs/foundational/phase1n/02-lifting.md` | `53bf70cb2aad625b4d5a3a753610ba271c84e738f557904860988350cbe40e54` |
| `docs/foundational/phase1n/evidence/reviews/reference-r1.md` | `c6f5adf78ffa283a88a31ab417700a9b72f25ea07a6cb5ee54238ae716ad3246` |
| `research/substitution/model.go` | `1faef47e9ef17401512aba14239fc07ad7031a6db249600844752b35db342ddf` |
| `research/substitution/relation.go` | `4d4977eb96432269fbff9b550c74fd59527b3d3df5833d46f0cda1e77961a6be` |
| `research/substitution/candidates.go` | `670d0265608ff7c519b6838bd65485427f231591516aaa6f75d8ad42566ade69` |
| `research/substitution/callable_join_local.go` | `d918c235822262b0c630d6ce69721036d2b614a5e4020585c3e9b86ed68275fb` |
| `research/substitution/callable_join_relation.go` | `61c61652dd9279147fd524a77e03476a0006d17e2c8e022f0582a29937d6997a` |
| `research/substitution/invocation_join.go` | `dac14d762e71d4db2ae6d920705bcec7d080929275a6425918cf94783cd37dc0` |
| `docs/foundational/phase1o/evidence/reviews/task1-r1.md` | `243f70ef25df4f732c6d4d9f0fb53cddc510c54f9d9c8771e3d61d433a467b0c` |
| `docs/foundational/phase1o/evidence/reviews/task1-r2.md` | `2e0e6b0c77b6c21c44baf581093e200fe34dda21483dbdcdae6ea0733da5656f` |
