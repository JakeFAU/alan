import datetime,gzip,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan')
core=root/'docs/foundational/phase1o/evidence/core'
out=core/'paper-build.json.gz'
assert not out.exists(), 'one final build already captured'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=['paper/alan-dissertation.md','paper/alan-dissertation.tex','paper/references.bib']
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':{p:h(root/p) for p in sources},'steps':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('ALAN_') and k!='OPENAI_API_KEY'}
commands=[(['/Users/jacob/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node','/Users/jacob/.codex/plugins/cache/openai-primary-runtime/pdf/26.1020.11618/skills/pdf/container_tools/mark_artifact_operation_started.mjs','--operation-kind','edit','--expected-output-count','1','--output-format','pdf'],root),(['/opt/homebrew/bin/tectonic','alan-dissertation.tex'],root/'paper')]
for argv,cwd in commands:
 start=time.monotonic();p=subprocess.run(argv,cwd=cwd,env=env,text=True,capture_output=True)
 record['steps'].append({'argv':argv,'cwd':str(cwd),'exit':p.returncode,'seconds':time.monotonic()-start,'stdout':p.stdout,'stderr':p.stderr})
 print('command',argv[0],'exit',p.returncode,flush=True)
 if p.returncode:break
record['pdf_sha256']=h(root/'paper/alan-dissertation.pdf')
record['source_unchanged']={p:h(root/p)==v for p,v in record['source_sha256'].items()}
with out.open('xb') as f:f.write(gzip.compress(json.dumps(record,indent=2).encode(),mtime=0))
print('evidence',out,'SHA256',h(out),flush=True)
print(record['steps'][-1]['stdout'][-2000:]);print(record['steps'][-1]['stderr'][-2000:])
raise SystemExit(record['steps'][-1]['exit'])
