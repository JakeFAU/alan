# Phase 1O Task 2 — second independent demand-normalization argument

Status: **source argument closes the F_fact/P_boundary demand obligation in the
approved A_op domain, using W item 4's unchanged K1 accounting safety. Submitted
for independent review; not an experimental acceptance or final ARG-2 verdict.**
The preliminary concern about a missing explicit accounting map is withdrawn:
absence of a state-only map in prose does not establish a specification gap.

The frozen A/B reports were read after their independence freeze. The concurrent
demand-adversary report was not read. The original Bridge C report is unchanged.

## 1. Precise claim

For X in A_op, assume the approved W_N^(F_fact,P_boundary)(X,Rw), including its
all-prefix K1 safety, and separately Progress_N(X). There is a coherent relation
Rg with the same mandatory protocol observations, original identities, ledger,
closure/depth and **equal original K1-accounted remaining demand**. Its transfer
paths have no extra nonmatching protocol event; the only added reference choice
steps preserve the current constructor/protocol guards identified in Task 2A.
The construction may relate X to reference states not in Rw. It is not obtained
by merely intersecting Rw with equal-demand pairs.

This is the missing demand part of Bridge A. The full constructor claim still
uses the independently reviewed ownership, authorization, constructor/reference
and progress arguments. No new candidate, API realization, finite operational
cap, runtime validation, or machine-checked theorem is supplied here.

The same accounting construction handles the original local closure/scarce
safety cases. Progress is asserted only in the original open/no-closure domain
with its given service/resource assumptions. Restriction from a coherent full
premise to D_N remains valid; a profile proof is not a profile-only negative
against full conformance.

## 2. What the existing premise actually supplies

K denotes `docs/foundational/phase1i/01-substitution-contract.md`; W denotes the
approved `phase1o/01-weak-contract.md` at the pinned digest below.

The construction requires the following accounting laws, **not** equality with
Rw's particular reference choice:

| Law used | Existing source and why it supplies the law |
| --- | --- |
| Initial e/h/q demand is fixed independently of X's eventual branch | K:153–168,202–215; `model.go:106–135`. Optional h starts possible even for an implementation that will never invoke it. |
| Commitment consumes a possible ticket into committed; acceptance transfers it to spent exactly once; refusal excludes only unspent demand | K:94–95,159–163,171–175; `model.go:154–177,230–259`. No excluded-to-possible or excluded-to-committed transition exists. |
| Local exclusion is the contract's local choice after request consumption, before the no-helper mode action | K:44–49,96–102,157–162; `model.go:261–287,296–329`. It does not occur merely because an analyst predicts no helper in a future trace. |
| If h was chosen/committed, its original selected outcome precedes e's mode action | K:47–48,99–102. Rejected-helper failure is distinct from local choice and retains the original helper commitment/refusal. |
| Demand changes only through those K1 semantic transitions; premature stopping cannot retroactively remove demand | K:171–176. W:264–267 explicitly includes K:71–117 and 151–176 in all-prefix safety. |
| Candidate private instructions cannot edit protocol/accounting history or restore an excluded operation | W:110–122 fixes the operational interface/kernel; it permits arbitrary private representation, not arbitrary semantic bookkeeping. |
| Bookkeeping remains meaningful under P_boundary even when it need not equal Rw's counterpart | W:172–176 requires possibility/choice/exclusion to be recorded when assessing demand. P_boundary at W:326 relaxes cross-side equality, not K's update semantics. |

This is more than the numerical inequality `spent + demand <= limit`. Replacing
W item 4 with that inequality alone would drop K's transition rules and would be
a different premise. A stale h ticket after a no-helper mode action, an h ticket
excluded before the contract's permitted branch point, or a helper commitment
after original h exclusion is not made legal merely by staying below the cap.

There are two related but different representations of these existing laws:

1. A candidate graph may explicitly carry its logical tickets and semantic
   branch annotation, as historical transcriptions do.
2. A candidate with a different private layout may carry the same information
   in a **prefix-coherent accounting interpretation** of its event history.
   The interpretation records actual K1 accounting transitions; it is not an
   additional program input or a runtime reservation.

The second representation need not be a single function of raw private state.
It does not permit selecting a different *past* exclusion after observing a
future branch. Fixed initial tickets and causal K1 updates determine the
accounted prefix once its actual semantic branch events are fixed. Hidden
choice means hidden from the F_fact comparison word, not nonexistent in the
semantic accounting. If an implementation folds the semantic branch into a
local instruction/ordinary action, its accounting follows the corresponding
K1 choice in that transition's abstraction; no runtime callback or extra input
is created. The contract's local mode action cannot occur with neither a local
choice nor the required selected original helper.

A reviewer must not infer this interpretation from the historical erasure
checker. It follows from the **already assumed accounting safety** in W item 4
and the fixed semantic domain. An operational conformance proof may have to
exhibit an accounting interpretation to establish that premise for an actual X;
asking for evidence of the existing premise is different from adding a stronger
ARG-1 relation as a new premise.

### Why this is not a language-of-futures replacement

The accounting is deliberately not `h is demanded iff some future execution
commits h`. A fixed local implementation begins with h possible under K even
though it never commits h. Root closure can also leave possible tickets in the
accounting until an actual specified refusal/exclusion; it does not trigger an
analyst's global deletion of all now-impossible work. The normalizer below
respects exactly these original tickets and update times.

Conversely, excluded h cannot later be committed: exclusion is an actual
accounting fact, all-prefix safety applies to every continuation, and the only
commit rule requires possible. That inductive fact supplies future compatibility
without redefining demand through a future-language test.

## 3. Construct the reference history, not a new initial state per event

Maintain the original mandatory history, its candidate accounting, and a
reference execution g starting from the original aligned initial state. Also
retain some current k with (x,k) in the given Rw as a witness of weak conformance.
The k witness advances by W from that same existing k; g is separately built
and need not equal k.

Normalize only the region after e input consumption and before any original h
commit or local mode action. Before that region, and after branch-dependent
mandatory facts have occurred, preserve the ordinary reference transition
history. More precisely:

- Before accepted e input consumption, use the reference's corresponding
  uncreated/receive stage and original tickets. Entry refusal keeps its exact
  refusal and excludes its unrealizable subtree; it does not become a local
  branch.
- After input consumption, while h is still **possible and uncommitted**, keep
  g at reference `choose`, even if X or k has already internally chosen helper.
  Both reference branches are still available there. This does not change h's
  demand: `choose` and `choose_helper` both retain that unspent h ticket.
- When X's original accounting excludes uncommitted h by local choice, take
  g's `choose_local` at that accounted boundary. Keep g in the local mode region
  while X performs its remaining private work. A no-helper mode action folded
  with that choice is matched by `choose_local` followed by that exact action.
- When X commits original h while it is possible, take g's `choose_helper`
  followed by the exact original `invoke_commit(h)`. The commitment, payload,
  source/handle and zero debit remain the original atomic commitment.
- Once original h commitment exists, follow its exact admission/refusal,
  request/reply/terminal/publication/delivery/selection history. A refused h
  ticket is not confused with the no-helper local exclusion: original commitment
  and refusal facts remain present. After selected helper outcome, follow the
  corresponding mode/failure branch.

The normalizer never rewinds an actual reference execution. It may be described
as replacing an Rw reference's premature private choice by a delayed one, but
its g execution has been maintained at `choose` all along. A fresh reference
state is not selected separately after each candidate event.

Let Rg contain all endpoint pairs (x,g) generated this way, across all original
initial configurations and all candidate/environment histories. If accounting
requires history distinctions, keep the accounting history in this semantic
construction and then take the resulting possibly nonfunctional relation on
original X/reference states. The next section establishes obligations for
**every included pair and every actual successor**, not only its generating
completed trace.

## 4. Closure under every future choice and environment move

Use the invariant that g and k agree on all mandatory original facts, but g has
the normalized branch position and X's original demand. W's coherent witness
supplies a path for the actual next X event from the current k and a next k'
in Rw. Classify that path using Task 2A's source enumeration: beyond the matched
mandatory event it can contain only the single local/helper choice. No other
protocol event can be hidden.

**Private step without accounting change.** Keep g unchanged. This includes a
candidate's internal helper-choice/preparation while h remains possible. k may
advance its silent choice; g need not. The same candidate successor is related
to g and the updated k witness. Neither current protocol readiness nor demand
changes in g.

**Actual local exclusion.** The legal accounting boundary implies input has
been consumed, no h commitment occurred, and g is at `choose`. Take its
`choose_local`. It excludes exactly the same h ticket. Any future helper commit
from the resulting X prefix would require an excluded-to-committed transition,
contradicting existing all-prefix accounting safety. Thus choosing local now
cannot discard a legal future X helper branch. This conclusion is established
by the fixed ticket rules, not by predicting that X will behave locally.

**Original helper commitment.** Its original accounting requires h still
possible. g is at `choose`, so choose_helper plus the exact commitment is
available. Neither choice charges a resource; both matched endpoints retain h
committed and the same ledger. Later admission uses current resource/depth/
source guards, not the earlier choice. All future helper actions retain their
mandatory original protocol and outcome facts.

**No-helper mode action.** K's accounting semantics requires the local exclusion
already present or included with the action's semantic abstraction. Therefore g
is at local mode or can take choose_local immediately before the exact action.
W supplies the correct mode/payload/terminal fact; no helper round trip can be
inserted to justify it. This covers answer Send, fail End, absent End, and the
actual unmatched pending receive. Wrong payload or mode remains a W violation.

**After helper commitment or a mandatory mode action.** The reference's hidden
branch ambiguity has disappeared. Its fixed protocol/control region is forced
by the original committed/selected/mode facts, including helper refusal versus
successful present selection. Transfer the corresponding mandatory event and
preserve its K ticket update. No further local/helper branch can occur.

**Either-side environment event.** Before branch resolution the only additional
independent local environment events are q and closure. Both reference choices
leave their guards and updates unchanged, and those events leave the local
choice guard intact. Thus normalize-before/service and service/normalize-after
give the same accounted endpoints. q changes its own possible ticket to spent
and spends once; closure sets closure without inventing ticket refunds or local
exclusions. After original commitment/reply/freeze, all admission, reply,
publication and delivery guards depend on mandatory facts shared by g and k.
W's immediate bilateral counterpart from k is therefore the same immediate
environment event from g, with the same X successor, exact reason/debit and
accounting update. No private X step is inserted before an environment action.
Entry/helper refusal and closure prefixes remain included, not just positive
completed traces.

**State merges and quantifiers.** Suppose two different accounting histories
reach the same raw X state, one with excluded h and another with possible h.
Rg may include two reference states for that raw x. Every outgoing X edge must
still satisfy the accounting law from **each actual reachable history**. If an
original helper-commit edge exists, appending it to the excluded history is a
real X execution violating K's ticket rule; the premise fails. The construction
cannot delete that edge for the excluded history. If no such violation exists,
the preceding per-event cases apply from both reference pairs. This is why the
union is coherent and not an existential choice of branch per future trace.

The same reasoning covers X retaining both local/helper alternatives while h
is possible: g stays at choose, which can match either future. It does not
require X to implement both alternatives once X has chosen one. Extra reference
local alternatives are harmless because K refinement is asymmetric (K:244–245).

## 5. Demand, current guards and atomic groups

Initial e/h/q tickets are identical. The cases above synchronize every allowed
ticket update: e/h commitment, exact admission/refusal, local exclusion, and q's
single debit. Therefore the original unspent possible/committed set U and its
cost agree at every Rg pair. Spent charges remain equal and are never refunded.
In the positive profile this retains residual3 and full4 with J's prior debit1;
no reduced initial entitlement is inferred from the branch ultimately taken.
Scarce configurations retain their exact initial demands and refusals rather
than being declared retrospectively entitled.

The extra reference choices preserve the current fixed constructor/protocol
guards: original commitment/admission, source terminal/closure, payload/links,
ledger/depth, reply state, publication, delivery and selected flags. A possible
uncommitted helper and an excluded helper both lack an authorization/admission
request. The change in local helper-commit availability belongs to candidate
branch control. This is the precise guard distinction in frozen Task 2A: demand
must agree at related endpoints, while a real local exclusion changes demand at
its own semantic boundary. It is not a pure demand-preserving stutter. Under the
weak alternative its matching choice contains no extra protocol event and
preserves every current constructor/protocol guard dependency.

Accepted admission still atomically includes its debit, member creation and
request admission. Terminal/freeze remains atomic. An internal reference choice
before a matched original action does not split that action, manufacture a
runtime checkpoint, or permit service inside an original fixed transaction
group. If several abstract facts belong to one original atomic group, retain
the group; the argument uses only the allowed adjacent internal choice.

Delayed e selection remains the monotone-selection argument of A/B: no matching
path for another event can select e and then restore its unselected flag. Actual
e selection uses the common satisfied S-selection gate. The demand normalizer
has finished its sole branch choice long before e publication/selection, so it
adds no new selection readiness restriction or need for early caller service.

## 6. Progress and all modes

This safety construction does not prove Progress_N(X). Retain the supplied
nondivergence/rank/SCC-equivalent obligation and eventual eligible service.
A normalized reference execution inserts at most one local/helper choice;
there is no extra infinite stuttering sequence or new required input. q and
protocol service remain immediately available at every relevant boundary, so
normalization changes neither the environment's service obligations nor the
fairness premise. A concrete X still needs its own operational bounds; no
historical rank or 512-step cap applies uniformly.

For answer/fail/absent, the given local progress reaches the prescribed original
envelope after the required input/helper consumptions. For pending, it reaches
the actual unmatched receive after the same consumptions. The finite original S
and fixed caller rules supply S selection and the intended J/O waits under E_N;
this argument does not turn pending into terminal output. A private divergence,
unfairly withheld service and that pending boundary remain distinct. There is
no closure liveness claim.

## 7. Is an additional accounting premise needed?

**No additional accounting law is needed under the approved W/A_op definition.**
What is needed is a faithful use of its existing all-prefix semantic accounting,
not just W's endpoint equality/forward-word clauses in isolation. The latter
alone would not identify when candidate bookkeeping excludes h. P_boundary
allows Rw to relate different branch-bookkeeping stages; it does not waive K's
own rules for either side's original accounting history.

A superficially contrary graph that skips local exclusion yet retains a
possible h ticket through a no-helper reply/End illustrates the distinction.
Its mandatory reply trace might weakly match K by inserting choose_local on the
reference. Its raw upper-bound inequality might also remain true. But calling
its unchanged h field the **original K1-accounted demand** contradicts K:157–162
and the required local branch/mode rule at K:44–49,96–102. Either that field is
unused private data, in which case it is not the demanded semantic accounting,
or the graph violates W item 4. This is not a conforming negative or a second
compatible frozen reading. The same applies to excluding h early merely because
a future trace will be local, or restoring it after a merge.

A proof would become invalid if it assumed an unmentioned, state-only canonical
map for every raw candidate, or if it independently reassigned the past branch
on each future trace. The construction requires neither. It uses the candidate's
actual causal accounting facts, permits history distinctions where necessary,
and checks every continuation. Thus my earlier worry about a missing explicit
map was an unproved concern, not an established specification gap, and is not
retained as an extra premise or final negative conclusion.

The independent review should challenge this decisive source interpretation:
W item 4 includes K's semantic branch/ticket rules, not merely numerical budget
safety. If the controller instead intentionally removes those rules for an
expanded candidate domain, the premise changes and the conditional normalizer
still states exactly what that expanded problem would lack. That is not the
approved Phase 1O problem addressed here.

## 8. Experiment decision, evidence and remaining obligations

No finite probe is required to decide this universal source lemma: the argument
exhausts the one optional branch and its accounting transitions and proves
coherence under every successor. Historical A/B erasure checks cannot establish
this generalized result, and a bounded candidate search cannot prove it.
A later checker regression could instantiate a finite candidate with two private
steps before nondeterministic local/helper choice and cross q/closure at each
boundary, checking the greatest demand-constrained relation. Such a regression
would validate a transcription, not decide the theorem or qualify a new public
candidate. No experiment was run or accepted here.

Remaining obligations are independent review of this source proof and coherent
integration with A/B/C and the original progress/reference premises. No code or
manuscript status is changed by this scratch report.

Actual work: read frozen A/B reports and freeze manifest after authorization;
re-read the named K/W/accounting/source rules; inspect exact SHA-256 identities
and HEAD. No concurrent demand-adversary report was read. No tests, search
campaign, runtime execution, code/manuscript edit, commit, render or delegation
occurred. Only this new scratch report was authored. Worktree is
`/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan`; HEAD read as
`bec75fa3db8cdafb6295f3d0e8ebb619400c1f36`.

| Source inspected | SHA-256 |
| --- | --- |
| `.superpowers/sdd/00-plan-phase1o/task-2a-report.md` | `0cf868caa5e648427cb11a16f284f077939333ff450433e02ce1fc2eeb2a65f9` |
| `.superpowers/sdd/00-plan-phase1o/task-2b-report.md` | `8ed588207c448d421dfcc5d98644a51325e0fa7c3db002ae76201e69ef4340fd` |
| `.superpowers/sdd/00-plan-phase1o/task-2c-report.md` (unchanged) | `f2f0cb3018292974598b9e77dc28c66975f11b8cf49a6857f5529e3ff568e8ae` |
| `.superpowers/sdd/00-plan-phase1o/task-2-independent-freeze.json` | `356431273e56b28773c8d00b4dcd64ea499e285d4b7a367b7120b0b0d319d5bc` |
| `docs/foundational/phase1o/01-weak-contract.md` | `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000` |
| K: `docs/foundational/phase1i/01-substitution-contract.md` | `cadd87220e6b9a06ccb597dc808b31ddae072d486d13feb703e0fb480294d865` |
| `research/substitution/model.go` | `1faef47e9ef17401512aba14239fc07ad7031a6db249600844752b35db342ddf` |
| `research/substitution/candidates.go` | `670d0265608ff7c519b6838bd65485427f231591516aaa6f75d8ad42566ade69` |
| `research/substitution/relation.go` | `4d4977eb96432269fbff9b550c74fd59527b3d3df5833d46f0cda1e77961a6be` |

Self-review: the Rw witness starts from its existing pair; Rg is independently
maintained from the original initial state; possible h preserves every future
candidate branch; excluded h's future restriction follows the fixed ticket
rules; actual merged-state edges are never filtered by a chosen history;
q/closure/environment matches remain immediate; all four mode actions and
refusal retain their original obligations; no extra protocol event or atomic
split is hidden; progress remains separate. The accounting interpretation is
explicitly justified from W item 4 rather than silently added to the theorem.
