# Task 3 independent fixture preparation report

DONE — independent specification only, pending controller review and Task 2 disposition.

Output: `.superpowers/sdd/00-plan-phase1o/task-3-fixture-spec.md`. Final specification SHA-256: `731ac0d3c8e1b93eec45ab5f793be0ceb59603e27e67693d23fbd1f35e6d0684`.

Self-check: reread the final specification, checked every listed relation/path endpoint and toy rank by hand, checked the F2 missing initial service edge and F3 fairness distinction, and confirmed initial coverage plus fixed state/edge accounting maps are explicit. This is document/source inspection, not executed qualification.

Verified frozen weak-contract SHA-256: `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`. Read that file, original K1, the assigned task/constraints, historical local checker/model slices, and original authorization/Send/End source slices. Did not read `02-arg2.md` or other argument/review reports.

The proposed interface validates a supplied original-state relation and explicit matching paths. It separately reports legality, candidate-domain/accounting scope, component transfer, immediate bilateral readiness, progress, and optional strong clauses. It neither searches for relations nor derives NONE from witness rejection. Validation bounds come from the actual finite graphs/relation/path lists. Disconnected well-formed nodes are harmless; false claims of legal reachability are errors.

Frozen proposed fixtures:

- F1: nonfunctional relation; two independently valid reference paths and a smaller alternative valid relation; positive toy rank.
- F2: component/output agreement with missing immediate environment readiness; positive toy progress does not repair weak rejection.
- F3: private self-cycle; safety/constant strong safety pass and explicit separate progress failure with no withheld service.
- F4: extra mandatory visible occurrence; projection equality does not permit stutter; independent toy progress passes.
- F5: bound reply allegedly first denied after End under stable binding/revision/generation; invalid authorization certificate, with allowed late-first/repeated-record positive control and a harmless disconnected-node control.

Original finite clause instances include explicit e/h/q ticket abstractions and possible/local demand values; exact q/closure/helper-fork transitions; a merged local/helper history that illegally imports h commit after local choice; and bound-reply early/late first authorization across succeeded/failed End with repeat lookup. Failed End plus a committed reply is J's existing diagnostic case, not a fabricated K1 fail-mode e Send. Early/late saved source snapshots need not be identical; repeated lookup within one schedule must return its exact saved record.

An additional three-node representation diagnostic aligns two lawful original prefixes (h possible versus local-excluded) with one raw node m and submits contradictory demand values there. It rejects that accounting-map certificate; retaining every annotated history does not make demand a function of raw m. The diagnostic is explicitly conditional on F/P alignment and is not a weak-conforming counterexample or NONE.

No broad W_N/full conformance verdict is proposed. The branch-window weak verdict remains F/P-dependent. Original R remains a relation on original graph states: demand must be a declared state abstraction, and protocol sidecar provenance is separate. No arbitrary X history-splitting is used to claim state-determined accounting or repair a relation.

Remaining controller rulings: whether machinery is necessary after Task 2; the exact F/P reading for future K1 validation; which optional strong clauses to implement; and acceptance of the proposed error taxonomy/state-abstraction scope. No implementation, candidate run, search, tests, manuscript edit, render, commit, or subagent occurred. No claim of experimental qualification or ARG-2 success follows.

## Append-only completion before controller freeze

DONE. Added spec §§6–7 only. The original 271-line specification body is byte-for-byte preserved at `731ac0d3c8e1b93eec45ab5f793be0ceb59603e27e67693d23fbd1f35e6d0684`; the specification **including appendices** now has SHA-256 `396e86af553fb677890eedc9be1eaa06d1793e0939f6deadaca6bba635b8cc3e`. The earlier “Final specification” digest above denotes the preserved pre-append body.

§6 supplies explicit state/edge accounting from pre-receive entry through one finite private calculation and actual local exclusion. For each q-spent/root-closed parameter combination, it freezes anticipating R_w and normalized R_g pairs, exact paths, immediate bilateral q/closure, and fixed source/ticket maps. R_w has explicit demand mismatch at private boundaries; R_g defers reference exclusion until the actual X exclusion and preserves equal demand. The optional helper fork rejects the premature local reference pair and supplies normalized matches for both branches. A direct semantic choice remains a matched event even when F_fact assigns it an empty visible word; unmatched surrounding stutters alone must preserve current guard dependencies. The scope is a conditional F_fact/P_boundary finite clause fragment with mode/service ports, not full conformance, arbitrary-raw-state accounting, ARG-1, or progress.

§7 freezes all c;a;d;t / c;a;t;d / c;t;a;d schedules for each of succeeded/failed End, using original J's bound diagnostic in all six. Both late authorization and late reply admission remain allowed under stated stable premises. The c;t prefix stays unresolved pending reply admission; every repeat returns that schedule's exact first saved source/authorization record. Invalid provenance and outside-profile revision/generation/nonreply-invocation controls remain separate.

Self-check: reread both appendices; hand-checked parameterized relation endpoints, occurrence paths, q/closure closure of each relation, demand arithmetic, direct-choice designation, optional helper edge IDs, and all six admission orderings against the original source slices. Verified the preserved body digest and new whole-file digest. This was document/source inspection only. No code, tests, candidate search/acceptance, other-agent report/02 reading, runtime execution, manuscript work, commit, or subagent occurred.
