# Task 3 report — finite supplied certificates

Question: do explicitly supplied original-state pairs and matching paths meet the frozen finite clauses, with legal original prefixes, independently checked immediate environment obligations, and separately named accounting/guard checks?

Result: the mandated finite fixtures are implemented and tested. This establishes clause-level implementation behavior under their declared grammars, projections and snapshot premises. It establishes no new universal ARG-2 implication, candidate conformance, relation nonexistence, or full ARG-1 certificate. General P_boundary ARG-2 remains OPEN.

## Interface and exact scope

All new names are unexported and limited to this research package. `weakProblem` fixes the two graphs and rule grammar; `weakCertificate` supplies a nonfunctional set of original state-ID pairs, exact K-edge paths for X component edges, and immediate bilateral environment counterparts. No witness field can override event facts, ownership or private classification. Rule ownership and ordered `Observation` words come from the fixed problem, and original K fragments separately check their rule/accounting transcription against actual original successors. Changing a problem's grammar changes the problem; this is not a runtime input authenticator.

`checkWeakCertificate` separates `Input`, `Transfer`, `Readiness` and optional `Strong` issues, each carrying the failed pair/edge where applicable. Structural/provenance errors stop semantic assessment; a legal wrong word, endpoint or missing readiness rejects only the supplied witness. Every independently reachable included pair and every outgoing in-scope X component move is checked; K component alternatives need not be simulated in reverse. Environment edges are checked immediately in both directions. Matching paths preserve occurrence order and multiplicity; interiors need not belong to R, but genuine private steps preserve mandatory public facts. Optional demand/current-guard checks inspect related endpoints and unmatched silent reference steps. A checked, once-only direct match of the same original semantic action may change its own demand even when its F_fact word is empty.

`checkWeakRank` validates a sufficient natural-number descent certificate and completed/pending boundary facts/sinks on a complete finite graph. Rejected rank certificates are inconclusive about actual progress. `checkWeakCycle` checks only a supplied reachable cycle whose private edge is the sole enabled action at each cycle state. F3 therefore gives an unambiguous private divergence with no competing component output or required service. There is no SCC search, scheduler/fairness inference or generic cycle-to-progress verdict.

`checkWeakOriginalPrefix` compares complete submitted original edges/states with `Initial`/`Successors`; this reuses the historical semantic rule as an anchor/transcription check, not an independent proof of that rule. `checkWeakDemandMap` checks consistency of supplied demand values over each unchanged raw-state ID. It does not infer demand, synthesize a map, validate every Account_D clause, or replace raw states by history-indexed states.

The authorization code transcribes the inspected original binding predicate and first-authorization switch, checks exact immutable descriptors and first/repeated records, and separately checks bound-reply admission versus nonreply invocation source/scope admission. `checkWeakAuthorizationHistory` validates first results before retaining them for repeat checks. Original J ordering/decision/Send/End/admission/publication is checked from an actual original finite-model prefix. Numeric raw Authority values, closure query values, stable binding/descriptor and schema-validity remain explicitly supplied clause premises: the finite J model has no executor sequence/revision fields. These are not extracted runtime records or a general raw-provenance checker. Full sidecar extension of arbitrary R remains unassessed.

## Executed finite results

| Fixture | Input / clause result | Scope and separate result |
| --- | --- | --- |
| F1 | Nonfunctional, smaller and both alternative-path witnesses accepted; malformed noncontiguous path is input error; empty legal path rejected | Toy weak/constant strong clauses and explicit rank certificates pass; alternatives remain open after rejection |
| F2 | Endpoint/component clauses pass; exactly initial `(x00,k0),D0` lacks immediate readiness | Toy weak witness rejected; delayed `[T,D10]` is not immediate service; toy ranks pass |
| F3 | Toy weak/constant strong safety clauses pass | Exact sole private self-loop supplies negative nondivergence; rank rejection alone is not used as that conclusion |
| F4 | Empty B match rejected for visible b despite unchanged endpoint projection | Toy rank certificates pass independently |
| F5 | Late source_closed denial of original stable bound reply rejected as invalid first-authorization provenance | Actual allowed first record and exact saved repeat accepted; unreachable denied node alone harmless; no bad-graph weak/strong/progress classification |
| Original branch/accounting | Original B anchor and nine literal spending/demand boundaries checked; finite branch/commit/admission/q/closure fragment has 22 states and 31 edges | Immediate q/closure guards, no refund, open accepted-h debit and closed scope_closed refusal checked; omitted mode/helper/later protocol actions remain ports |
| Merged helper edge | `B;choose_local;invoke_commit(h)` rejected as invalid original prefix; helper alternative accepted | No candidate or relation nonexistence claim |
| Raw map | Legal B/L prefixes accepted; one raw m has conflicting required `[2 2 0]` / `[1 1 0]` values | Submitted accounting map rejected; the conditional F_fact/P_boundary alignment fragment is checked separately; q/closure/outcome/progress ports unassessed |
| §6 normalization | Both supplied R_w/R_g pass the declared boundary fragment's weak clauses and bilateral q/closure readiness | Each has 16 pairs, 12 component and 24 bilateral environment obligations. R_w has 8 endpoint-demand plus 4 unmatched silent-demand failures; R_g has none for the implemented strong subset |
| §6 helper fork | Deferred relation supports both choices; premature local strategy rejected at missing successor pairs | Helper admission and local-mode actions are ports; no full W_N, Progress_N or ARG1Compatible_N verdict |
| §7 timing | All six c/a/d/t schedules and exact repeat lookups accepted against original J rules | Early-a snapshots retain their own saved record after End; late-a uses its declared post-End snapshot. Both failed/succeeded Ends retain the present original diagnostic once admission resolves. c;t and c;a;t remain reply_admission pending before d |
| Outside-profile controls | Revision-before-generation denial priority, generation denial, malformed bound fields and closed nonreply source/scope checks tested | These changed-premise legal denials are separate from the stable six schedules; immutable-descriptor/first/repeat/admission mutations are invalid certificates |

The §6 component uses an independent `weakPrivateState` representation (R/P0/P1/L plus optional H/C, explicit consumed/computed/result/local/helper/q/closed fields), with fixed field-derived spending/ticket demand and guards. It has no A/B private PCs/registers and does not run an A/B erasure checker. K account/edge mappings are checked against original states for every q/closure parameter. This qualifies this finite instance, not membership of arbitrary graphs in A_op or A_pub.

## Changes and evidence

Added only these seven Go files:

- `research/substitution/weak_refinement.go`, `weak_refinement_test.go` — supplied relation/path/readiness checks, rank/cycle certificates and toy/defensive fixtures.
- `research/substitution/weak_refinement_accounting.go`, `weak_refinement_accounting_test.go` — original-prefix checks, branch/ticket accounting and raw-state map diagnostic.
- `research/substitution/weak_refinement_authorization.go`, `weak_refinement_authorization_test.go` — original authorization/admission clause records and six J schedules.
- `research/substitution/weak_refinement_normalization_test.go` — independently represented §6 normalization and helper-fork fixtures.

Evidence is under `docs/foundational/phase1o/evidence/core/task3-*`. `task3-index.json` lists every run, exact argv, exits, source identities, evidence hashes and selected top-level test names. Each compressed JSON record retains UTC, cwd, argv, an environment allowlist, stdout/stderr, selected Go test events and source SHA-256 values. Final normal/race records hash every Go source in the package plus the inspected original production rules. They have identical source manifests. The recorder stripped every ALAN_* variable and OPENAI_API_KEY from the child environment without logging their values.

Frozen inputs remain unchanged: 01 SHA `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`; 02 SHA `ca3def80b384335694afcd97c68202e6d93821aad414ac305dc701495599e84c`; 03 SHA `a41c2216caa80d979365e61470dce6fc03c2616ad6f2faeab2e2431b0418a083`. Source base was `ffd00be531fbb986b86160bd6c22a87345fee14a`. This worker did not change frozen contracts, historical checkers/model/runtime, manuscript or dependencies and did not commit/push/render/spawn. Concurrent controller manuscript/docs edits are outside this worker's changes.

## Verification actually run

Installed toolchain: `/opt/homebrew/bin/go`, Go 1.27.3 darwin/arm64. All Go child commands used `GOTOOLCHAIN=local CGO_ENABLED=1 GOPROXY=off GOSUMDB=off GOFLAGS=-mod=readonly GOCACHE=/private/tmp/alan-phase1n-model-go-build`.

- Discovery: `/opt/homebrew/bin/go test -list '^TestWeakRefinement' ./research/substitution` discovered 23 top-level tests.
- Final normal/race: `/opt/homebrew/bin/go test -json [-race] -count=1 -run REGEX ./research/substitution`, where REGEX is the exact anchored alternation of those 23 discovered names, retained literally in both verified-run JSON argv records. Both passed 23 top-level tests / 69 total test+subtest events, zero failures/skips.
- `/opt/homebrew/bin/go vet ./research/substitution`: exit 0, no diagnostics.
- `/opt/homebrew/bin/go mod verify`: exit 0, all modules verified, offline.
- `/opt/homebrew/bin/gofmt -d` on all seven additive Go files: exit 0, empty output.
- `/opt/homebrew/bin/staticcheck ./research/substitution`: exit 1, six remaining historical diagnostics and none in the new files. ST1005: callable_join.go:290,301,307 and callable_join_local.go:65. U1000: invocation_join_explorer.go:84 and invocation_join_oracle.go:61. The four diagnostic-bearing files were compared byte-for-byte with HEAD and are unchanged. No checks were suppressed and these findings were not repaired out of scope.

RED evidence was captured against compile-only stubs before core/accounting/authorization implementation. Defensive RED runs exposed repeated direct-match exemption and missing structural rank checks, then a private reference interior changing public projection; those checks were corrected and included in the passing final runs. All ordinary attempts are retained: the first compile collided with historical function `weakGraph` (renamed the new record); an early negative word fixture accidentally retained a direct-match annotation, making it invalid before word rejection (removed only that annotation to target the legal wrong-word clause); initial staticcheck also found a new unused F4 setup assignment (fixed). There was no interrupted validation or incomplete search. No broad historical census/full suite/download was run, as instructed.

## Remaining obligations

No existence or NONE API exists. Rejected supplied witnesses do not exclude alternatives. Admissibility A_op/A_pub, arbitrary initial/configuration families, full Account_D, all ARG-1 clauses, coherent retained-sidecar extension, full W_N/W_full and actual all-mode Progress_N remain not assessed. Fragment projection/grammar/accounting assumptions are fixed inputs, not proved consequences of weak conformance. Original-rule reuse provides a transcription check, not an independent theorem or runtime correspondence proof. Manuscript reconciliation and independent acceptance review remain controller responsibilities.
