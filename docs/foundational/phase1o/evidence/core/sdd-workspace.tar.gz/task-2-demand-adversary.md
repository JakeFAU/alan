# Task 2 — adversarial demand-normalization attempt

Status: **no admissible A_op counterexample found; constructive normalization
argument for the original legal ticket accounting, submitted for independent
review. No specification-gap verdict.** The argument below attacks Task 2A
section 3's F_fact/P_boundary case. It does not claim a compiler theorem,
A_op=A_pub, an executed qualification, or an unconditional ARG-2 verdict.

Original Task 2B report is preserved. The first A/B/C reports were read only after
their independent freeze; no other concurrent demand report was read. All source
arguments use HEAD `bec75fa3db8cdafb6295f3d0e8ebb619400c1f36` and the approved
definition hash `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`.

## 1. Exact accounting premise: already required, not an added scalar invariant

Let K be `docs/foundational/phase1i/01-substitution-contract.md`, and W be the
approved Phase 1O weak contract. The relevant accounting premise is **a legal
trajectory of the original logical tickets**, including their original transition
discipline. It is stronger than saying that a candidate counter is monotone,
takes values in `{0,1}`, or satisfies the resource inequality.

This trajectory is already required by W:264–267 item 4, which imports K1 safety
at all prefixes, explicitly including K:151–176. W:172–175 also says helper
possibility/choice and exclusion determine demand under those original rules
and must be recorded when assessing it. The rules are:

- Initial demand includes the original optional h even for a local-only
  implementation (K:153–158,165–176). Knowing the code never invokes h is not
  permission to remove that initial ticket.
- Commit changes possible to committed; original admission either spends it
  once or excludes it by its exact refusal. Entry refusal excludes its
  unrealizable subtree (K:159–162).
- The original local choice excludes h (K:162); it occurs after request
  consumption and before the local mode action (K:44–49,96–102).
- Demand updates only by K1 transitions; spent is never refunded or resurrected
  (K:163,171–176). A possible h may not be excluded merely because a private
  instruction happened to make a syntactic future path disappear.

The last two statements jointly rule out a purported *logical* h that remains
possible after taking the original local mode action without a helper. K's mode
action follows its local/helper choice; the local case has already excluded h.
Conversely, an independently represented private flag called `helperPossible`
is not automatically this logical ticket. Its spelling or a stale historical
`PC`/`Choice` field cannot redefine K's account.

This is an operational semantic trajectory, not a new metric such as “there
exists a future machine execution that invokes h.” For example, root closure
does not automatically delete every possible ticket: retain original bookkeeping
until its actual K update. Likewise a local-only program retains initial h
demand until the original local-choice boundary. No future-language calculation
or retrospective entitlement change is used below.

For a candidate encoding, its original logical account can be recorded alongside
its private control or indexed by its lawful semantic history. It need not be
the A/B `Operation` layout or a unique function of a private instruction address.
This is accounting for original transitions, not a new candidate-observable
state variable or a new environment input. The relation must include all enabled
continuations from every included accounting history. History indexing cannot
hide an illegal transition from a merged physical state.

## 2. The normalization construction

Claim under attack: for X in A_op satisfying
`W_N^(F_fact,P_boundary)(X,Rw)` and separate `Progress_N(X)`, obtain a coherent
relation with exact original demand at related boundaries. This section gives
a source-level construction; Sections 3–4 test its critical cases. It is not
the assertion `Rg = Rw intersect equal-demand`, which can lose successors.

Use the original mandatory history and legal logical-ticket history of X.
W supplies a consistent original identity renaming and preserves every mandatory
commit/admission/input/reply/terminal/publication/delivery/selection/debit fact.
The only potentially invisible reference transitions are its two branch choices
(`model.go:274–287`). Build normalized reference histories as follows:

| X's original semantic boundary | Normalized reference boundary |
| --- | --- |
| Before accepted input consumption | Same original entry/protocol state; initial h remains possible unless original entry refusal excluded it. |
| Input consumed; h uncommitted and logically possible; no e mode action yet | Keep reference at `choose`, regardless of X's private branch flags or a prior tentative/helper decision. |
| Original local exclusion of an uncommitted h | Take reference `choose_local` at this original accounting update; reference is at local mode with h excluded. |
| First original helper commitment while h remains possible | From reference `choose`, take hidden `choose_helper` immediately before that original commitment. The commitment is the same immutable original h action. |
| Original h committed/admitted/refused/selected | Follow its mandatory history. Reference e awaits h until original selection, then enters its mode/failure action. Its demand changes on the same exact admission/refusal. |
| Original local mode action, terminal, pending and later protocol | Same original action and retained facts; the original local or helper branch is already determined. |

Here “keep at choose” is a choice of reference state/path, not a delay imposed
on X. X's private instructions continue under their original guards. Choosing
helper alone keeps the same possible demand; delaying that reference choice
until commitment changes no committed intent, source terminal, debit, reply,
publication or selected fact. There is no admitted helper service to withhold
before commitment. If a declared X event's fixed correspondence already contains
an original bookkeeping choice and a mandatory action, match that existing
whole event by the corresponding finite K path; do not invent an X checkpoint
or admit service inside its atomic group. No new grouping is proposed to rescue
an otherwise illegal encoding.

The construction uses X's **actual original accounting transitions**, rather than
guessing its ultimate branch from its code or choosing a favorable completed
trace. At h-possible private boundaries it picks `choose`, which retains both
permitted future branches. At h exclusion it picks local; every lawful later
continuation excludes original helper commitment. At helper commitment it picks
helper; the mandatory original commitment prevents returning to a no-helper
history. These decisions therefore remain compatible with all future moves.

Form Rg from the initial pairs and all successor pairs generated by this
normalization for every required X/component and either-side environment action.
Equivalently, use all compatible pairs of original-accounting histories produced
by this rule. Distinct lawful histories may have different account states at
the same private PC; no unique private-PC-to-ticket sidecar is assumed. Mandatory
and account histories remain fixed once chosen; they are not recomputed after
future behavior. Where the account is already state-determined, ordinary state
pairs suffice.

Exact demand follows by induction: e and q use identical mandatory original
commit/admit/debit histories; h stays possible on both sides, becomes excluded
on the same original local/refusal update, or becomes committed/spent on the
same original helper history. Thus both retain the same original U at every
related boundary. In D_N the initial residual e+h+q entitlement remains3, with
J's prior debit1/full4 separate. No extra helper charge, deletion, or refund is
introduced. Current spent/depth/open guards continue to agree.

## 3. Closure under all moves, including the branching objection

**Private work with unchanged account.** Match stutter and keep the normalized
reference boundary. In particular, private flags may say local or helper,
be changed during finite preliminary computation, or use different PCs. They
do not force an early reference branch. This is the key difference from fixed
private-state erasure.

**Original local exclusion.** Its legal original position is post-input and
pre-mode, with no original h commitment. The normalized reference is at choose,
so it takes choose_local with the same exclusion. A machine instruction that
realizes that semantic update is not a pure demand-preserving ARG-1 stutter,
even if F_fact hides its control label. It matches the original semantic choice;
the word has no extra mandatory fact. A label `private_step` alone cannot make
an arbitrary bookkeeping mutation legal.

**Original helper commitment.** The normalized reference takes choose_helper
then the same commitment. No original excluded h can reach this case. Later
mandatory helper service is unchanged; X cannot reach e's mode action before
the original helper selection because that would require nonmatching mandatory
helper facts on every reference match. Exact rejection/failure and successful
present helper results are kept separately.

**The exact branching argument.** Suppose a related X boundary has a lawful
future local path and a lawful future h-commitment path. A supplied pair with
reference already local/excluded cannot support the latter: local reference
has no return to choose or helper-enabled state, and no hidden transition
recreates h. Following the candidate's finite prefix to the first h commitment
eventually falsifies forward simulation from that *same starting reference
state*. Nonfunctionality does not permit replacing the starting reference state
after seeing that continuation; every included pair must work.

That rejects this supplied pair, not X. The normalized `choose` state supports
both paths: local exclusion chooses local, and first helper commitment chooses
helper. Each successor lies in the same generated Rg. No prophecy, per-trace
replacement of the start state, or language-of-futures demand estimate occurs.
If the branches reside in different private states instead, the same normal form
works and is only more permissive than needed. It adds no candidate choice or
environmental input.

**All declared environment events.** Before helper commitment, neither reference
choice creates an admitted intent or reply. Only independent q/closure can
interleave in the post-input choice region, and both commute with either
reference choice (`model.go:211–227,274–287`). Their guards, ledger/closure
updates, and original ticket updates are unchanged. They cannot force a private
step first. If closure has occurred, preserve its exact bookkeeping rather than
deleting tickets based on hypothetical future feasibility.

After any commitment, the same mandatory protocol history gives the same
admission/reply/publication/delivery readiness and original current guards.
Entry refusal's helper exclusion is already part of the same fixed refusal
transition; helper refusal's exclusion is likewise matched directly. The
normalization does not split an accepted admission's debit/create/request group,
or a terminal/freeze group. Because the differing reference bookkeeping states
have the same enabled declared-environment guards, W's original bilateral
service can be matched immediately in the generated relation, including at
every private boundary. Source/binding/first-authorization histories remain the
separate frozen Bridge C argument; silent choices alter none of those predicates.

**Mandatory local mode actions.** These have already resolved local exclusion
or contain the original helper history through selection. The canonical state
has the correct mode continuation. W prevents wrong payloads, missing required
consumptions, extra actions or different terminal facts. Retained protocol facts
then determine the later reference suffix; branch choice cannot reappear.

These cases use existing ticket transition legality, not just U equality.
They explain why lawful accounting closes the objection in Task 2A section 3:
an early reference choice can be moved to its compatible original-accounting
position, while the uncommitted possible-demand region retains choose. The
result is a fresh coherent relation, not necessarily a subrelation of Rw.

## 4. Adverse attempts and their dispositions

1. **A real bad supplied witness, but a normalizable candidate.** Take the
   ordinary local semantic graph, independently add one once-only pure private
   instruction after original request consumption and before its original local
   choice, and retain the original h account. Call those private boundaries u/v,
   with h possible. In F_fact/P_boundary, a supplied Rw can match request consume
   by `request_consume;choose_local`, pairing u/v to reference local mode with h
   excluded. It can match X's later actual local exclusion by empty stutter.
   Mandatory facts and environment guards agree, but demand differs at u/v.
   Rg instead pairs u/v to reference choose and takes choose_local at X's lawful
   exclusion. Thus the supplied witness does not extend by intersection, while
   another compatible relation exists. P_stage/F_event reject the premature
   witness, not the candidate with this normalized witness. This supplies no
   difference in candidate acceptance sets between readings.
2. **Keep logical h possible forever after a correct local reply/End.** Invalid
   original accounting: local mode follows the local branch, whose prescribed
   update excludes h. A stale private field can remain possible, but cannot be
   substituted for K's logical ticket. The prefix inequality alone would miss
   this; W item4 imports more than that inequality.
3. **Initially exclude h because the whole program is local-only.** Invalid
   initial account under K:156–170. The example in item1 retains h until the
   original branch, so it does not make this mistake.
4. **Exclude before original input, then invoke h on a later private branch.**
   The early semantic exclusion violates its original choose guard; the later
   commitment also resurrects an excluded ticket. A merely tentative private
   flag is harmless but changes no logical demand. Exact same-state future
   branching cannot legalize either violation.
5. **Actual local exclusion on one history, merge private state, then enable h.**
   On the excluded history the enabled h edge is a safety violation, regardless
   of a different possible-ticket history reaching the same private state. A
   history-indexed Rg cannot erase the bad continuation. If the merged suffix
   never invokes h, the original local update may be represented at its lawful
   boundary; both histories can be related without a unique private-PC sidecar.
6. **Tentatively choose helper, do private work, then choose local before any
   commitment.** Ordinary private intention flags are normalizable at choose.
   If the encoding claims the irreversible original choose_helper and then an
   unsupported reversal, its original semantic map is invalid; one may not
   invent a rollback transition or retract an original commitment.
7. **Use q/closure to mutate the private branch or h account.** A_op does not
   grant arbitrary private access or kernel updates. Original environment
   refusal updates are matched as stated; arbitrary q-written branch state or
   an extra observation is outside the interface. No such candidate was used.
8. **Add an infinite private cycle while matching reference choose.** Safety
   simulation can permit it; separate Progress_N/nondivergence rejects it. It
   cannot refute a premise that already includes that obligation.

None of these classifications asserts nonexistence from an exhausted guessed
example. Items1/6 exhibit the alternative normalization; items2–5 violate
specific original accounting rules; item7 changes the interface; item8 violates
the separate progress premise. I did not produce two compatible full-contract
readings with differing candidate consequences, so I make **no ambiguity or
demonstrated specification-gap claim** from these attempts.

## 5. Progress, bounds, and smallest optional finite check

This accounting construction proves no candidate termination theorem. Progress_N
and a rank/SCC/equivalent private nondivergence certificate remain separate.
Only the original once-only branch is repositioned in reference matching, so
normalization adds no infinite internal expansion. It grants no q priority and
preserves the same eventual eligible service. Delayed e selection and the actual
S-selected/J-e-await/O-J-await pending boundary remain the frozen A/B arguments.

For the concrete item1 toy, the new private instruction is once-only; the original
local graph remains finite and acyclic. With its extra monotone completion bit b,
`2*Rank(original semantic state)+b` strictly increases on every toy edge. The
ordinary mode paths and original q/caller service then give the original exact
maxima. This is an analytical separate progress certificate for that specified
toy; no solver or runtime was run. It is neither a uniform rank for arbitrary
private implementations nor an adequate public runtime cap. I/R/depth remain
the fixed entitlement; sufficient finite operational limits remain a premise.

No finite probe decides the universal normalization lemma. Its decisive review
point is whether each use of the original accounting law above has the stated
source justification, especially local exclusion before/no later than its mode
action. That law is already part of approved W item4, not an additional joint
transition correspondence inferred merely from legal scalar values. A missing
syntactic map for an unspecified implementation is not itself a contract gap.

If the controller wants the smallest executable check of the only actual
supplied-witness mismatch here, encode item1 with **one** extra private bit and
one original local-choice boundary for D_N answer input `{id:1,value:0}`.
Independently check both supplied relations: premature-local Rw and delayed-choice
Rg. Keep q/closure edges immediate at u/v; compare exact original U at endpoints;
check all alternative pairs/paths rather than fixed erasure. An optional second
branch to original h commitment attacks the exact bad-pair failure in section3.
All-mode toy checks would independently exercise fail/absent/pending, but one
input already decides this finite relation question. This proposed probe would
validate a transcription, not prove ARG-2 or A_pub realization. It was not run.

## 6. Result, remaining review obligations, and inspected identities

Result: a coherent original-accounting normalization survives the attempted
F_fact/P_boundary attacks in A_op. The required legal accounting trajectory is
an **existing frozen premise**, while a mere monotone demand number is
insufficient. The proof deliberately permits history-indexed accounting and
alternative Rg states/paths. No contextual failure, new semantic gap, universal
compiler correspondence or executed candidate acceptance is asserted.

Remaining obligations: independent semantic review of the normalization
induction and the joint original bookkeeping/mode cases; integration with the
separately frozen A/B/C arguments without weakening their assumptions; and any
subsequent finite qualification/operational correspondence chosen by the
controller. No new production or manuscript change was made here. The original
report hashes below remain unchanged.

Read sources: assigned Task2 brief/constraints/bridge instructions from the
initial task; approved W; K:44–106,151–176,218–245; original model choice/mode,
admission and rank slices; all three independently frozen reports and their
freeze manifest. Read Go source-navigation guidance in the earlier bridge task.
Checks performed now were read-only source extraction, HEAD verification and
SHA-256 computations. No Go tests, finite search, runtime acceptance, render,
commit, paper/code edit or child agent occurred. Only this new scratch report
was authored during this follow-up.

| Inspected artifact | SHA-256 |
| --- | --- |
| `docs/foundational/phase1o/01-weak-contract.md` | `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000` |
| `docs/foundational/phase1i/01-substitution-contract.md` | `cadd87220e6b9a06ccb597dc808b31ddae072d486d13feb703e0fb480294d865` |
| `research/substitution/model.go` | `1faef47e9ef17401512aba14239fc07ad7031a6db249600844752b35db342ddf` |
| `.superpowers/sdd/00-plan-phase1o/task-2-independent-freeze.json` | `356431273e56b28773c8d00b4dcd64ea499e285d4b7a367b7120b0b0d319d5bc` |
| `.superpowers/sdd/00-plan-phase1o/task-2a-report.md` | `0cf868caa5e648427cb11a16f284f077939333ff450433e02ce1fc2eeb2a65f9` |
| `.superpowers/sdd/00-plan-phase1o/task-2b-report.md` | `8ed588207c448d421dfcc5d98644a51325e0fa7c3db002ae76201e69ef4340fd` |
| `.superpowers/sdd/00-plan-phase1o/task-2c-report.md` | `f2f0cb3018292974598b9e77dc28c66975f11b8cf49a6857f5529e3ff568e8ae` |
