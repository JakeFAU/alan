# Task 2B — independent caller ownership and readiness argument

Status: independent source-level argument, submitted for controller integration
and independent challenge. This is neither a machine-checked theorem nor a new
qualification run. No other contemporary bridge report was read.

## Exact result and scope

**B_op:** For `X in A_op`, a relation satisfying the frozen `W_D^sigma(X,R_w)`
has equal readiness for original caller-owned `invoke_commit(e)` and
`outcome_consume(e)` at every related local boundary. Moreover, their matching
reference paths are forced to be the immediate corresponding caller transition,
so their successors are already related by `R_w`. This applies to `D_full` and
its restriction `D_N`, to both projection readings `P_stage/P_boundary`, and to
both visibility readings `F_event/F_fact`. It does not normalize arbitrary
candidate/helper paths or extend authorization histories; those are Bridges A/C.

The framing premise is the fixed operational ownership interface in the approved
definition, not a theorem obtained from K1's simulation clauses alone. Under that
interface candidate-private state cannot add a caller guard, remove a kernel
transition, or alter its update. The needed caller guard facts follow from K1's
named public facts without equating every field of the historical `publicState`.

**B_graph:** If `A_graph/O_graph` removes that framing premise, the relation and
progress clauses do not imply caller readiness. Section 5 gives an exact
edge-deletion construction witnessing the differing consequence, including
progress, rather than relying on a failed guessed relation. This is a broader
graph result, not an `A_op` or `A_pub` negative and not a contextual failure.

**B_pub:** The inspected authoring/compiler/reducer rules support this owner
separation for authored programs, but no theorem here equates all `A_op` graphs
with public realizations or proves compiler correctness. A concrete public
witness would require its own mapping and operational-limit evidence.

## Sources and premise provenance

Names: `K` = Phase 1I contract; `N` = Phase 1N contract; `L` = Phase 1N lifting;
`R1` = final Phase 1N reference review; `W` = approved Phase 1O weak contract.
All source paths and SHA-256 identities appear in section 8.

| Needed premise | Exact provenance and classification |
| --- | --- |
| Original caller starts at Invoke, without extra initialization; retains original handles and selected outcome | Original K:122–124; source kernel `model.go:106–135,230–242,375–423`. |
| Commit is source-open at the original Invoke and once-only; selection requires the original delivered outcome and open caller at exact Await | Original K:94,104–106 and once-only fields K:78–88. The model expands the delivery/not-consumed checks at `model.go:375`. |
| Public commitment, delivery, selected consumption, source terminal and closure facts agree at related states | Original K:74–88,218–225,299–303; frozen W:158–176,196–212. No extra coarse-PC equality is inferred. |
| Candidate variation cannot guard or mutate original caller actions | Fixed operational-domain premise W:104–131 and R1:140–145,157–158, supported for historical transcriptions by `candidates.go:17–29`. K:218–242 alone is not an ownership type system. |
| Every declared environment action remains immediately available on both sides at private boundaries | Original K:208–216,226–231; W section 5 item 3. The Environment flag does not establish ownership of false-flag events. |
| Terminal member cannot resume; original helper must be selected before e's mode action | Original K:44–48,81–88,99–103; fixed operational termination W:148–154; runtime `program.go:302–304,470–477`. |
| Fixed J commits e then S and consumes S then e; same S/J state in lifted relation | Independent constructor premise N:40–47; L:110–124; kernel `invocation_join.go:174–187,212–224`. |
| Local progress/nondivergence, eventual eligible service and adequate finite operational bounds | Separate original obligations K:192–198,232–242; positive environment N:195–222. Not derived from safety simulation. |

## Derivation of B_op

Write a local state as candidate/private data plus the fixed caller/protocol
kernel. Let `H` contain original e commitment, admission/refusal, delivery,
selected-consumption and immutable envelope facts, together with root closure.
All are named facts in `P_K` under either projection reading. The fixed local
caller has the following reachable-history invariant:

```text
root closed                         => caller cancelled; no commit/selection
open, original e uncommitted         => caller at first original Invoke
open, e committed, e not selected    => caller at original e Await
open, original e selected            => caller has retained its envelope and ended
```

This follows by induction from the local initial state: original e commitment
is the only transition from the first stage; selection is the only normal
transition out of Await; closure cancels. Candidate/helper instructions and
protocol service cannot write the caller phase. `model.go:230–242,375–423`
implements these updates. For the local `Config` domain, e is initially enabled
and cannot be excluded before its original commitment/admission. Entry refusal
does not restore its ticket or permit a second commitment. Root terminal is
distinct from a child envelope, as K:86–88,108–110 requires.

Thus the local guards reduce to public-history predicates:

```text
C_e(H) = caller open at first Invoke AND original e not yet committed
T_e(H) = caller open at original e Await AND original e delivered AND not selected
```

At related reachable states these predicates agree, even if scratch caller PCs
are not explicitly in the selected projection: the reachable-history invariant
determines the phase. The exact envelope/handle and the selected data update also
agree. Source-open is determined by closure for this fixed local root caller
(`model.go:138–143`), not by a candidate-private flag. Therefore readiness is
bilateral for these two caller actions. A candidate local step may legitimately
change a public guard dependency only via an admitted ordinary semantic event;
it cannot change the owner's predicate or require a preparatory private step.

Readiness alone would not establish that an arbitrarily supplied `R_w` relates
the *immediate* successors: its forward clause generally permits a longer path.
Here the two caller positions force normalization without a general Bridge A:

1. At e commitment, no e member exists and no helper work is enabled. A reference
   path matching the original commit cannot admit e, consume its input, spend q,
   close the root or perform any other mandatory protocol fact: those would be
   additional facts. There is no pre-admission reference branch/control step.
   Nor is there a silent post-commit choice: reaching the choice requires the
   additional admission and request-consumption facts. The matching path is
   therefore precisely the original `invoke_commit(e)`.
2. Before e selection, its original outcome is already delivered. A reference
   entry is consequently rejected or frozen and published. A successful/failed/
   absent e path has already consumed its chosen helper before the mode action;
   a refused entry has no helper run. No e/helper local choice or mode work
   remains that could precede/follow selection silently. Reply/admission,
   publication, delivery, debit and closure are mandatory facts, and cannot be
   inserted into a path matching only selection. The reference has no extra
   private instruction at this tail. The path is precisely the once-only
   `outcome_consume(e)`.

These statements use ordered facts, not endpoint totals, and leave all fixed
atomic groups intact. They also apply when F_fact hides a reference choice:
neither caller position is adjacent to a reachable choice without an intervening
mandatory event. Since every enabled X-side caller action is included in W's
forward checks, W's related-successor obligation now applies to these immediate
kernel successors. There is no need to enlarge `R_w` or preselect a future
matching strategy for these actions. Every included pair retains the same
future obligations under W.

## Declared environment service and delayed e selection

Caller commitment/selection have `Environment=false`; K:226–231 does not by
itself apply its reverse-readiness clause to them. Conversely, admission,
reply-admission, publication, delivery, q and closure are declared environment
events. At every already-related private boundary W directly requires their
immediate identical counterparts and related successors. A candidate cannot
disable an eligible delivery until a private instruction executes, even if it
would eventually execute that instruction. Fixed ownership and bilateral
environment readiness are different reasons, both needed here.

In J, replace the scratch local caller by the common fixed J phase. Its e
commitment additionally waits for J's original input; both sides have that
identical finite owner prefix. Its e selection additionally requires original
S selection, because J is at its second Await. This restriction is common to
both sides (`invocation_join.go:118–122,174–187,212–224`). No candidate-owned
guard is added. The projection explicitly retains a scratch e Await after e
commitment even while full J is still at its S Await
(`callable_join_local.go:10–12,31–38`); this is not a claim that J's actual e
selection is already enabled.

For a candidate event ending e-unselected, any reference matching path also
ends e-unselected. Monotonic once-only selected flags prohibit an intermediate
e selection followed by restoration. For actual e selection, S's common selected
gate already holds and remains true. Section 3 forces that matching caller event
to be immediate. This establishes that this particular new selection gate does
not invalidate otherwise allowed matches. It does not establish stability of
other guards at arbitrary matching intermediates; Bridge A remains separate.

**Progress is conditional and separate.** Under E_N, J's finite prefix eventually
commits S; original S has its finite Receive/Send/End and protocol path. Initial
I=R4, J's prior debit1, residual3, depth3, and K1's at-most-e/helper/q demand
prevent S resource starvation. Stable binding and eventual eligible protocol
and local service yield S publication, delivery and actual J selection. This
allows S admission before or after e admission and grants no q priority. While
S completes, delaying e selection cannot withhold an input needed for further
e computation: e can only publish after its freeze/refusal, and there is no
post-freeze component resumption or selection-acknowledgment input. Other local
actions and all protocol service remain eligible under their original rules.

Therefore the added S gate delays an otherwise enabled local e selection only
finitely on fair open paths. Removing that finite prefix preserves the local
eventual-service premise; it does not reclassify an infinite service-withholding
suffix as fair. The separate `Progress_N(X)`/nondivergence premise supplies each
mode boundary. In pending, e has consumed its request and chosen original helper,
then reaches the actual unmatched receive with no freeze/reply/publication; S
still completes and is selected, J stays open at e Await, and O stays at J Await.
In other modes the finite J/O suffix follows original e selection. Authorization
service here uses E_N's conditions and the separately required Bridge C extension;
this paragraph does not prove that extension.

An infinite private cycle is rejected by K:239–242, whereas an infinite withheld
eligible S/q/protocol action violates service assumptions; neither is the
designated unmatched receive. A sound rank/SCC or equivalent certificate for X
is still required. Nothing here bounds arbitrary private instruction counts by
the historical rank or the 512-step runtime setting. Adequate finite limits stay
a premise. A new public candidate would need an independently derived common
operational cap before qualification, separate from I/R/depth entitlement.

## Exact broader-graph limitation

To show why the framing premise cannot be inferred just from W's relational and
progress clauses, consider this purely mathematical graph `G_q` over the unchanged
K1 reference state space:

```text
Q(c,s) = the original sole peer_debit(q) is enabled in (c,s)
G_q(c,s) = all original K1 edges, except omit outcome_consume(e) when Q(c,s)
R_q = identity on reachable state/public facts
```

There are no new operations, events, private instructions, debits, post-freeze
steps or state writes. At an aligned answer boundary, choose the local branch and
allow e's commit/admission/input/reply/freeze/reply-admission/publication/delivery
before q. e has spent1 out of residual3, q is still possible, and the original
caller is open at e Await. Thus Q is true. K1 permits immediate e selection;
`G_q` omits it. Delaying q through this finite prefix is allowed by eventual
service. This is a concrete reachable discrepancy, not an unreachable-state
artifact.

Why the *relational clauses* accept `R_q`: every retained candidate edge is the
identical reference edge, with identical successor; all declared environment
edges are retained and have immediate counterparts in both directions. Public
facts agree under the strongest P_stage projection and all visibility readings.
Reverse checks do not cover the deleted Environment=false caller edge.

Why *progress* does not repair the discrepancy: deleting that selection never
creates a new stuck state, since Q supplies the unchanged q edge whenever it
causes a deletion. All remaining paths are reference paths, and no new cycle is
introduced. Once q occurs, Q is permanently false; if other spending instead
exhausts a coordinate, Q likewise becomes permanently false. The finite reference
rank/once-only transitions therefore leave the same permitted maxima. A fair
service interpretation also cannot withhold a continuously eligible q forever.
When q is absent/ineligible, no selection is deleted. Pending selection was
already absent. Hence the construction preserves the reference's all-mode,
scarce and closure qualifications, conditional on those reference obligations,
on D_full as well as D_N; it supplies no candidate-specific uniform runtime cap.

No alternative ARG-1 relation can hide the readiness discrepancy at the displayed
reachable state: any related reference state must retain the same open caller,
original commitment, delivered unselected e envelope and q/ledger facts. Its
fixed original caller is therefore at e Await and selection is enabled. The
candidate lacks that action. ARG-1's same-caller-readiness requirement fails.
This establishes a differing consequence between an unconstrained edge-subgraph
reading and the framed domain, without relying on one failed relation guess.

`G_q` is **outside A_op**, since it changes the original caller guard. It is not
an A_pub witness. It also does not establish a K_join failure: in fixed J, S
selection implies its accepted debit has already spent q, making this added
guard redundant exactly when J can select e. Thus three claims remain distinct:
relational clauses lack a caller framing type rule; this graph has no supplied
local ARG-1 readiness relation; no contextual violation follows here.

The missing rule for A_graph would be exactly owner framing: original caller
commitment/selection and their state updates retain their fixed guards/functions
of original caller/public history independently of candidate-private state. W
already declares that rule as its **domain premise** for A_op. Adding it to an
unconstrained-graph contract would narrow that domain; it cannot be advertised
as a consequence of forward simulation plus bilateral declared-environment
readiness. The q filter demonstrates the omission even with an extra *public*
guard, so the relational clauses alone cannot certify the stronger prohibition
on private guards either.

## Public correspondence limits and decisive experiment

The public API builds Invoke as the source program's emit and AwaitInvocation as
its receive, matching the pending original operation
(`author/invocations.go:99–107`, `author/compile.go:307–329`). The reducer sees its
own projection and supplied observation (`program.go:292,308–317`), checks exact
target run/provenance/source/generation/obligation/operation (`:362–387`), and
rejects a non-open source (`:302–304`). This supports the owner argument within
the fixed authored-program interface. It does not establish A_op=A_pub or
universal correspondence for all abstract finite graphs. No raw authentication,
scheduler or compiler proof is claimed.

No finite experiment is needed to decide B_op or the clause-level A_graph
non-implication: they follow from the two forced reference caller positions and
the explicit edge filter. Existing historical A/B checks are insufficient for a
universal claim because they hardwire the fixed owner extraction and a stronger
public projection (`candidates.go:17–29`; `relation.go:15–19,43–109`).

If the controller wants an executable regression for the specific graph-scope
distinction, the smallest proposed probe is one D_N answer/local input
`{id:1,value:0,mode:answer}`: retain the q-possible delivered-e state above,
compare original/deleted caller edge readiness, and verify identity matching and
no new maxima for this deletion-only graph. This would check a transcription of
the analytic construction, not establish the arbitrary-candidate implication or
public realizability. It is proposed, **not run**. No search campaign is needed.

## Remaining obligations

- Independently challenge the forced-immediate caller-match proof, especially its
  reliance on mandatory delivery/selection facts and no post-freeze work.
- Bridges A and C still determine arbitrary weak-path guard stability and legal
  authorization-history extension. B_op alone is not ARG-2.
- Candidate-specific progress/nondivergence and operational-limit premises
  remain mandatory; the argument supplies no arbitrary-implementation bound.
- A_pub realization/correspondence remains separately checked per candidate.
- The controller must reconcile any integrated conclusion with both manuscript
  representations. This report leaves the existing conditional ARG-1/open ARG-2
  status unchanged and edits no paper or historical source.

## Inspected source identities and actual checks

Worktree: `/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan`.
Observed HEAD: `bec75fa3db8cdafb6295f3d0e8ebb619400c1f36`; initial `git status
--short` output was empty. The approved W hash matched the controller dispatch.
All following SHA-256 values were computed locally in this task:

| Source | SHA-256 |
| --- | --- |
| `docs/foundational/phase1i/01-substitution-contract.md` | `cadd87220e6b9a06ccb597dc808b31ddae072d486d13feb703e0fb480294d865` |
| `docs/foundational/phase1n/01-contract.md` | `001c1fe5cd7be722aa75ae00a2be84ec702b51783a5595754d38ec8e6b2d8fd9` |
| `docs/foundational/phase1n/02-lifting.md` | `53bf70cb2aad625b4d5a3a753610ba271c84e738f557904860988350cbe40e54` |
| `docs/foundational/phase1n/evidence/reviews/reference-r1.md` | `c6f5adf78ffa283a88a31ab417700a9b72f25ea07a6cb5ee54238ae716ad3246` |
| `docs/foundational/phase1o/01-weak-contract.md` | `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000` |
| `research/substitution/model.go` | `1faef47e9ef17401512aba14239fc07ad7031a6db249600844752b35db342ddf` |
| `research/substitution/candidates.go` | `670d0265608ff7c519b6838bd65485427f231591516aaa6f75d8ad42566ade69` |
| `research/substitution/relation.go` | `4d4977eb96432269fbff9b550c74fd59527b3d3df5833d46f0cda1e77961a6be` |
| `research/substitution/callable_join_local.go` | `d918c235822262b0c630d6ce69721036d2b614a5e4020585c3e9b86ed68275fb` |
| `research/substitution/invocation_join.go` | `dac14d762e71d4db2ae6d920705bcec7d080929275a6425918cf94783cd37dc0` |
| `internal/executor/program.go` | `4a6813c69d509dff545c75a05410919e182e73c9f06e5fd359112e64df568374` |
| `author/invocations.go` | `3e1a8592fedc3ab95e4a58f2ce12fd535027929b96d4b9a9852847ae59797e35` |
| `author/compile.go` | `45e5ede143a60159d3beeb970c2e17adf1989f5c788fb4107e506034fbf58307` |
| `.superpowers/sdd/00-plan-phase1o/task-2-brief.md` | `ef9b3da6ce8888bba419e6cbbd7bbf48fe6cabad025e9aad6f84f73d69ead967` |
| `.superpowers/sdd/00-plan-phase1o/constraints.md` | `04cc24b4b994214e7aba7f83ff0ee1242c296401d885c0d3c67c3fea1f862584` |
| `.superpowers/sdd/00-plan-phase1o/task-2-bridge-instructions.md` | `b42fa70fbb7d525f7017fc26aadce3bab8c843db0e41f0d17c9f81bf9655d717` |

Actual checks: read the assigned brief first; read constraints and bridge
instructions; read the approved definition and the cited unchanged source slices;
inspected status/HEAD; computed the source digests. Read Go how-to/navigation
guidance for source inspection; no broad dependency audit was performed. No
tests, finite-state searches, runtime executions, renders, code/paper edits,
commits, pushes or child agents were performed. Only this scratch report was
written. The q construction is an analytical derivation, not executed evidence.
