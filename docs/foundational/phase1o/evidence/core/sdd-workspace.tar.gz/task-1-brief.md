## Task 1 — Freeze the exact implication and candidate domain
- [ ] Record baseline/protected identities and the precise historical clauses being interpreted.
- [ ] Define the weak relation, admissible candidate class, environment domain and progress predicate independently of the desired conclusion.
- [ ] Create the premise-provenance table below and resolve or explicitly identify material ambiguities.
- [ ] Obtain independent semantic review before using these definitions to accept or reject candidate experiments.
Separate the two local domains
Define W_full(X, R_w) as the original K1 relational, safety and readiness clauses over its full original local initial-state domain. Define Progress_full(X) as its separately required mode-progress and nondivergence clauses. Complete original local conformance requires an eligible relation and the applicable progress obligations. Do not confuse this local domain with the five historical context-product censuses.

Use W_N and Progress_N for those same unchanged obligations restricted to the aligned Phase 1N local domain below. This notation separates existing requirements; it does not weaken or strengthen K1:
- id{1,2} × value{0,1} × mode{answer,fail,absent,pending};
- candidate entry depth2, cap3, residual I=R3, E0, one q debit;
- closure transitions retained for local safety/readiness, as in CallableJoinLocalConfig;
- a separate open/no-closure progress check, as in QualifyCallableJoinLocal.
The composed positive environment E_N has full I=R4 after including J and excludes cancellation/retirement. Keeping closure in the local safety check does not introduce cancellation into that composition profile.

The immediate target is:
For X in the declared admissible candidate class, under E_N:

    (there exists R_w satisfying W_N(X, R_w))
    and Progress_N(X)
        implies
    (there exists R_g satisfying ARG1Compatible_N(X, R_g)).
ARG1Compatible_N must include ARG-1's permitted guard-stable weak alternative, not just its sufficient single-event special case.

A proof of this profile implication can support the full-premise implication by justified restriction of both W_full and Progress_full. A negative candidate satisfying only W_N and Progress_N does not automatically refute that full-premise implication. Either establish the original full local conformance for that witness or label the result profile-scoped. Full local qualification is distinct from rerunning all historical context products.

A universally quantified input-family claim requires the candidate premise over that family. One bad composition input can refute such a claim only after its corresponding agent-conformance premise has been established.
Preserve existential and strategy quantifiers
The target asks whether some suitable strong relation exists. It does not require every weak witness to extend.

Allow nonfunctional relations, alternative related reference states and alternative finite matching paths where the original definition permits them. A single relation, or coherent configuration-indexed family, must cover all relevant reachable component and environment choices under one fixed identity renaming. Separate favorable certificates for completed traces do not establish simulation.

Do not require a reference choice before observing the candidate event it matches unless the original semantics requires that order. Conversely, do not use hindsight to choose incompatible matches for the same related state and future obligations.

Keep three propositions distinct:
1. This supplied weak relation cannot be extended.
2. This weak-conforming candidate admits no ARG-1-compatible relation.
3. This weak-conforming candidate breaks K_join when placed in J.
Only the third is a contextual behavioral counterexample, with its reference and progress premises established.
Make visibility and ownership explicit
Specify the state projection and the ordered visible events, including multiplicity, payloads, charges, refusal reasons, terminal facts, original identities and atomicity. Specify which transitions may be hidden and exactly which facts a private stutter must preserve.

Map every choice to the written K1 contract, its fixed transition semantics or a separately identified environment assumption. Distinguish the abstract candidate class from the publicly authorable subset.

Audit candidate-owned, caller-owned and environment-owned actions separately. Original invoke_commit and outcome_consume events can be caller-owned while carrying Environment=false; that implementation flag alone is not a proof that an arbitrary candidate may control them. Equally, the prose clause about bilateral declared environment readiness must not be silently expanded to all actions without justification.

A candidate must not gain powers unavailable in the admitted semantics: changing caller/S state, reading retained authorization variables, adding operations, supplying undeclared inputs or releasing pending work. If such a restriction comes from fixed operational ownership rather than the weak relation, say so.

Use a compact table:
ARG-1 requirement	Original clause or operational rule	Status	Evidence
Each required identity, protocol, outcome, closure, ledger, depth, demand, readiness and progress condition	Exact source	Derived / independent E_N assumption / additional / ambiguous	Lemma, certificate or precise gap


Do not define admissibility by the very intermediate guard stability that ARG-2 is meant to establish. If K1 is materially ambiguous, preserve the plausible interpretations and explain their different consequences. Do not silently choose a stronger reading for a proof or a weaker reading for a counterexample. A proposed future clarification must remain separate from unchanged K1.
