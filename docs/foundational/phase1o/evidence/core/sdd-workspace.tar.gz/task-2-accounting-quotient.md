# Phase 1O Task 2 — accounting quotient follow-up to R1-1

Status: **R1-1 is substantiated. The earlier universal closure claim is not
established.** The source argument currently supports candidates with an
identified state-respecting semantic account. The unrestricted raw-state case
needs the quotient/representation result below. This is an open proof obligation,
not a demonstrated specification gap, qualified negative, or contextual failure.

This report corrects the representation claim in my frozen demand-normalization
report; it does not alter that report, Bridge C, the frozen definitions, or the
rejected integrated argument. No concurrent correction or demand-adversary
report was read for this follow-up. Findings were sent only to the controller.

## 1. The exact distinction

K's initial tickets and their update laws are accepted. They give lawful
accounting along a semantic history. The prior proof additionally needed exact
accounting to be an observation of the **same X states quantified in the target**.
These are distinct assertions.

Let X have raw states S. Let Xhat be a proposed history-accounted extension with
reachable states Shat, projection pi:Shat -> S, and original demand
Dhat:Shat -> U. U may denote the named unspent ticket set or its cost; the
possible/excluded distinction below changes both. Let K have demand DK.
Suppose the normalization argument gives Rhat contained in Shat x States(K).

The desired raw relation would be

```text
R = { (x,k) : there exists xhat with pi(xhat)=x and Rhat(xhat,k) }.
```

That formula is a relation on the original S. Whether it is eligible for ARG-1
also depends on a well-defined original demand observation DX on S. Merely
projecting transition pairs does not supply DX.

## 2. Two different quotient lemmas

**Operational projection lemma.** Suppose the accounting extension is
conservative in the following strong sense:

- Original initial states are covered; each accounted history projects to an
  actual original history with the same mandatory facts and atomic groups.
- Every original edge x --a--> y has a lift from **each** reachable xhat over x,
  projecting to that same edge. The lift does not filter a continuation or add
  a preparatory original/private action.
- Every extension edge projects to an allowed original edge; declared
  environment events project immediately with the same facts and ledger change.
- The other required state observations and original identities descend through
  pi, and Rhat supplies the corresponding transfer/readiness obligations.

Then the projected R satisfies those operational transfer/readiness obligations.
Proof: from an included (x,k), choose its witness xhat once. Lift the actual X
edge from that xhat, apply Rhat's matching obligation from the existing k, and
project the resulting related endpoint. For a reference-enabled environment
step, Rhat supplies the immediate extension counterpart, whose projection is an
immediate original counterpart. All included pairs are covered. This explains
why the prior all-successor argument was necessary and useful.

**Exact-demand factorization lemma.** A demand observation DX on the original
reachable S can preserve **all** original accounted demands precisely when

```text
pi(xhat1) = pi(xhat2)  implies  Dhat(xhat1) = Dhat(xhat2)
```

for the accounted states/histories whose preservation is claimed. Equivalently,
Dhat = DX composed with pi. Necessity follows by evaluating DX at the common
raw state. For sufficiency define DX(x) using any accounted state over x; the
condition makes that definition independent of the choice. If Rhat already has
Dhat(xhat)=DK(k), the projected R then has DX(x)=DK(k).

Only the demand value must be constant on these fibers; the complete accounting
history need not be uniquely recoverable. A unique private-PC map is unnecessary.
An existing semantic abstraction from raw state to tickets would suffice, even
if many raw states represent the same accounted state. Conversely, different
raw histories may be retained without difficulty when their demands agree.

This factorization condition is in addition to operational conservativity.
Neither one implies the other. The prior proof established neither a general
factorization nor another valid raw-state demand construction.

## 3. The reviewer's merge defeats automatic factorization

Consider the stated region after original e input consumption, before any h
commitment or local mode action. e's charge and all mandatory protocol facts
agree. There is no future helper action from the raw merge state m.

```text
H_L: ... input consumed ; lawful local exclusion ; raw state m
H_P: ... input consumed ; private work           ; raw state m

m's future: the original no-helper mode action and its fixed protocol suffix
```

On H_L, h is excluded. On H_P, h remains possible at m and is lawfully excluded
in the semantic abstraction of the later no-helper mode action. The latter
uses the existing weak-path allowance for adjacent internal choice; it does not
split the original action or insert a durable service checkpoint. There is no
helper commitment, ticket resurrection, added debit or change in eventual mode
behavior on either history. The same pattern applies to the prescribed local
Send, fail/absent End, or unmatched pending boundary. This schema diagnoses
accounting representation; it is not an independently qualified A_op candidate.

At m the two demands differ by h's `(1,1,0)`:

```text
Dhat(H_P) = Dhat(H_L) + cost(h).
```

The normalizer relates H_P to reference choose and H_L to reference local mode.
Both can support the only remaining raw no-helper mode edge and all eligible
q/closure/service edges. Thus the all-successor condition can hold perfectly:
there is no forbidden helper edge for it to expose. Nevertheless demand is not
constant over pi^{-1}(m). No single DX(m) equals both original values.

This establishes that the proposed **all-history exact-demand quotient lemma**
does not follow from legal ticket histories plus all-successor operational
projection. It does not establish that an independently specified original X
satisfies every W/Progress premise yet has no possible ARG-1 witness. Whether
m is really one X state or two accounted semantic states is exactly the
representation question the original proof must answer.

## 4. Why obvious repairs do not prove the missing result

**Keep both reference pairs.** Nonfunctional R is permitted, but cannot make a
fixed DX(m) simultaneously equal two different DK values. Nonfunctionality
solves choice of counterpart, not an ill-defined source-state observation.

**Keep only the possible counterpart, or only the excluded counterpart.** That
can remove the contradictory pair. It does not preserve both original accounted
histories. Choosing possible forgets H_L's actual exclusion; choosing excluded
anticipates H_P's not-yet-taken exclusion. A new proof could conceivably derive a
state-respecting accounting convention compatible with the original target,
but the current construction has not done so. It may not silently replace the
original accounted demands by a preferred one at the merge.

**Choose an accounting subfamily.** A useful prospective result would select a
subextension that is initial-covering, closed under every original edge, and has
fiber-constant demand, and then prove that its observation is the original
permitted demand of X. The last clause matters: selecting a favorable account
from a nondeterministic observer is not automatically exact preservation of
all actual accounts. No such selection theorem is supplied by the earlier proof.

**Use maximum/minimum demand over the fiber.** Either choice gives a function,
but neither equals both original values in the schema. This replaces exact
accounting by a new over/under-approximation. The unchanged target requests
exact future demand, not just the prefix budget inequality. Defining demand by
future helper reachability likewise violates the fixed initial-ticket convention.

**Declare the history part of X.** This gives a sound accounted-state target if
made explicit: `(m,possible)` and `(m,excluded)` are then different semantic
states. It is not a demonstrated relation on the unchanged raw X. A conservative
extension theorem for transitions alone does not repair that change of domain.
Bridge C's explicitly permitted retained-authorization augmentation does not
license an unrelated accounting-state augmentation by analogy.

## 5. What the frozen sources establish, and what remains supported

- K:153–176 supplies the original ticket states, fixed initial demands and
  lawful changes. K:97–98 and the reference rules at `model.go:274–287` supply
  branch effects. These do not themselves assert that different lawful prefixes
  ending in an arbitrary raw candidate state have equal ticket state/demand.
- K:218–225 and W:244–247 quantify relations between M/X states and K1 states.
  They do not replace X with its history unfolding when assessing the stronger
  endpoint-demand predicate.
- W:104–122 permits arbitrary finite private representations while fixing
  operational ownership/kernel rules. W:172–175 requires accounting facts when
  assessing demand. These support enforcing the laws, but the prior proof did
  not derive from them a universal fiber-constancy or quotient result.
- The historical model explicitly includes Ticket and Choice in Operation and
  every Operation in State (`model.go:49–81`). For these graphs the two different
  accounting boundaries are different states. Their state representation cannot
  be generalized to every arbitrary finite X without an argument.

The presently justified scope is therefore X with a fixed state-respecting
semantic account (explicit fields or an independently established abstraction
DX on the original X state space) obeying the original rules. For that scope,
original demand at an Rg pair is defined and the earlier postponing normalizer
can use it without changing X. The independent review did not identify a
counterexample to this conditional construction; it still requires its stated
W/Progress and other bridge premises.

For a raw X supplied only with a history accounting, either prove a valid
factorization/selection result with the original demand interpretation and
atomic groups, or explicitly state an accounted-state interpretation/domain
hypothesis. Until then the broader representation case is **unresolved**. This
is a proof limitation demonstrated by the failed quotient step, not a conclusion
that the source specification is intrinsically ambiguous or that ARG-2 is false.
My earlier report's assertion that W4 alone had closed this representation step
was stronger than the argument established; R1-1 should remain recorded.

## 6. Progress and experiments

None of the quotient reasoning derives progress from safety. If an accounting
extension merely annotates original edges without filtering or adding execution
steps, original progress remains an independent premise. If it inserts steps,
a separate conservative progress/fairness argument is required. Neither route
makes the exact-demand factorization automatic. The merge has a finite local
suffix and no helper future, so assuming nondivergence does not force its two
past demands to coincide. Designated pending remains an unmatched receive.

No finite probe is needed for the factorization lemma or the two-value merge
obstruction: both follow directly from equality. A tiny executable annotated
merge could confirm a transcription, but cannot decide whether all original
A_op representations admit an eligible accounting quotient. No tests, solver,
candidate acceptance, runtime execution, code/paper edit, render, commit or
subagent occurred. Only this new scratch report was authored.

## 7. Inspected identities and self-review

Worktree: `/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan`.
HEAD checked: `bec75fa3db8cdafb6295f3d0e8ebb619400c1f36`.
Read the exact R1 review and rejected argument, then the cited frozen definition,
K1 and model slices. Commands were focused source reads and SHA-256/HEAD checks.

| Inspected source | SHA-256 |
| --- | --- |
| `docs/foundational/phase1o/evidence/reviews/task2-r1.md` | `2e641ee83da8c9d1ec0ccc0d47f5d4fdd7c283bdc168bf1a4af61c83e9afb45c` |
| `.superpowers/sdd/00-plan-phase1o/task2-r1-rejected-argument.md` | `7d37091194cc5e283ae9007959fc56b5ad64fa1f78d04f9752b2a04554b13d21` |
| `.superpowers/sdd/00-plan-phase1o/task-2-demand-normalization.md` (unchanged) | `d15b34ad267c9cac7d99fe5d1e7caab24a54a58d2e6a0ba04cd718e91dfb12fe` |
| `.superpowers/sdd/00-plan-phase1o/task-2c-report.md` (unchanged) | `f2f0cb3018292974598b9e77dc28c66975f11b8cf49a6857f5529e3ff568e8ae` |
| `docs/foundational/phase1o/01-weak-contract.md` | `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000` |
| `docs/foundational/phase1i/01-substitution-contract.md` | `cadd87220e6b9a06ccb597dc808b31ddae072d486d13feb703e0fb480294d865` |
| `research/substitution/model.go` | `1faef47e9ef17401512aba14239fc07ad7031a6db249600844752b35db342ddf` |

Self-review: operational edge projection and observation factorization are
separate; both histories in the merge have legal continuations; no helper edge
is needed to expose the problem; raw-state nonfunctionality cannot repair a
fixed observation; selecting a subfamily cannot silently erase original
accounting; the corrected scope is explicit; no raw candidate counterexample
or demonstrated specification gap is claimed. Prior reports remain preserved.
