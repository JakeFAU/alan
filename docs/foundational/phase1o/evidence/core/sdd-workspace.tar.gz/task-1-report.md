# Phase 1O Task 1 report — weak contract and candidate domain

Status: DONE_WITH_CONCERNS, ready for the controller's independent semantic
review. This is a definition/provenance result; ARG-2 remains unresolved and no
candidate acceptance/search or contextual counterexample is claimed.

## Question and result

Question: does unchanged weak K1 local conformance, including its separate
progress obligations, supply some relation satisfying the final Phase 1N ARG-1
premise for the fixed callable join?

The new contract freezes the exact profile implication with existential weak
and suitable-relation witnesses; distinguishes D_full/W_full/Progress_full from
D_N/W_N/Progress_N; keeps closure in local safety and excludes it from positive
E_N composition; and includes ARG-1's permitted guard-stable weak alternative.
It specifies ordered visible facts, atomic boundaries, ownership, candidate
versus public-authoring scope, a provenance table, and the remaining interpretive
choices. It does not prove the implication or silently adopt a stronger K1.

## Files and identities

Owned worktree:
`/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan`.
Branch: `codex/phase1o-weak-refinement`.
HEAD: `42c837f545ae60676935c3f46e38d17d98f009df`.
Tree: `5cf3fc7094df1bff097b639f9141c63e04bac04e`.
Reviewed head `765226b88edd65536586cb06c4df3f53c85c4390` is an ancestor and has
that same tree. These are local checks, not a new fetch of remote main.

| Written file | SHA-256 / disposition |
| --- | --- |
| `docs/foundational/phase1o/01-weak-contract.md` | `bbf8e0923d2819b3658c73bca0471cd07421b5a8b9490ab3680ea00b28dee225` |
| `.superpowers/sdd/00-plan-phase1o/task-1-report.md` | This report; its hash is emitted after writing for the controller's package, avoiding a self-referential digest. |

Input brief SHA-256:
`50b200c6b79cbe41b3818886ba34c938b993692b54bde539c91a32327f6ef90a`.
Constraints SHA-256:
`04cc24b4b994214e7aba7f83ff0ee1242c296401d885c0d3c67c3fea1f862584`.
The inherited K/N/L/R1 hashes appear in the contract's source table and were
checked against the controller baseline manifest. All 35 manifest entries
matched; none was changed. The existing controller baseline file was read only.

The only worktree writes are the two assigned paths. Temporary drafting copies
were written under `/private/tmp/phase1o-task1-{contract,report}.md`. Scoped
sandbox escalation copied each authorized document to this external linked
worktree; no broad permissions or repository mutation was requested.
No historical sources, code, paper, ledger, dependencies or other task files were
edited. No subagent was spawned, no commit/push/merge was made, and no render ran.

## Decisions and precise provenance

1. **Domains.** K:202–216 and `relation.go:21–40` define the full local product,
   independently of the five contexts. The 3,072 count is arithmetic only.
   `callable_join_local.go:5–8,178–219` defines the depth2/cap3/I=R3/q profile and
   separates closure-enabled relation checks from open progress. N:177–222 pins
   full I=R4/fixed1 with the prior J debit and original S as the only q debit.
   Full-premise and family quantifiers cannot be refuted from a smaller premise.
2. **Quantifiers.** K:218–245 permits asymmetric branch/path choice and private
   control differences. The task requires one coherent relation/family and fixed
   renaming. The contract permits nonfunctional relations, alternate reference
   states and paths, and event-responsive choices; it rejects incompatible
   hindsight certificates. R_g need not extend a supplied R_w.
3. **Ownership.** `model.go:230–242,375–423` assigns original e commitment and
   selection to the caller while marking them `Environment=false`.
   `candidates.go:17–43,56–69` preserves those actions for historical A/B; it is
   not evidence about every abstract/public candidate. K:94,105,122–124 and the
   declared fixed operational interface justify ownership separately. Bilateral
   K:226–231 readiness remains limited to declared environment service.
4. **Candidate class.** A_op permits varied finite local/private instructions
   under fixed caller/protocol ownership; it does not assume conformance,
   intermediate guard stability or progress. A_graph, an unconstrained labeled
   graph able to add caller guards, is a distinct broader reading. A_pub needs
   an independent public instruction correspondence. No A_op=A_pub claim is made.
5. **Visibility.** K:71–106,218–225,288–304 requires original identity, payload,
   charge, terminal, protocol and selected outcome facts. `oracle.go:12–22` and
   `model.go:181–423` give their concrete representation/order. Coarse terminal
   status lives in successor Freeze, not the empty Observation.Status; the
   constructor's explicit status is normalized in `callable_join_local.go:78–80`.
   Repeated events, net-charge erasure or conflated Send/publication/selection
   are not accepted interpretations of the fixed event semantics.
6. **Atomicity.** K:86–88 treats terminal/freeze atomically and publication/delivery
   separately. Production publication/delivery can share one transaction
   (`invocation_outcome.go:499–568`); that expansion is not a checkpoint. Admission
   is atomic with child/binding/debit (`invocation.go:218–219`), and terminal
   capture retains the committed prefix (`invocation_outcome.go:220–288,571–621`).
7. **Authorization.** `messages.go:103–177` retains/reuses first authorization;
   source revision/generation checks precede the original bound reply exception.
   `invocation.go:123–140,296–312` distinguishes binding predicates and invocation
   refusal precedence. `invocation_outcome.go:164–184,354–373,426–440` preserves
   reply validation, waiting and accepted responses on failed End. These are
   fixed rules, not an arbitrary weak-relation extension proof. Public local
   instructions cannot acquire an undeclared retained-authorization input.
8. **Progress.** K:192–198,232–242 supplies the separate all-mode service,
   refusal/stuck and nondivergence obligations; the aligned maxima in
   `callable_join_local.go:104–165` show the concrete historical completion
   boundary. That checker's A/B rank is not an arbitrary candidate bound.
9. **Historical status.** Final R1:140–224 explicitly allows the guard-stable weak
   alternative and leaves ARG-2 open. Phase 1N's qualification/decisions/review
   preserve that disposition. Earlier lifting prose is not used as proof of the
   missing bridge. Markdown:562 / LaTeX:381 still state the same qualified status.

## Interpretive concerns retained for independent review

- **F_event versus F_fact:** whether every semantic model bookkeeping event is
  visible, or some contract-choice/control steps may be unlabelled under the
  prose's listed fact projection. Any permitted silence still preserves required
  ordered protocol facts; choosing local changes helper possibility/demand and
  cannot be declared guard-stable without analysis.
- **P_stage versus P_boundary:** whether all coarse `publicState` control/ticket
  fields are required endpoint-equality fields, or only the prose's named
  protocol/outcome facts plus operational consequences. The A/B erasure checker
  establishes one sufficient witness, not uniqueness of K1's projection.
- **O_op versus O_graph:** the fixed operational candidate class and unconstrained
  graph interpretation have different ownership powers. The task's A_op domain
  is stated independently; any negative relying on the broader graph's powers
  must be classified rather than called a realizable replacement failure.
- Caller-readiness, intermediate guard stability and authorization-sidecar
  extension still require proofs against the chosen readings. These definitions
  have not experimentally established different acceptance sets for the readings.
- ARG1Compatible_N follows the final reviewed conditional premises, including the
  weak alternative; it is not “passes the single-event checker.” The conclusion
  is existential, so failure of one supplied witness does not settle ARG-2.

No concern is hidden by accepting a candidate or changing K1. Independent
semantic approval of this freeze is still required before dependent acceptance
work. A review may approve a qualified domain while leaving a written-contract
ambiguity explicit; that is not approval of a stronger unchanged-K1 theorem.

## Checks actually performed

- Read the exact Task 1 brief and constraints first, then applicable repository
  AGENTS.md. The startup Superpowers skill was inspected and explicitly exempts
  dispatched subagents; no skill-driven approval or implementation workflow was
  imposed on this definition-only task.
- Inspected K1 in full, relevant N contract/lifting sections, final reference R1,
  later qualification/decisions/review status, model/candidate/relation sources,
  aligned local and lifted relation code, and the precise production paths above.
  No new public construction or runtime captures were inspected for a candidate.
- `git rev-parse HEAD`, `git branch --show-current`, both tree identities, and
  `git merge-base --is-ancestor 765226b88edd65536586cb06c4df3f53c85c4390 HEAD`:
  matched the assigned branch/base/tree; ancestry exit 0.
- Python SHA-256 comparison against every entry in
  `docs/foundational/phase1o/evidence/core/baseline.json`: 35 checked, zero
  mismatches. Hashes were computed for the output, brief, constraints and the
  additional inspected ownership/public-interface source files below.
- `git diff --check`, `git diff --stat`, `git status --short`: no tracked diff or
  whitespace failure; Phase1O is untracked new work (including the controller's
  pre-existing baseline). Since untracked documents are omitted by git diff,
  the contract was separately checked for trailing whitespace and balanced
  fenced blocks. The four-column provenance header was checked explicitly.
- Self-review against every Task 1 bullet: full/profile separation; E_N/closure;
  existential/strategy witnesses; weak ARG-1 alternative; visibility/order/
  multiplicity/atomicity; caller ownership; class versus public realization;
  non-circular admissibility; table provenance; distinct progress; review gate.
- Read-only searches initially named absent `internal/reducer`, `internal/author`
  and guessed reducer filenames; rg reported those paths absent. Actual files
  were located with `rg --files`/scoped search and the cited `program.go` paths
  were then read. No source or behavioral result depends on the failed lookups.

No Go tests, race checks, static analysis, reference/candidate searches, finite
censuses, public executions or renders were run by this worker. The controller
reported separately that its focused inherited baseline passed 21 leaves; this
report does not represent those as worker-run evidence or a new ARG-2 result.

## Additional inspected source hashes

These hashes pin files outside the contract's short K/N/L/R1 table. Hashing an
entire file does not imply every line received semantic review; cited ranges
above and in the contract identify the inspection scope.

| Source | SHA-256 |
| --- | --- |
| `research/substitution/oracle.go` | `9f7f5f59414c439392ab813759c6ed1c99f4be21aaa44f03a24cf953eb3899ad` |
| `research/substitution/invocation_join.go` | `dac14d762e71d4db2ae6d920705bcec7d080929275a6425918cf94783cd37dc0` |
| `research/substitution/consumer_reason.go` | `a2afb355e11b08f1d0a9cc302dbf7bcc181f24c7054ae59c4837e3327f00dc79` |
| `internal/executor/messages.go` | `1186fd9220d44352dcfd77ec5e7209dadd78d9956304a931593b5de6c6b8ae39` |
| `internal/executor/invocation.go` | `b40c1edc17249a31ccff84408a7855098e3a51ad28579ea856efc34bf4fa6746` |
| `internal/executor/invocation_outcome.go` | `adeaba4f04843867c5405a6bfb5a8716e64654a3e96bc58ad190ec23cbfcb53d` |
| `internal/executor/invocation_payload.go` | `652a5861e3dca171688b211d515fcd633f533b4cbb3e229f85787789f6b9c413` |
| `internal/executor/program.go` | `4a6813c69d509dff545c75a05410919e182e73c9f06e5fd359112e64df568374` |
| `internal/executor/store.go` | `4100327b3d95b44c061dad51f656fd193f26bc28c58093ecd2b385f9f76895bb` |
| `author/invocations.go` | `3e1a8592fedc3ab95e4a58f2ce12fd535027929b96d4b9a9852847ae59797e35` |
| `author/compile.go` | `45e5ede143a60159d3beeb970c2e17adf1989f5c788fb4107e506034fbf58307` |

## Remaining obligations and manuscript implications

The controller must package these exact bytes and dispatch independent semantic
review before Task 2 or later work uses the definitions for acceptance. The
substantive missing implication is not closed. No additional condition is
asserted necessary merely because a stronger historical checker uses it.
Future proof/negative work must retain reading/domain/family scope and its
independent progress/reference premises. Any public witness requires its own
realizability/correspondence gate. Phase-end manuscript reconciliation remains
assigned to the controller; Task 1 has checked the existing ARG-1/ARG-2 status
without editing Markdown, LaTeX or bibliography.


## R1 nonblocking clarification — 2026-10-30

Independent review `docs/foundational/phase1o/evidence/reviews/task1-r1.md`
returned specification APPROVE and semantic/research quality APPROVE for the
qualified definition gate. Its sole nonblocking finding noted that the paragraph
following the correct numbered relation definition could be read as allowing an
event-dependent replacement of the starting reference state.

Changed only that paragraph: every already-related `(x,k)` retains its starting
k; the path from k and related successor k' may depend on the candidate event.
Nonfunctional relations remain allowed, but every included pair must satisfy all
obligations. This clarifies the existing quantified definition without changing
its domain or premises. Scoped reviewer confirmation remains the controller's
gate before the shared lemma freeze.

Pre-edit SHA-256: `bbf8e0923d2819b3658c73bca0471cd07421b5a8b9490ab3680ea00b28dee225`.
Post-edit SHA-256: `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`.
The controller's `.superpowers/sdd/00-plan-phase1o/task-1-approved-r1.md`
exactly matched the pre-edit bytes. This report's prior bytes, SHA-256
`6ecc9c4f899481a73366951eace29a65c2efad9e56a127cb98540a1cf0941690`,
are preserved verbatim as a prefix; this section is appended only.

Exact contract diff:

```diff
--- approved-r1/01-weak-contract.md
+++ clarified/01-weak-contract.md
@@ -269,3 +269,5 @@
-The witness may choose a related reference state and matching path after seeing
-the candidate event being matched: the quantifier is `forall event, exists path`,
-not `exists preselected path, forall events`. All successors used remain in the
+For each already-related `(x,k)`, the matching path from k and related successor
+k' may be chosen after seeing the candidate event. Nonfunctional R remains
+allowed, but every included pair must meet all its obligations. The quantifier
+is `forall related pair, forall event, exists path from k`, not
+`exists preselected path, forall events`. All successors used remain in the
```

Checks: exact pre-edit/approved-snapshot equality; unique byte replacement of the
one paragraph; unchanged bytes before and after that paragraph; exact new hash;
report-prefix preservation; and no trailing whitespace or unbalanced Markdown
fences in either output. The receiving-code-review skill was used to compare the
finding with the numbered definition before editing. No tests, candidate
searches, renders, other source changes, commits or delegation were performed.

A draft whitespace check caught the blank context-line prefix in the embedded
unified diff; the report now uses an exact zero-context diff. That failed draft
check changed no worktree file. The final document checks passed.
