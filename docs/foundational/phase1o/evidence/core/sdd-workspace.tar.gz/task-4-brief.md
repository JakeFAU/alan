## Task 4 — Classify and minimize the result; execute only informative witnesses
- [ ] Establish the original premise before presenting a candidate as a counterexample.
- [ ] Minimize substantive witnesses without changing their assumptions or erasing causal events.
- [ ] Decide whether a public execution resolves a concrete realizability/correspondence question.
- [ ] Independently review the strongest supported conclusion and its limits.
Use the following categories:
Result	Permitted conclusion
Reviewed normalization/extension argument for every candidate in an explicit class	ARG-2 closed for that class and named environment
One witness fails, another eligible witness exists	Certificate/normalization-choice failure
Weak premise and progress hold; no eligible ARG-1 witness exists	The certificate implication fails in its stated scope; J may still behave correctly
Weak premise/progress and J[K1] premise hold; J[X] violates K_join	Genuine bounded substitution counterexample in the qualified domain
Old admissibility/readiness/progress/conformance fails	Invalid attempted witness or useful negative control
Only a bounded candidate family passes	Bounded support; generic ARG-2 remains open
The original clauses do not determine a necessary ownership/visibility rule	Exact specification gap, with consequences stated per interpretation
A checker/search cannot decide within its justified resources	Incomplete result with the unresolved obligation retained


Failure of a sufficient proof method does not by itself justify strengthening K1 or repairing the runtime. Keep any proposed weaker lifting rule or future contract clarification separate from the unchanged target.

A no-witness certificate may require a finite branching game. A genuine contextual failure may have a concrete linear execution. Preserve the appropriate object; do not demand that every logical negative be a runtime trace.
Public realizability gate
Add a separately authored public candidate and focused consumer only when it establishes something specific:
- a noncanonical yet accepted implementation with a checked relation;
- an authentic realization of a meaningful model counterexample; or
- the exact public-interface limitation of a proposed semantic witness.
J/O source and policy remain frozen; new template bindings/catalogue identities must be documented. Before any runtime conclusion, map the new candidate artifact and original emitted handles, selected observations, authority/binding decisions, charges and publications. Use supported public operations and unchanged automatic scheduling or a clearly labeled supported driver.

Do not alter authoritative state, invent outcomes or change production semantics to realize a witness. A model-only obstruction stays model-only if the public interface cannot express it. If the proof settles the question without an execution distinction, no additional runtime campaign is required.

No new recovery, effect, scarcity or topology cross-product is required.
