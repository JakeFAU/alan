# Phase 1O — Result classification and public realizability

Status: **source classification draft; Task3 outcomes and independent Task4
review pending**. This records the conditional source result approved by
[Task2 R2](evidence/reviews/task2-r2.md), preserving the rejected universal claim
and [R1 finding](evidence/reviews/task2-r1.md). Expected finite outcomes are not
executed results or candidate acceptance.

Source baseline: `ffd00be531fbb986b86160bd6c22a87345fee14a`. R2 identifies the
corrected [argument](02-arg2.md) by SHA-256
`ca3def80b384335694afcd97c68202e6d93821aad414ac305dc701495599e84c` and frozen
[interpretation](01-weak-contract.md) by
`ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000`.
The controller pins [03-finite-contract](03-finite-contract.md), including §8,
at SHA-256 `a41c2216caa80d979365e61470dce6fc03c2616ad6f2faeab2e2431b0418a083`.
These are inherited source identities, not newly rerun checks or runtime evidence.

## 1. Exact claim and scope

The unchanged unrestricted target is:

```text
forall X in A_op:
  (exists Rw. W_N^sigma(X,Rw)) and Progress_N(X)
    => exists Rg subset States(X) x States(K1).
         ARG1Compatible_N(X,Rg), under E_N.
```

For **P_boundary under either F_event or F_fact, ARG-2 remains OPEN**.
Visible-history alignment does not by itself make demand a function of the
original X state. No universal accounting/quotient/selection theorem is supplied.

The approved source result adds `Account_N(X; alpha, lambda)` on the original
states and edges. With W and separate Progress_N it yields a suitable
original-state Rg under E_N. Account checks initial tickets, faithful state
accounting, ordered original edge updates, branch/mode order and all-edge/atomic
group coverage. Its checks do not assume reference-demand equality, ARG-1,
readiness or progress. It is an **additional sufficient representation
hypothesis**; its universal existence and necessity are unestablished.

Under frozen **P_stage**, W already compares original-state choice/ticket/demand
stages. The source argument retains Rw and derives the remaining bridge duties
under the named assumptions. This closes the source implication for that
stronger reading, not a derivation of P_stage from P_boundary or the historical
A/B single-event erasure checker.

D_N is D_full restricted to depth2/cap3/residual I=R3/q. Full W, Progress and
Account, when supplied, restrict configuration-wise to D_N, giving a full-premise
corollary for the sufficient class. A D_N certificate says nothing about
uncertified full configurations. An open-port fragment is narrower still. Local
closure/scarcity safety is distinct from the no-closure composition environment;
no new whole-profile or full-contract qualification is established here.

## 2. Premise provenance and lifting boundary

| Obligation | Derived source portion | Independent or additional premise |
| --- | --- | --- |
| A: guards and demand | Fixed extra choices preserve current constructor/protocol guards. Account supplies original-state normalization; P_stage supplies endpoint stage/demand equality directly. | Account existence for arbitrary P_boundary X remains open. Current-guard preservation is not demand equality. |
| B: caller and delayed selection | W plus fixed original caller rules gives immediate caller matches; original finite S service opens J's selection gate. | Owner framing belongs to A_op. Eventual eligible service and Progress are separate; the Environment Boolean supplies neither ownership nor readiness. |
| C: authorization | Given coarse transfer under E_N, compatible legal first-authorization histories have the stated retained-record extension; each run retains its own raw provenance. | Stable authority/binding, inaccessible sidecars and the coarse relation are premises. Permitted authorization histories do not repair missing X demand representation. |
| Composition | ARG-1-compatible relations support conditional lifting. | Reference/product premises, including the required J[K1] premise, remain necessary for K_join/G_outer preservation. Schema compatibility does not establish them. |
| Progress and bounds | Completion, designated pending and divergence remain distinct. | Candidate all-mode Progress_N and adequate concrete operational limits remain separate. Finite authorization counts are not a private-program rank or uniform runtime bound. |

E_N retains J's prior debit1, full I=R4, original S as sole q, stable
identity/authority/bindings, the open eligible caller, no closure/retirement/
release, eventual eligible service and adequate finite limits. These composition
premises do not follow from weak safety. A_op is narrower than arbitrary A_graph;
inspected public owner separation does not prove A_op=A_pub or general
compiler/runtime correspondence.

## 3. Failure classifications

| Object | Permitted conclusion |
| --- | --- |
| Accounted local example with premature Rw | Bad supplied strong witness: demand differs at private boundaries. A normalized Rg is supplied for the declared fragment. Rw failure is neither failure of every relation nor failure of J[X]. |
| Unresolved local/helper fork | The premature local pair cannot handle the actual helper commitment; normalized Rg preserves both actual choices. Pair/path strategy failure is not NONE. |
| Lawful possible/excluded merge | Representation diagnostic: two lawful history accounts over one raw m give different proposed demands. It refutes that supplied map/history-descent argument, not every faithful map or relation. No resurrection occurs. |
| Exclusion followed by imported helper commitment | Invalid original-history/accounting certificate: excluded/disabled h cannot commit. Reject it before weak-conformance or contextual classification; it is distinct from the lawful merge. |
| G_q | Analytic A_graph-only control: deleting caller selection while q is enabled can break local ARG-1 readiness, but violates A_op owner framing. In fixed J, S has spent q before e selection. No fixed-J failure or public realization follows. |
| Private divergence or postponed environment service | Separate progress/readiness failures. Matching completed outputs is insufficient; toy controls establish no A_op negative. |
| False late bound-reply denial or changed first record | Invalid legal/provenance certificate under stable binding. Legal revision/generation denials and nonreply checks keep their changed outside-profile premises. |

No conforming A_op negative, certificate-implication counterexample,
no-eligible-witness result, K_join violation, candidate acceptance-set difference
or exact specification gap is established. The missing proof is not classified
as intrinsic impossibility. Failure of a sufficient proof method warrants
neither strengthening unchanged K1 nor repairing the runtime.

## 4. Diagnostic minimization and finite boundary

The retained one-merge diagnostic is [03 §3.4](03-finite-contract.md): two raw
edges u→m align respectively to staying at B and lawful exclusion at L, followed
by one shared local reply edge m→z. The submitted history map requires both
`(2,2,0)` and `(1,1,0)` at m. Retain the common original entry-commit/admission/
input prefix, fixed spending, h possible/excluded distinction, unchanged m
identity and shared continuation. q/closure/later outcomes remain named
unassessed ports. Local future behavior does not retrospectively exclude h.

This is a small causal diagnostic, **not proved globally minimum**. Minimization
must preserve original premises, the two lawful accounts over one original
state, atomic boundaries and the continuation showing no resurrection. Splitting
m by history, deleting an incoming account, changing initial entitlement or
importing a helper edge changes the question. Before calling any future object
a counterexample, establish original admissibility, weak conformance, progress,
environment and, for contextual failure, J[K1] premises. Preserve the required
branching certificate rather than demanding that every negative be a linear run.

Task3 results are not incorporated. The frozen required checks have these
**prospective** limits, pending execution evidence and independent review:

| Fixture family | Maximum scope if validated as specified |
| --- | --- |
| F1–F4 | Toy machinery: nonfunctional relations/alternative paths, immediate readiness, safety versus divergence, ordered visible occurrences. No ALAN admissibility or whole-profile conformance. |
| F5 and invalid-history controls | Named original authorization/provenance legality and harmless well-formed unreachable data. No semantic NONE result. |
| Original branch/accounting and raw merge | Original finite rule instances and the supplied inconsistent accounting-map diagnostic; no W_N/W_full or complete progress. |
| §6 normalization/helper fork | Declared F_fact/P_boundary fragment, fixed state/edge account, all in-scope q/closure readiness, named endpoint-demand/current-guard clauses and alternative Rg. Not full ARG1Compatible_N. |
| §7 six J reply schedules | J's original diagnostic, both End statuses, first-record/admission timing, unresolved admission, invalid and outside-profile controls. Not runtime execution or an arbitrary-relation sidecar-extension proof. |
| Positive ranks/negative private cycle | Progress handling for complete declared toy graphs. Open-port fragments receive no complete progress/conformance verdict. |

Sharing inspected original rules establishes transcription checks, not
independent proof of those rules. Supplied paths are not an existence search;
a rejected path, relation, rank or map is never NONE. No search-completeness or
new full-profile census claim is intended.

## 5. Public-realizability decision

**No new public execution campaign is justified by this result.** The open
question quantifies over every permitted P_boundary candidate representation;
one public execution cannot establish that universal original-state theorem.
The approved conditional proof introduces no execution distinction requiring
realization. No qualified model contextual failure needs authentication and no
new public-candidate/compiler correspondence claim is made. An unrelated
accepted run would not supply the clause fixtures' missing premises.

This does not assert that the raw merge or any arbitrary graph is publicly
realizable or unrealizable. A separately authored candidate becomes informative
only for a concrete question: checked noncanonical public correspondence,
authentic realization of a qualified counterexample, or the exact interface
limitation of that witness. First fix candidate/consumer and map emitted handles,
selected observations, authority/binding decisions, charges and publications
under supported operations and unchanged scheduling or a labeled supported
driver. Retain J/O source/policy and document any new bindings/catalogue
identities. None of these new claims is needed here; no authoritative state
change or invented outcome is proposed.

## 6. Remaining obligations

1. Finish Task3's frozen checks, exact RED/focused verification evidence and
   independent review. Update this classification with actual scoped outcomes;
   expected outcomes are not passes.
2. Independently review Task4's strongest conclusion, minimization and no-campaign
   decision. This draft is not that approval or whole-phase acceptance.
3. Resolve unrestricted P_boundary ARG-2 with a faithful original-state account,
   a demand-preserving conservative quotient/selection, or another suitable
   original-domain relation; alternatively supply a fully qualified negative or
   demonstrated specification gap. Current evidence selects none of these.
4. Keep Account necessity, candidate acceptance-set differences, A_pub/compiler
   correspondence and uniform operational bounds unestablished unless separately
   proved/qualified. A finite fragment or single trace supplies none of them.
5. Reconcile final accepted claims with both manuscript representations in Task5.
   No code–paper reconciliation or manuscript change is claimed here.
