## Task 5 — Qualification, independent review, manuscript and delivery
- [ ] Verify the new argument/checkers and any justified concrete witness with focused checks.
- [ ] Obtain independent semantic and implementation/certificate review, then final whole-phase review.
- [ ] Resolve actionable findings and rerun affected checks with exact source identities.
- [ ] Reconcile Markdown/TeX, build the PDF once at phase end, inspect changed pages, and deliver a reviewed draft PR.
For new Go machinery, run the relevant normal/race tests, static checks, formatting and module verification using the actual pinned local toolchain, CGO and offline/readonly dependencies. Check test discovery and derive selectors from implemented names. Re-run affected historical gates only for an identified reuse/change risk or repository requirement.

Do not predeclare counts or passing commands. Record actual argv, environment, exits, search bounds, selected leaves, source hashes and certificate verdicts. Keep finite search, mathematical argument, certificate validation, source inspection and runtime execution as separate evidence categories. Source-review agreement does not make an argument machine-checked.

If a broad command times out, preserve it and identify unfinished work before targeted follow-up. Combined focused coverage is not a green monolithic suite. Corrected sources do not inherit old execution results without an explicit unaffected-source justification.

Use independent agents where useful for the three lemmas, adversarial examples and certificate validation. Keep one controlling definition/version for each gate. Freeze the weak interpretation before candidate acceptance, and prevent search output from redefining expected conformance.

Keep evidence compact: clause/provenance table, exact quantified argument, decisive certificates or witnesses, declared search domain, qualification/limits, source map, executed runbook and review disposition. Reuse historical evidence by pinned reference. New audit commands should read their immutable archive/commit inputs directly where practical, instead of requiring the live reconciled manuscripts to resemble a historical checkout. Any restoration must occur only in a disposable copy.

TeX remains the manuscript truth. Synchronize corresponding Markdown; preserve inherited formatting, mathematics and historical results. Update ARG-2 only to the scope actually established. A profile/class-specific result does not close arbitrary-context congruence or universal compiler correctness.

After source/claim review, run tectonic alan-dissertation.tex once from paper/ under the accepted warning policy and inspect changed PDF pages. Do not regenerate per implementation commit.

Finish the authorized scope when it yields a reviewed argument, minimized qualified witness, demonstrated specification gap, or honestly bounded unresolved result. Correct ordinary mistakes and test alternative witnesses before classifying a substantive failure. Do not expand the topology or silently adopt a stronger contract to manufacture closure.

The final report and draft PR must answer:
1. What precise version of unchanged weak K1 was formalized, and for which candidate/environment domain?
2. Which ARG-1 premises were derived, supplied by E_N, additional, or ambiguous?
3. What happened to each of the three bridge arguments?
4. Is the result about one certificate, existence of any suitable certificate, or actual J behavior?
5. Does it concern W_N, W_full, a finite candidate family, or a broader proved class?
6. What was proved, mechanically checked, searched, executed, source-reviewed, or left open?
7. What exact source/evidence identities and independent dispositions support that conclusion?
Draft only. The intended outcome is a sharper substitution criterion: establish what the current local contract guarantees, and expose any additional promise composition actually needs.
Pinned primary sources
- PR25
- Original K1 contract
- Exact ARG-1/ARG-2 review disposition
- Phase 1N qualification
- Original eventwise local checker
- Original transition semantics
- Candidate transcription and shared transitions
- Aligned local relation/progress checks
- Finite callable lifting checker
