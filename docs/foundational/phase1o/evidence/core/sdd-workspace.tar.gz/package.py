"""Package an explicitly scoped working-tree review without modifying Git state."""
import hashlib
import subprocess
import sys
from pathlib import Path

root=Path('/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan')
workspace=root/'.superpowers/sdd/00-plan-phase1o'
label,base,*names=sys.argv[1:]
output=workspace/(label+'-diff.txt')
assert not output.exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
parts=[f'Base: {base}\nCurrent HEAD: {head}; explicitly named working-tree files below.\n']
parts.append(subprocess.check_output(['git','log','--oneline',base+'..'+head],cwd=root,text=True))
for name in names:
 path=root/name
 assert path.is_file() and path.resolve().is_relative_to(root)
 data=path.read_bytes()
 parts.append(f'\nFILE {name} bytes={len(data)} sha256={hashlib.sha256(data).hexdigest()}\n')
 exists=subprocess.run(['git','cat-file','-e',base+':'+name],cwd=root,capture_output=True).returncode==0
 if name.endswith(('.gz','.pdf')):
  parts.append('Binary evidence: inspect exact compressed/format content as required; identity above.\n')
 else:
  argv=['git','diff','-U10',base,'--',name] if exists else ['git','diff','--no-index','-U10','--','/dev/null',name]
  p=subprocess.run(argv,cwd=root,text=True,capture_output=True);assert p.returncode in (0,1),(argv,p.stderr);parts.append(p.stdout)
output.write_text(''.join(parts))
print(str(output))
print('sha256='+hashlib.sha256(output.read_bytes()).hexdigest())
