from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path('/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan')
s=root/'.superpowers/sdd/00-plan-phase1o'
out=root/'docs/foundational/phase1o/evidence/core/sdd-workspace.tar.gz'
manifest=out.with_name('sdd-workspace-manifest.json')
assert not out.exists() and not manifest.exists()
files=sorted(p for p in s.rglob('*') if p.is_file())
assert all(not p.is_symlink() for p in files)
h=lambda b:hashlib.sha256(b).hexdigest()
entries={str(p.relative_to(s)):{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())} for p in files}
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as t:
 for p in files:
  b=p.read_bytes();i=tarfile.TarInfo(str(p.relative_to(s)));i.size=len(b);i.mode=0o644;i.mtime=0;i.uid=0;i.gid=0;t.addfile(i,io.BytesIO(b))
out.write_bytes(gzip.compress(buf.getvalue(),mtime=0))
with tarfile.open(out,'r:gz') as t:
 assert set(t.getnames())==set(entries)
 for i in t:
  b=t.extractfile(i).read();assert h(b)==entries[i.name]['sha256'];assert b==(s/i.name).read_bytes()
manifest.write_text(json.dumps({'scope':'Complete Phase1O plan workspace only; archived before scratch cleanup','archive_sha256':h(out.read_bytes()),'member_count':len(entries),'members':entries,'verified_against_live_workspace':True},indent=2)+'\n')
print('Verified',len(entries),'members; archive SHA256',h(out.read_bytes()),'bytes',out.stat().st_size)
