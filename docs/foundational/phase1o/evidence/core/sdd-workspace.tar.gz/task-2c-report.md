# Phase 1O Task 2C — independent retained-authorization argument

Status: **Bridge C closes as a conditional authorization-overlay lemma in the
frozen A_op / E_N scope. This does not close ARG-2.** No experiment or candidate
qualification was performed. The other bridge reports were not read.

## 1. Exact claim and scope

Question: can a weak local correspondence retain every legally possible first
authorization, rather than choosing a convenient authorization order or assigning
one canonical authorization record to a coarse state?

Let sigma be any frozen F_event/F_fact and P_stage/P_boundary combination, with
O_op. Let X be in A_op and R satisfy W_N^sigma. Augment the local operational
interface with the unchanged first-authorization protocol. Under E_N's stable
original authority/bindings and the fixed source/owner rules, R admits a
**history-indexed extension** that:

1. Covers every legal augmented X history whose coarse history is in the local
   premise, with a matching reference history from the original initial pair.
2. Gives immediate bilateral counterparts to every enabled first authorization,
   preserving its original intent, source, revision/generation, binding, actual
   source-open snapshot and first decision. Repeated lookup returns that same
   decision; it does not take a second decision.
3. Lifts each already available coarse matching transition/path without changing
   any previous first decision and remains closed under later protocol service.

For full J[X] histories, coverage is conditional on the coarse constructor
transfer and caller correspondence being established by Bridges A/B. When their
coarse relation exists, extend it with the same J/S/O state and the history
relation below; the authorization overlay adds no further premise in E_N.
**This report does not infer all constructor guard preservation, future-demand
equality, or caller readiness from the authorization lemma.**

The result is a source-based mathematical argument for the fixed abstract
interface, subject to independent review. It is not a new runtime qualification,
compiler correspondence proof, proof that A_op = A_pub, or theorem for arbitrary
A_graph transitions. A graph allowed to inspect/edit first dispositions or
invent commitments is outside this lemma's operational domain. No conclusion
about A_graph nonexistence or differing candidate acceptance sets is asserted.

The local result uses only mandatory protocol facts common to all named F/P
readings. Silent reference choices may change future demand and thus remain a
Bridge A issue; they cannot change an already committed original intent or a
source's terminal fact. Restricting a coherent W_full family to D_N suffices for
this local premise. E_N excludes closure/retirement: the result is not an
unqualified retained-authorization theorem for every D_full/D_N closure history.

## 2. What is retained and what equality means

For a legal prefix h, retain its original commitment records and, for each
committed intent i, either no first decision or its actual first authorization
record A_h(i). Also retain the decision's position in that legal prefix. Define
its semantic record to contain:

- original intent/operation and immutable commitment descriptor, including kind,
  payload and original source/target/obligation links;
- generation-qualified source identity, committed source revision, and the
  source revision/generation predicates at that first decision;
- original composition binding: protocol, source entry-member role, caller
  subject/generation and entry-port obligation, plus original parent/root links;
- source-open/retired facts at the decision, and its allowed/refused outcome and
  exact reason. The open snapshot is derived from its actual retained prefix;
  it is not reconstructed from the final state.

Equality means equality of these **normalized semantic records** under the one
fixed identity renaming. Each side keeps its own raw immutable record and raw
commit provenance. It does not mean equality of SQL bytes or private step counts.
In particular, Authority includes Epoch/Sequence/Revision (`store.go:58–69`),
Intent includes source Sequence/Ordinal (`program.go:80–88`), and raw replay
checks the authorization against its own source prefix
(`composition_replay.go:494–526`). Extra private instructions can give the two
runs different source sequences. K1 explicitly hides pure step count
(`K:290–297`); the reference is also an abstract graph, not a second raw runtime
execution. No raw snapshot is fabricated, overwritten, or reassigned to another
commit to obtain normalized equality. A proposed concrete witness still needs
its own raw identity/decoding correspondence.

This is a relation on history-distinguished augmented states. It is not a
function from a coarse local state to one sidecar assignment. For an original
J report, write c = reply commit, a = first authorize, t = End, d = reply admit.
The prefixes `c;a;t`, `c;t;a`, and `c;t` can have the same coarse committed,
terminal, not-yet-admitted report state. The first two have allowed dispositions
with different historical source-open snapshots; the third is unresolved.
All three are retained. Each is paired with the corresponding reference history,
not indiscriminately with the other two.

## 3. Fixed authorization rule and dependency provenance

`AuthorizeIntent` first loads the immutable committed intent and revision,
derives authorization identity from that intent, and retrieves an existing row
before examining current source status (`messages.go:103–127`). A changed
request descriptor conflicts; it cannot replace the first decision. A genuinely
new decision loads the source, identifies the original reply binding, checks
revision and generation first, then applies retirement/closure restrictions
except for that bound reply (`:128–177`). In this profile the formula is:

```text
FirstReady(i,h) = original commitment exists AND A_h(i) is absent
Allowed(i,h) = RevisionMatches(i,h) AND GenerationMatches(i,h)
               AND (not Retired(source,h) OR BoundReply(i))
               AND (SourceOpen(i,h) OR BoundReply(i))
```

Reasons follow the ordered switch, not an unordered conjunction. E_N fixes the
first two predicates true and retirement false. BoundReply requires all the
original tests in `invocation.go:123–140`; `intent.Kind == message` is essential.
An invocation never receives this exception.

| Dependency | Provenance and consequence |
| --- | --- |
| Same original commitment, request/payload, source/operation/result links, and terminal/closure facts | W endpoint equality and mandatory ordered facts; K:74–106,218–225,288–304. Source-open for an inner source is determined by terminal/closure (`model.go:138–143`). |
| Revision/generation stability, original grants/bindings and no retirement/cancellation | Independent E_N premise, N:195–199; not learned from W or a successful trace. |
| Correct caller/source identity at each operation | Fixed binding/interface plus the one immutable renaming; J calls e/S, e calls its helper, O calls J. Candidate instructions cannot change those owners. |
| No candidate access to authorization state | Frozen A_op interface; production reducer works on its own projection and rejects a closed source (`program.go:290–317`). It is not a new assertion that W alone enforces an ownership type system. |
| First row immutable; admission separate | Fixed production rules, `messages.go:103–177`, `invocation.go:218–224`, `invocation_outcome.go:172–184`. |
| Source-open agreement at a new decision | W mandatory terminal facts for e/helper; same fixed J/S/O state and E_N's open eligible callers for constructor-owned sources. This is not equality of all private PCs. |
| Authorization stability during reference silent choices | Mandatory commitment/terminal facts cannot be changed silently in either F reading. The reply-binding and authority premises are fixed. No helper demand/choice equality is needed for this specific guard. |
| Current admission/depth/budget/readiness agreement | W's bilateral original environment transfer and same ledger/depth, plus the separately established coarse constructor mapping. This report does not establish every Bridge A/B guard. |
| Progress/nondivergence and adequate operational bounds | Separate Progress_N and E_N premises; neither is a consequence of equal sidecars. |

## 4. Legal histories and extension construction

Use only histories generated by the unchanged operational rules. A sidecar
assignment is admissible exactly when such a history exists. Thus no decision
precedes its commitment; no first decision repeats; no admission precedes its
required authorization; no terminal/source snapshot precedes the terminal event;
and source revision/generation/binding evidence belongs to that original intent.
No Cartesian product of arbitrary allowed/refused/pending values is admitted.

Fix the identity renaming of R. For a pair of legal histories (h_X,h_K), require:

- Their coarse endpoints are in R (or the conditional coarse constructor
  relation for full J), and their mandatory original protocol words agree,
  preserving order, multiplicity and atomic groups.
- Their first-authorization occurrences agree in the normalized ordered word,
  each tied to its original commitment and source prefix; all corresponding
  retained first records agree as above.
- Any constructor state supplied to the relation has the same original J/S/O
  control and evidence as required by the coarse lifting argument.

Take **all** such compatible legal history pairs. Do not take all assignments
on equal coarse endpoints. Nonfunctionality is essential and harmless: every
included pair must satisfy the following extension argument from its own
already-related endpoints. We never switch the starting reference state after
seeing a candidate event.

**Initial pair.** There are no e/helper commitments or first decisions. The fixed
O-to-J entry prefix, when needed, has its same original invocation/authorization/
admission on both sides and initializes the local pair after the prior J debit.

**New authorization from either endpoint.** Same original commitment and same
absence of a first row give immediate readiness on the other side. Equal source
terminal facts, fixed revision/generation, and the original binding give the
same ordered predicate evaluation, snapshot and exact first result. Append
that event to both histories and keep the coarse endpoints unchanged. The pair
remains in the same relation. This is bilateral service for the added event,
derived from its guards; it does not reclassify caller-owned events in W.

**Repeated lookup.** A prior row is returned before current source checks. The
same old semantic record is returned on the other side. It is a retained-result
lookup/stutter, not another first authorization or a chance to revise a reason.
Raw source prefix evidence remains the original record's own evidence.

**An original coarse step.** Start from the given related pair and use W's
matching path from that same reference state. Every extra silent step on that
path preserves all original commitments and source terminal/closure facts.
Consequently it cannot change an existing authorization guard or historical
record. The actual matched commitment may make a *new* first authorization
ready; the actual matched terminal event may change current source-open while
leaving all earlier decisions unchanged. These intended changes occur at the
same position among mandatory facts. No extra hidden commitment, admission,
consumption, terminal event or authorization is inserted.

The ordered mandatory history ensures that a captured committed prefix at
freeze is the same original prefix. The proof never splits a commit/freeze
transaction or inserts an authorization inside an atomic original event.
For a coarse admission or reply-admission step, the split operational version
requires its prior row. Both sides have the same row, so W's existing immediate
environment counterpart is available with the same retained decision and
current guard evaluation. Other protocol steps keep the rows unchanged.

Induction gives a counterpart for **every candidate-side legal authorization
schedule**, not a selected favorable schedule. At every included pair, every
later first authorization from either side has its immediate counterpart.
Reference component choices remain asymmetric as in W; this does not claim
matching every unrelated K1 branch. Different future candidate events may
choose different paths/successors allowed by the same R, but each extension
ends in this same history relation and meets all future obligations. An
arbitrary authorizer invocation between candidate private instructions is
included: it is serviced at that actual boundary, with that run's own raw
sequence, rather than moved to a preferred earlier/later boundary.

The reference may have extra silent choice boundaries. They preserve the
particular authorization predicates above; an authorization commutes across
those choice steps without altering its semantic snapshot or record. This
establishes authorization-specific intermediate stability, not stability of
all demand or caller guards at those states.

## 5. Adverse orders, original invocations and subsequent service

**All reply/End orders.** For a committed valid bound reply with first admission,
`c;a;d;t`, `c;a;t;d`, and `c;t;a;d` are all legal. In the first two, the first
source-open snapshot is true; in the third it is false. The decision is allowed
in all three, for both successful and failed End. A later lookup after t in the
early case must return its old row. A first decision after t in the late case
must test the binding exception; it is not recomputation of a fictional early
row. No ordering between independent intents' authorizations is imposed.

For J specifically, the fixed Send precedes End and its normal failed decision
can retain a diagnostic. `callable_join.go:171–200` exposes authorization before
or after End without requiring admission before End. Production freeze captures
the committed prefix (`invocation_outcome.go:220–288,571–621`); preparation waits
for every captured reply admission (`:354–373`); accepted response presence is
retained for failed End as well (`:426–440`). The matched later service therefore
preserves the original report, status/reason and presence. Final totals or a
fresh post-End predicate calculation cannot replace these facts.

**Invocation has no reply exception.** In the fixed kernel, a first invocation
authorization after source End is refused `source_closed`. An authorization
allowed before source End remains allowed, but a first later invocation
admission still checks current source/revision and scope
(`invocation.go:296–312`). Thus “retained allowed” does not imply “admissible
forever.” The two histories can produce distinct exact refusal reasons; this
argument preserves their own first rows and does not conflate them.

Those closed-source invocation schedules are **not reachable for the required
original invocations in a W-conforming positive J history**: O remains open
through J selection; fixed J remains open through both e/S selections; and if
the helper is chosen, K1 requires its original admission/delivery/consumption
before e's mode action and terminal. W's ordered mandatory facts transfer that
precedence to X. A purported X terminal before its chosen helper admission
cannot match a K1 path without inserting nonmatching mandatory protocol facts.
This uses W, not just Progress_N. It applies to fail/absent/pending as well as
answer. Consequently the original invocation authorizations in E_N are allowed,
while their possible service delays are unrestricted. We do not populate equal
coarse states with impossible refused dispositions to simulate an absent race.
The general closed-source rule is stated to delimit the lemma, not to add an
unauthorized cancellation history to E_N.

**Later admission and publication.** Equal old rows feed the same current source,
scope and schema checks; depth/charge transfer remains the coarse relation's
obligation. Reply admission retains the original intent and authorization
(`invocation_outcome.go:172–184`), and later publication/delivery do not reset it.
Successful publication's descendant obligations remain tied to the captured
prefix. Failed publication can preserve an admitted original reply. Neither
case creates a missing commitment or treats outcome delivery as selection.

## 6. Progress remains independent

Assume Progress_N and the unchanged eventual eligible local/protocol service
premise. First authorization is once-only for each original intent. In this
fixed full construction there are at most four invocation intents (J,e,S,h)
and four replies, hence at most eight newly deciding authorization transitions;
this is an interface count, not a runtime step/byte cap. The integer
`8 - number of retained first decisions` strictly decreases on each new
authorization. Existing local nondivergence is still supplied by Progress_N;
this small rank only excludes infinite newly deciding authorization stutters.

A continuously pending first authorization remains eligible until serviced.
Afterward its original admission stage has the same eligibility as in the
coarse protocol. Eventual eligible service therefore turns the split into a
finite delay, preserving the original service premise. Infinite repeated
lookups without required admission/service are unfair withholding under E_N,
not a new proof that a private divergent cycle terminates. No universal private
rank or 512-step bound is imported.

Together with the separately justified coarse constructor progress transfer,
S eventually reaches its original selected result and the caller gates open.
Answer/fail/absent then retain their prescribed envelopes and finite J/O suffix.
Pending reaches the actual unmatched e receive after input and any chosen
helper consumption; S is selected, J awaits original e, and O awaits original J.
There is no e/J reply or terminal created to make that pending path finish.
The authorization extension neither proves the original progress premise nor
replaces the independent pending-boundary argument.

## 7. Remaining obligations and finite experiment

No authorization-specific unresolved predicate remains **within the stated
conditional A_op/E_N lemma**. The unresolved overall obligations are the other
bridges' coarse path/guard/demand and caller transfer, plus independent review
of this history-extension argument. Full raw execution correspondence and
whole-D closure/refusal normalization are not claimed by this report.

No finite experiment is required to decide the structural authorization lemma:
the induction covers arbitrary finite private implementation states and every
legal first-authorization ordering, while a bounded run could not prove that
universal quantifier. The inspected historical finite structs retain small
disposition codes, not complete raw source-prefix histories; their passing
results would not substitute for this proof.

If the controller later wants a minimal nontrivial finite validation of a new
history certificate, use one original J bound reply, the three causal orders
`c;a;d;t`, `c;a;t;d`, `c;t;a;d`, and both End statuses (six schedules), recording
the actual first source-open snapshot and checking a post-End repeated lookup
returns the old row. Include the unresolved `c;t` prefix. That tests the precise
canonical-sidecar error without a candidate search. A negative kernel-only
check can separately contrast late invocation authorization with bound reply;
it must not be called a positive-profile candidate counterexample. No such
probe was run here, and the proposal is not an acceptance verdict.

## 8. Inspected identities and checks actually performed

Worktree: `/Users/jacob/.codex/worktrees/phase1j-retained-joins/alan`.
HEAD read as `bec75fa3db8cdafb6295f3d0e8ebb619400c1f36`; initial `git status
--short` was empty. Read exact Task 2 brief, constraints and bridge instructions;
then the approved definition and its r1/r2 reviews. The startup skill explicitly
exempts dispatched subagents. Used read-only source extraction/search for the
named guards and SHA-256 verification. One initially guessed scratch review
filename was absent; the actual archived reviews below were then read.
No tests, execution/search campaign, code/paper edit, render, commit, push or
subagent occurred. The only authored file is this report.

| Inspected source | SHA-256 |
| --- | --- |
| `docs/foundational/phase1o/01-weak-contract.md` | `ac1c0ecbf62bd82c718a7a3ad3dcf000552d14e093868321b0f7dcc4b370b000` |
| `docs/foundational/phase1o/evidence/reviews/task1-r1.md` | `243f70ef25df4f732c6d4d9f0fb53cddc510c54f9d9c8771e3d61d433a467b0c` |
| `docs/foundational/phase1o/evidence/reviews/task1-r2.md` | `2e0e6b0c77b6c21c44baf581093e200fe34dda21483dbdcdae6ea0733da5656f` |
| K: `docs/foundational/phase1i/01-substitution-contract.md` | `cadd87220e6b9a06ccb597dc808b31ddae072d486d13feb703e0fb480294d865` |
| N: `docs/foundational/phase1n/01-contract.md` | `001c1fe5cd7be722aa75ae00a2be84ec702b51783a5595754d38ec8e6b2d8fd9` |
| `docs/foundational/phase1n/02-lifting.md` | `53bf70cb2aad625b4d5a3a753610ba271c84e738f557904860988350cbe40e54` |
| `docs/foundational/phase1n/evidence/reviews/reference-r1.md` | `c6f5adf78ffa283a88a31ab417700a9b72f25ea07a6cb5ee54238ae716ad3246` |
| `research/substitution/model.go` | `1faef47e9ef17401512aba14239fc07ad7031a6db249600844752b35db342ddf` |
| `research/substitution/invocation_join.go` | `dac14d762e71d4db2ae6d920705bcec7d080929275a6425918cf94783cd37dc0` |
| `research/substitution/callable_join.go` | `98712edefc1e9dd44f146089c4e3e8d1da2fcac1df5a57421d73ce31c6a07a08` |
| `research/substitution/callable_join_local.go` | `d918c235822262b0c630d6ce69721036d2b614a5e4020585c3e9b86ed68275fb` |
| `internal/executor/messages.go` | `1186fd9220d44352dcfd77ec5e7209dadd78d9956304a931593b5de6c6b8ae39` |
| `internal/executor/invocation.go` | `b40c1edc17249a31ccff84408a7855098e3a51ad28579ea856efc34bf4fa6746` |
| `internal/executor/invocation_outcome.go` | `adeaba4f04843867c5405a6bfb5a8716e64654a3e96bc58ad190ec23cbfcb53d` |
| `internal/executor/store.go` | `4100327b3d95b44c061dad51f656fd193f26bc28c58093ecd2b385f9f76895bb` |
| `internal/executor/program.go` | `4a6813c69d509dff545c75a05410919e182e73c9f06e5fd359112e64df568374` |
| `internal/executor/composition_source.go` | `70140b8f46a9c63fca177a7320d94dd4e0afef9c2f91057e81a29c65655c5c9f` |
| `internal/executor/composition_replay.go` | `21b7c4cfd97654b5eb1a139be1d74f9ceadec5b1bcd44b4c3462beead0d10642` |

Self-review: checked the quantifier starts from each existing related pair,
normalized equality does not erase per-run raw provenance, late first reply
authorization survives failed End, invocations receive no exception, impossible
closed-source dispositions are not added to E_N, and finite authorization delay
does not discharge private progress. Main review focus: whether the other
bridges supply the coarse constructor correspondence this lemma explicitly
requires. No contemporaneous bridge finding was used to assert that premise.
