## Task 2 — Attempt the three bridge arguments first
- [ ] Write a direct derivation or explicit failed obligation for each bridge.
- [ ] Challenge the derivations independently, including interleavings, ownership and progress.
- [ ] Identify the smallest finite experiment needed for any unresolved step.
- [ ] If the arguments close, validate their nontrivial finite instances and proceed to final qualification without inventing a larger campaign.
Bridge A: weak-path normalization
Determine whether matching paths can be selected so that J's relevant guards remain valid at intermediate states. Preserve ordered observable facts and the original atomic groups; do not match an unordered set of endpoints or split an atomic transition to manufacture an interleaving.

Make clear which obligations concern related endpoints and which concern intermediate states. Address additional protocol events, monotone commitment/consumption/terminal facts, optional-helper future demand, and the compatibility of path choices across future moves.

The delayed e-selection gate matters: J permits caller selection only after S has been consumed. Explain why an allowed matching path can survive that restriction without relying on an earlier selection or changing the environment's service obligations.
Bridge B: caller ownership and readiness
Derive, or identify the absence of, the framing rule that keeps original commitment and selection under their declared owner. Establish that candidate-private state cannot impose an additional guard on those caller actions.

Preserve bilateral environment readiness at private instruction boundaries. A candidate must not postpone a required environment action by inventing a private computation step.

If the fixed public API enforces a condition that the abstract K1 wording does not determine, report the two scopes separately. Do not claim a theorem for arbitrary graphs from an operational restriction established only for authored programs.
Bridge C: retained authorization extension
Construct the relation over legally reachable authorization histories, preserving each original intent's commitment, source identity/revision/generation, binding and immutable first decision.

The same coarse local state may have several legitimate retained-history extensions. Allow the required history-distinguished augmented states; do not require an unjustified single canonical sidecar assignment.

Cover every legal history admitted by the fixed environment. Do not select only a favorable authorization order, and do not introduce a Cartesian product of impossible dispositions. In particular, retain both authorization before J End and first bound-reply authorization after End. Invocation authorization has no reply exception.

Show which matching facts preserve each guard and how the extension remains closed under later service. Equal final totals or recomputation after End cannot replace original first decisions.
Progress is a separate obligation
Preserve all-mode progress/nondivergence and the actual intended pending boundary. A safety relation alone cannot discharge these conditions.

Use an appropriate rank, SCC/fairness argument or explicit equivalent certificate. Distinguish a private divergent cycle, unfairly withheld service and the designated unmatched pending receive. Do not infer progress from successful completed traces.

Keep semantic allowances fixed. Adequate finite operational bounds remain a premise: the old rank or 512-step execution setting is not a uniform bound on arbitrary private implementations. For a new concrete witness, derive an adequate common operational cap before qualification and record it separately from the fixed I/R/depth entitlement.
