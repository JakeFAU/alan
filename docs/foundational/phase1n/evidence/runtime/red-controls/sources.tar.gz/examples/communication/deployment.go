// Package communication builds the single Phase 1K ordinary report/ACK experiment.
// Its messages carry participant assertions; commitment supplies no delivery receipt.
package communication

import (
	"github.com/JakeFAU/alan/author"
	join "github.com/JakeFAU/alan/examples/join"
	"github.com/JakeFAU/alan/examples/substitution"
	"github.com/JakeFAU/alan/examples/substitution/protocol"
	"github.com/JakeFAU/alan/runtime"
	"github.com/JakeFAU/alan/schema"
)

// Options name separate adverse artifacts. Empty options preserve original S.
type Options struct {
	SMode              string // empty/answer, fail, absent, pending: original J1 builder controls
	WrongReportRequest bool
	WrongACKRequest    bool
	WrongACKHandle     bool
}

// New attempts the frozen J2 context using existing author operations.
// The current compiler rejects the exact ACK string/retained-handle comparison;
// on that error the returned deployment has no Provision and must not be run.
func New(candidate author.Template, config substitution.Config, options Options) (substitution.Deployment, error) {
	// This public builder is the source of the exact frozen candidate/S/control bytes.
	d, err := join.New(candidate, config, join.Options{SMode: options.SMode})
	if err != nil {
		return d, err
	}
	// Never return the original J1 provision as though it were a J2 deployment.
	d.Provision = runtime.Provision{}
	root, err := rootCaller(candidate, options)
	if err != nil {
		return d, err
	}
	peer, err := peerCaller(d.Peer, options)
	if err != nil {
		return d, err
	}
	d.Provision, err = (author.Application{
		"root": {Artifact: root, Inputs: map[string]schema.Value{
			"request_id": schema.Int(config.Request.ID), "request_value": schema.Int(config.Request.Value),
			"request_mode": schema.Text(config.Request.Mode),
		}},
		"peer": {Artifact: peer, Inputs: map[string]schema.Value{
			"request_id": schema.Int(config.Request.ID), "request_value": schema.Int(config.Request.Value),
		}},
	}).Provision()
	if err != nil {
		return d, err
	}
	allowed := []string{}
	for _, template := range d.Provision.Composition.Templates {
		allowed = append(allowed, template.ID)
	}
	d.Provision.Composition.Roots = []runtime.ResourceRoot{{
		Run:       runtime.RunID{Subject: "root", Generation: 1},
		Members:   []runtime.RunID{{Subject: "root", Generation: 1}, {Subject: "peer", Generation: 1}},
		Templates: allowed, Limits: config.Limits,
	}}
	return d, nil
}

func reportSchema() schema.Record {
	return schema.Record{
		"request_id": {Kind: "int"}, "s_operation": {Kind: "string", MaxBytes: 256},
		"status": {Kind: "string", MaxBytes: 20, Enum: []string{"succeeded", "failed", "cancelled", "abandoned", "rejected"}},
		"reason": {Kind: "string", MaxBytes: 4096}, "response_present": {Kind: "bool"},
		"response_id": {Kind: "int"}, "response_value": {Kind: "int"},
	}
}
func ackSchema() schema.Record {
	return schema.Record{"request_id": {Kind: "int"}, "s_operation": {Kind: "string", MaxBytes: 256}}
}
func reportReceive() author.Step {
	return author.Receive("report", map[string]string{
		"request_id": "join_request_id", "s_operation": "join_s_operation", "status": "join_status",
		"reason": "join_reason", "response_present": "join_present", "response_id": "join_id", "response_value": "join_value",
	})
}
func ackReceive() author.Step {
	return author.Receive("ack", map[string]string{"request_id": "ack_request_id", "s_operation": "ack_s_operation"})
}
func requireEqual(a, b author.Expr, next []author.Step) author.Step {
	return author.IfEqual(a, b, next, []author.Step{author.Failure()})
}
func rootCaller(candidate author.Template, options Options) (author.Artifact, error) {
	checks := []author.Step{author.Success()}
	for _, check := range []struct{ a, b author.Expr }{
		{author.Var("join_value"), author.Integer(0)},
		{author.Var("join_id"), author.Var("request_id")},
		{author.Var("join_present"), author.Boolean(true)},
		{author.Var("join_status"), author.String("succeeded")},
		{author.Var("answer_value"), author.Var("expected_value")},
		{author.Var("answer_id"), author.Var("request_id")},
		{author.Var("child_present"), author.Boolean(true)},
		{author.Var("child_status"), author.String("succeeded")},
	} {
		checks = []author.Step{requireEqual(check.a, check.b, checks)}
	}
	steps := []author.Step{
		author.Invoke("pending", "candidate", map[string]author.Expr{
			"id": author.Var("request_id"), "value": author.Var("request_value"), "mode": author.Var("request_mode"),
		}, nil),
		author.AwaitInvocation("candidate", "pending", author.InvocationOutcomeBindings{
			Status: "child_status", Reason: "child_reason", ResponsePresent: "child_present",
			Response: map[string]string{"id": "answer_id", "value": "answer_value"},
		}),
		reportReceive(),
		// This one-report profile supplies no second report after wrong correlation.
		author.IfEqual(
			author.Var("join_request_id"), author.Var("request_id"),
			nil, []author.Step{reportReceive(), author.Failure()},
		),
	}
	request, handle := author.Var("join_request_id"), author.Var("join_s_operation")
	if options.WrongACKRequest {
		steps = append(steps, author.IfEqual(author.Var("request_id"), author.Integer(1),
			[]author.Step{author.Set("sent_ack_request_id", author.Integer(2))},
			[]author.Step{author.Set("sent_ack_request_id", author.Integer(1))}))
		request = author.Var("sent_ack_request_id")
	}
	if options.WrongACKHandle {
		handle = author.String("phase1k-wrong-s-operation")
	}
	// ACK asserts consumption of this report, including known negative S outcomes.
	steps = append(steps,
		author.Send("ack", map[string]author.Expr{"request_id": request, "s_operation": handle}),
		author.IfEqual(author.Var("request_value"), author.Integer(0),
			[]author.Step{author.Set("expected_value", author.Integer(1))},
			[]author.Step{author.Set("expected_value", author.Integer(0))}),
		checks[0],
	)
	r := protocol.Request()
	return author.Compile(author.Definition{
		Name:        "phase1k-ack-root",
		Inputs:      schema.Record{"request_id": r["id"], "request_value": r["value"], "request_mode": r["mode"]},
		Invocations: map[string]author.Template{"candidate": candidate},
		Ports: map[string]author.Port{
			"report": {Peer: "peer", Obligation: "phase1k_s_report", Receive: reportSchema()},
			"ack":    {Peer: "peer", Obligation: "phase1k_s_ack", Send: ackSchema()},
		}, Steps: steps,
	})
}
func report(present bool) author.Step {
	id, value := author.Integer(0), author.Integer(0)
	if present {
		id, value = author.Var("peer_id"), author.Var("peer_value")
	}
	return author.Send("report", map[string]author.Expr{
		"request_id": author.Var("report_request_id"), "s_operation": author.Var("peer_pending"),
		"status": author.Var("peer_status"), "reason": author.Var("peer_reason"),
		"response_present": author.Var("peer_present"), "response_id": id, "response_value": value,
	})
}
func peerCaller(peer author.Template, options Options) (author.Artifact, error) {
	steps := []author.Step{}
	for i := 0; i < 32; i++ {
		steps = append(steps, author.Set("schedule_marker", author.Integer(int64(i))))
	}
	steps = append(steps,
		author.Invoke("peer_pending", "peer", map[string]author.Expr{
			"id": author.Var("request_id"), "value": author.Var("request_value"),
		}, nil),
		author.AwaitInvocation("peer", "peer_pending", author.InvocationOutcomeBindings{
			Status: "peer_status", Reason: "peer_reason", ResponsePresent: "peer_present",
			Response: map[string]string{"id": "peer_id", "value": "peer_value"},
		}),
		author.Set("report_request_id", author.Var("request_id")),
	)
	if options.WrongReportRequest {
		steps = append(steps, author.IfEqual(author.Var("request_id"), author.Integer(1),
			[]author.Step{author.Set("report_request_id", author.Integer(2))},
			[]author.Step{author.Set("report_request_id", author.Integer(1))}))
	}
	park := []author.Step{ackReceive(), author.Failure()}
	steps = append(steps,
		author.IfEqual(
			author.Var("peer_present"), author.Boolean(true),
			[]author.Step{report(true)}, []author.Step{report(false)},
		),
		ackReceive(),
		author.IfEqual(author.Var("ack_request_id"), author.Var("request_id"),
			[]author.Step{author.IfEqual(
				author.Var("ack_s_operation"), author.Var("peer_pending"),
				[]author.Step{author.Success()}, park,
			)},
			park),
	)
	return author.Compile(author.Definition{
		Name:        "phase1k-ack-static-peer",
		Inputs:      schema.Record{"request_id": {Kind: "int"}, "request_value": {Kind: "int"}},
		Invocations: map[string]author.Template{"peer": peer},
		Ports: map[string]author.Port{
			"report": {Peer: "root", Obligation: "phase1k_s_report", Send: reportSchema()},
			"ack":    {Peer: "root", Obligation: "phase1k_s_ack", Receive: ackSchema()},
		}, Steps: steps,
	})
}
