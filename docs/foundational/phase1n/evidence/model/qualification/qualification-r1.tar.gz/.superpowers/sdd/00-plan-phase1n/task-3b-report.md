# Phase1N Task3b implementation report

Status: implementation and author qualification complete; ready for independent
Task3b review. No commit, push, rendering, paid call, broad root suite, historical
edit, reference-oracle change or public-construction edit was performed.

The question was whether the frozen J[K1] reference satisfies the independently
frozen K_join/G_outer predicates, whether shifted A/B local relation and separate
all-mode progress supply the restricted lifting premises, and whether the actual
public artifacts realize the frozen transitions within declared finite bounds.
The bounded qualifications below pass. They do not turn enumeration into a
generic theorem or close the unrestricted weak-refinement implication.

## Boundary and source identities

Task3a was approved/committed as
`c3c5b81938d177d73bca28532c3f8886ad02211b`; construction was separately approved
at `907e22694149cf2ba52069c7c2e7038fdacc63fa`. The release of the reference author's
output firewall is retained in
`docs/foundational/phase1n/evidence/model/qualification/firewall-release.json`
(SHA256 `9250012b3ecb69564f840f048fdc54bb14aec91a10b96211aed5180a4f63c8af`).
Only after release were approved construction source/artifacts/representation/
review and the runtime author's static inventory used for correspondence. The
inventory was a map, not an oracle. Shared historical K1/M semantics and the
Phase1I exact component mapping remain disclosed independence limitations.

All 66 reference-r1 input/source hashes are unchanged, including the six frozen
Go files, contract, lifting document and historical inputs. No re-freeze or
reference re-review is required by a discovered reference defect; none was found.
The original reference manifest SHA256 remains
`4603206f1eccf3bb471ca1df821aa56c613633d98dfdd9d84016786db137023e`.

New implementation identities:

| Path | SHA256 |
| --- | --- |
| `research/substitution/callable_join_qualification_test.go` | `646ceba875c36ee4238bf641c6c2729b18ea6105ee3619b8ee609e84dc0c273b` |
| `research/substitution/callable_join_artifact_test.go` | `022d600520ce0adfd835f8e911e12f224fe89bf1ed74333873ae5c87a05d7040` |
| `qualification/check_correspondence.py` | `1fec84e9a96ce7c8691c8705d5ea9a86aa702b9c9e664fa09e50bb06a4c802ac` |
| `qualification/capture.py` | `cafb58d697703484dadc557da2e966d62ded48d430bfd735b154e114cdc21545` |
| `qualification/audit.py` | `8105d8402188e2cdb726c5a445d0430f8ef7f9788c2e5268902b6dd3e00c9382` |
| `qualification/README.md` | `e2c98af92144082fce4fc0226d704bd2fd42bd0a504271d380d7c683aab55d17` |

Here `qualification/` abbreviates
`docs/foundational/phase1n/evidence/model/qualification/`.
All command source archives, full result identities and final files are indexed
in that directory's `index.json`. Current audit is
`audit-r2/audit.json.gz`, SHA256
`6a61c530d59abe27582f76f0a9b51e840894a75be2820aa1f1388730cb8392f5`.
Current normal/race correspondence records are respectively
`normal-correspondence-r2/correspondence.json.gz` SHA256
`0bc86332b9df7705e84e189accdf7bb62e36ad54ebec246af29c9f2118e0dbc6`
and `race-correspondence-r2/correspondence.json.gz` SHA256
`23f0088e5742c3dfdf0b446753377945aa183010fe1197c7ae38535ca7fbfd92`.

## Executed qualification

In each normal/race profile, exact anchored tests ran in the required order:
ReferenceQualification (16 leaves), AlignedLocalQualification (32),
ReplacementQualification (32), FiniteLiftingQualification (32), followed by
ArtifactCorrespondenceInputs (2), each prefixed `TestCallableJoin`.
Actual selectors, discovery, all leaves/exits/stdout/stderr and pinned environment
are in command records. All 114 leaves per profile passed (228 total), zero
skipped; focused `go vet ./research/substitution` exited 0. Go1.27.3 darwin/arm64,
CGO 1, GOTOOLCHAIN local, GOPROXY/GOSUMDB off, readonly modules and isolated
`/private/tmp/alan-phase1n-model-go-build` cache were used. ALAN_* and
OPENAI_API_KEY were stripped except the capture's ALAN_MODEL_EVIDENCE output path.

The initial census archives precede gofmt and the additive artifact extraction
test. The audit proves archived qualifier bytes become exactly the final bytes
under gofmt. It does not attribute old executions to newer source archives.
Every capture has its own exact source archive; no recorded source changed
during a command. Full model/local/lifting/artifact normal/race exports are
byte-identical. The separately recorded Python evaluator and audit are not Go
test leaves or extra model configurations.

| Product, 16 configurations each | States/model states | Edges | Terminal/pending maxima | Rank extrema / cap |
| --- | ---: | ---: | ---: | --- |
| J[K1] with O | 6,376 | 13,232 | 24/8 | 100..9,300 /12,221 |
| J[A] with O | 2,864 | 5,622 | 12/4 | 100..7,206 /12,221 |
| J[B] with O | 6,644 | 13,844 | 12/4 | 100..9,313 /12,221 |

This is exactly 48 configurations, with K1's independent local/helper choice in
every mode. Every refusal/stuck/cutoff/cycle/state/rank/prefix/component/projection/
K_join/G_outer failure count is zero. All 64 maxima and their traces are retained.
K_join and G_outer are projections of these same products, not independent
censuses. Equal monitor/model state totals are observed, not assumed.
Full charges are A(3,3,0), B(4,4,0), K1 independently either; prior J debit remains
separate from the sole S q debit. Physical depths 2/3 and guard/refusal projection
are checked on every edge. Pending maxima meet the full original-request/helper/
S-consumption and unmatched-receive/J-await/O-await predicates with no invented
report, release, End, or publication.

Aligned local relation has A 884/B 2,320 pairs; component checks 468/1,328,
environment checks 1,688/4,168, stutters 180/496, no failures. Separate open progress
has A 376 states/544 edges and B 824 states/1,244 edges; each has 12 terminal/4 pending
maxima with no refusal/stuck/cycle/rank/cutoff. Ranks 1400..4906 and 1400..6813
under 8321. The legacy summary's Entitled 4 is answer-only; the new all-mode
maximum predicate checks all 16 configurations without changing that field.

Finite lifted relation has A 2,864/B 6,644 pairs, component checks 2,954/7,280,
environment checks 5,336/13,128 and stutters 644/1,512. Each has 16 initial pairs,
zero failures/counterexamples. These are finite eventwise instances, not a weak
path normalization theorem.

## Correspondence and bounds

The checker maps all 283 retained instructions: both J 58/O 64 plus original
A 13/B 16/helper 7/S 3. It checks exact instructions, operands, branches, setters,
Send/End and bounded collection/cursor operations, original frozen component
bytes, six exact A/B binding-difference paths, and all 16 input builds per binding.
Invocation-handle/intent commitment, selected Receive binding/consumption and
End/freeze atomic groups are explicit. Public request/reply runtime binding
remains a separate retained-history authentication obligation.

The J classification Set maps to classify then a ghost decision fixed by the
immutable tag. Remaining code and final PC55 branch are checked; no durable
intermediate decision checkpoint is claimed. O decision Set similarly fixes
PC61. The model permits abstract interleavings not taken by an atomic concrete
commit. J Send/End-before-first-authorization remains allowed under the exact
original bound-reply exception; no source-open restriction was added to hide it.

The original receive reducer establishes schema eligibility only. The separate
Python bytecode evaluator uses explicit frozen-contract policy tables. Per
binding, 140 inner envelopes yield 136 accepted; 1,703 outer yield 1,696 accepted. Four
successful-absent envelopes are schema-rejected; outer additionally rejects
unknown tag, two rows and missing answers. Absent fields are never filled with
zero. Domain is five statuses × four reasons × absent/present; child ids 0,1,2 and
values 0,1; report ids 0,1,2, four tags and empty or one of six rows. It is explicitly
finite and includes schema-valid adverse combinations, not only deployment
outputs. Candidate/S receive output schemas are checked equal.

Per binding, 73,984 J cases and 6,784 O cases agree with independent policy tables.
Complete witnesses for 22 distinct J paths and 54 O paths include cursor snapshots,
indices and exhaustion. J PC27/49 are schema-unreachable successful-absent
setters; adjacent shared jumps remain reachable. O PC14 requires a prohibited
second row and PC50 a prohibited tag. Other post-selection PCs are witnessed;
static correspondence covers all instructions, including unreachable ones.

Conservative runtime bounds are A 139/B 149 local commits and A 9/B 12 dispatches,
source-checked against actual public 512 steps/64 dispatches/capacity 1. These are
not model ranks. Largest retained program 25,387 bytes; bound-program allowance
max 416,142; projection/observation/one-intent-array allowance 55,616; finite schema
payload max 571; original handle allowance 76. They fit default 1 MiB caps under
the fixed finite stable identity/value/no-error/no-retry/no-closure profile.

## Preserved failures and limits

`normal-correspondence-1` exits 1: an initial checker expectation incorrectly
included shared jumps 28/50 among unreachable setters 27/49. Exact control edges
26→28 and 48→50 identify the error. Only the coverage expectation changed; the
passing corrected capture and the failed original argv/archive/stderr remain.
No policy table or frozen semantic source was changed.

The controller subsequently found that successful captures mislabeled prior
M's 200/200 limits as the N public settings. Current r2 source asserts actual
512/64 and checks the unchanged 139/149, 9/12 bounds fit. Earlier successful
records and audit-final are preserved but superseded for this metadata. A
read-only optional-metadata inspection raised KeyError Collections; it changed
no evidence or verdict and was corrected to optional access.

ARG-1 remains the reviewed closed **restricted conditional constructor argument**:
supplied eventwise or explicitly guard-stable R, bilateral environment readiness,
caller-owned delayed selection, equal authorization sidecars, resource/depth/
future-demand alignment and separate all-mode progress/nondivergence. Matching
O private control is added only for the outer-policy corollary.

ARG-2 remains **open**: arbitrary weak unchanged K1 refinement has no proved
normalization/extension bridge to those stronger premises, including intermediate
guards, caller-owned commitment/selection and split authorization. Finite A/B
witnesses do not establish that bridge. Runtime original binding/authentication,
all-history traces, actual post-End first authorization and operational execution
are Task4, not established by these static/model checks. No recovery or broad
context theorem is claimed. No manuscript files were edited in this authorized
slice; controller reconciliation must carry these limits into the final phase
account. Independent Task3b review is the next gate.
