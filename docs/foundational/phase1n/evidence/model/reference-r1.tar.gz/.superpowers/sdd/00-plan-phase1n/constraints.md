Global constraints
- Preserve original A/B/helper/S artifacts and the K1 contract. Keep prior contexts and historical evidence identifiable and unchanged.
- Preserve production compiler, executor, schema semantics, scheduler, accounting, and dependencies. Use existing public authoring/runtime behavior.
- Correct ordinary example, model, adapter, and test mistakes within this scope. If a genuine production/interface obstruction remains, preserve its smallest witness, complete unaffected work, and report the blocked obligation; do not redefine semantics to force a positive result.
- Preserve PR19 formatting, PR20 mathematics, and existing theorem qualifications.
- No outer sibling, extra forwarding wrapper, static peer, ordinary report/ACK protocol, inner-handle serialization, pending-release request, retry/fallback, new effect, or generic context generator.
- Current authorization is for a reviewed draft PR only.

Repository AGENTS.md applies. No new PDF compilation until controller runs it once after final source review. No paid providers. No new dependencies. User has already authorized execution through reviewed draft PR.
