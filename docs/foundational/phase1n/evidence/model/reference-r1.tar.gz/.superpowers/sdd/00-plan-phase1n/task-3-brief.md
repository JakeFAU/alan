## Task 3 — Establish the restricted lifting argument
- [ ] Derive and independently review J[K1] and the K_join monitor before replacement acceptance.
- [ ] Establish the resource/depth/environment alignment and requalify all-mode local A/B progress where the old result does not transfer directly.
- [ ] Write the explicit constructor relation and transition-case argument; mechanically check its finite instantiations.
- [ ] Explore the declared reference product first, then the A/B replacements, and report precisely which proof obligations were established.
Keep the logical obligations separate:
X refines K1 under the aligned candidate environment.
J[K1] satisfies K_join.
The fixed constructor lifts that relation:
    J[X] refines J[K1] under the declared join environment.
The fixed outer policy uses K_join to preserve G_outer.
State K_join and the constructor rule without referring to O's private PCs or registers. O is the verified realization of the required public caller behavior, not part of the definition of K_join.

The target rule ranges only over candidates in the declared semantics satisfying the required event refinement, bilateral environment readiness, resource conditions, and separate progress/nondivergence obligations. Local safety simulation alone is insufficient. Do not silently strengthen K1 or treat schema compatibility as this premise.

Give an explicit lifted relation covering:
- related candidate/reference states and the same original S state;
- matching J control and the declared public caller-environment and ownership obligations; matching O control is added only for the outer-policy corollary;
- original handles, retained outcomes, selected consumptions and correlation under consistent identity renaming;
- the prior J ledger offset, residual budget, depth shift, and the single S environment debit;
- matching diagnostics, reply obligations, terminal decisions and publications.
Check the cases for candidate steps, S/environment steps, J's public entry and inner joins, classification, reply commitment/authorization/admission, J termination/publication, and O consumption/termination. Identify pure stutters explicitly. Preserve refusal/accounting distinctions; do not erase them to obtain a relation.

In particular, the invocation-bound reply exception must cover the exact reply source, generation/revision, caller identity, route/schema, and binding assumptions. J can terminate after its Send and before first authorization; the rule must justify that schedule rather than exclude it. O's ownership supplies the required open destination under this profile.

Use an explicit finite transition argument and an independently checked invariant/relation. A new proof assistant or generic framework is not required. Distinguish a general constructor argument within these declared semantics from its A/B finite instances and from concrete artifact/runtime correspondence.

If only the finite instances can be established, report bounded nested preservation and the precise missing lifting step. Do not call enumeration itself a constructor theorem. If the argument fails substantively, preserve the smallest exact gap or counterexample instead of extending the context family.
Domain, maxima, and progress
Use id{1,2} × value{0,1} × mode{answer,fail,absent,pending}, with unchanged answer S: 16 configurations per K1/A/B product, 48 total. Retain K1's independent local/helper choice in every mode. Do not prescribe state, edge, maximum, or test-leaf counts.

A single full product may support both inner-contract and outer-policy predicates through justified projections; do not duplicate its counts as independent evidence. Any standalone abstract K_join checking must retain its declared resource/progress obligations.

For pending, establish all of the following under eventual service:
- The candidate consumed its original request, completed/consumed any chosen helper, and reached the designated unmatched receive.
- Original S completed and was actually consumed by J.
- J waits at the original e await, without a completed diagnosis, reply, End, or invocation publication.
- O waits at the original J await, without a completed decision, End, or root publication.
Do not send the forbidden release input or manufacture a Pending reply. Check genuine maximality and progress/rank/cycle obligations separately from acceptance of finite prefixes. Include monitor memory in state equivalence where needed, inspect every transition before deduplication, and report cutoffs rather than treating them as completed searches. Model rank is not a runtime instruction budget.
