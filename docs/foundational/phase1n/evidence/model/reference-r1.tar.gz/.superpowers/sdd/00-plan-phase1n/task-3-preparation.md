# Phase 1N Task 3 independent reference preparation

Status: source-only design/handoff, 2026-10-30. No new reference has been
implemented or reviewed, no census or qualification has run, and no constructor
theorem is established by this report. This is the distinct reference author's
preparation while the public construction is authored separately.

## Question and allowed inputs

Does the fixed owning constructor lift a candidate's K1 event refinement and
separate progress obligations through one new public invocation/reply boundary,
under the declared residual resources and caller lifetime? The smallest new
semantic boundary is J's diagnostic Send/authorization/admission/publication and
the caller's original selected J consumption. J's inner classification still
depends on both original child consumptions.

The approved `docs/foundational/phase1n/01-contract.md` was read and its SHA-256
verified as `001c1fe5cd7be722aa75ae00a2be84ec702b51783a5595754d38ec8e6b2d8fd9`.
The task-3 brief, adjacent constraints and repository AGENTS.md were read.
No `examples/callablejoin` source, new preflight evidence, construction-worker
report, new runtime output, replacement result or other new implementation file
was inspected. No model conclusion is inferred from a new execution. This report
is the only repository edit in this preparation stage.

Permitted shared historical sources inspected, in full or in the targeted
sections named below:

- `docs/foundational/phase1i/01-substitution-contract.md`: K1 transitions,
  local environment, refinement/readiness and separate progress conditions.
- `docs/foundational/phase1m/01-reason-contract.md`, `02-qualification.md`,
  `03-review.md`, `05-decisions.md`: reviewed M scope, preserved counterexamples,
  local qualification, independence and counting limitations.
- `research/substitution/model.go`, `candidates.go`, `relation.go`,
  `explorer.go`, `oracle.go`, `runtime_boundary.go`: finite component machinery,
  public-state relation, local environmental debit, rank and root-terminal hazard.
- `research/substitution/invocation_join.go`, `invocation_join_oracle.go`,
  `consumer_policy.go`, `consumer_reason.go`, `consumer_reason_oracle.go`,
  `consumer_reason_explorer.go`, `consumer_reason_local.go`,
  `consumer_reason_test.go`: historical owning join, split authorization,
  independent classification monitor, model/monitor product and adverse fixtures.
- `examples/substitution/protocol/protocol.go`, `a/candidate.go`, `b/b.go`,
  `deployment.go`: original schemas, A/B/helper and original S definitions.
- `internal/executor/invocation.go` (binding and invocation admission),
  `messages.go` (first authorization and reply dispatch),
  `invocation_outcome.go` (reply recording, freeze capture, publication/delivery).
- Historical `paper/alan-dissertation.md` sections 4.5.1–4.5.2 and Phase I–M
  discussion; corresponding targeted LaTeX passages. Definition 4.6's symmetric
  exact-debit relation and the open status of Theorem 4.8 remain unchanged.

All 28 historical files above were byte-compared with baseline
`3c5118ea9763a27cca432ca91aac667bd59e21e7`; all matched. The SHA-256 of sorted
`path + NUL + sha256(file) + newline` entries is
`4d3946a2498ab156ae3ad6542d230c0861176e1f2d2fb203c6da6e974c7a0cb4`.
Hashing/identity inspection is not behavioral verification. Historical qualification
numbers, where read, are attributed prior evidence; they are not new N results.
Shared historical protocol machinery and candidate transcriptions limit the
independence of the new reference. The new diagnostic oracle must be derived
from the approved contract rather than a model classifier or construction output.

## Four separate obligations

1. `X <= K1` in the aligned local environment, including bilateral environment
   readiness, exact labeled facts/refusals/accounting and separate all-mode
   nondivergence/progress.
2. `J[K1] |= K_join` under the declared public caller environment. K1 keeps both
   local/helper alternatives independently in every mode.
3. The explicit constructor relation lifts the first obligation to
   `J[X] <= J[K1]`, with the second supplying the reference premise.
4. Fixed O's guarded public policy preserves `G_outer` for a K_join component.

K_join contains no O PC/register predicate. Its public environment supplies a
fresh valid invocation with the original request and binding, residual resources,
stable identities/authority, an open eligible caller through original outcome
consumption, and eventual eligible local/protocol service. J owns original e/S
until both are consumed. Matching O control is added only in obligation 4.
K_join requires truthful selected-child classification, original once-only joins,
report and publication discipline, and mode-specific progress. G_outer requires
O's actual committed public decision and root publication. Public authentication
does not prove truth about J's private selected outcomes.

## Resource and depth alignment

Use full limits `(I,R,E)=(4,4,0)`, depth cap 3, fixed O at depth 0. Accepted J at
depth 1 contributes prior spending `p=(1,1,0)`. At the post-J-admission boundary,
project to local config `Shape=local, Local=true, EntryDepth=2, Depth=3,
I=3, R=3, Peer=true`. Closure is enabled only for the separately reused local
relation's stronger adversary check; open progress uses `Closure=false`.

For each projected prefix, local spent is full spent minus p. e is depth 2,
helper depth 3; original S is depth 2. Map S's unique accepted admission to q's
unique `(1,1,0)` debit. Before that admission q remains possible, including after
S commitment or authorization. Other S actions project to stutters. J admission
is not a second timed q event. Both schedules S-admitted-before-e and
e-admitted-before-S must remain enabled when their own prerequisites hold.
No root-budget refund occurs. Commitment costs zero, acceptance costs once and
refusal costs zero with its original reason retained.

The full demand invariant is `spent + possible/committed demand <= (4,4,0)`;
after J admission it is the local `(3,3,0)` invariant. K1's optional helper stays
in demand until local choice excludes it. In the positive profile the remaining
worst-case e/h/S demand fits, so limits/depth alone cannot cause refusal. This
does not justify dropping refusal cases from guards or negative evidence. A
matched K1 path has the same actual charge as its candidate; A and B need not
have the same charge as one another.

The M local qualifier cannot be relabeled: its config and maximum checker
explicitly require entry depth 1/cap 2. Add new N wrappers calling unchanged
`CheckLocalRelation`, `CandidateGraph` and `ExploreGraph` with entry depth 2/cap 3.
Restate all-mode maximum conditions and demand checks in N rather than modifying
old qualification predicates. M's answer-only `Entitled` cannot gate N's
fail/absent/pending progress checks. S's payload/lifetime/consumption facts remain
separate from this q projection.

## Proposed explicit lifted relation

Let E be the declared public caller environment, and R a local candidate/K1
relation satisfying K1's event/readiness/progress requirements at the aligned
boundary. Write `L_R^E(s_X,s_K)` when all the following hold, under one consistent
renaming of original root, subject, invocation, intent, observation and handle
identities (application id/value are preserved, not renamed):

- Candidate/helper projections are in R; original S state is identical,
  including its request, protocol stages, selected outcome and consumed flag.
- J has identical semantic control phase, original received request and retained
  e/S handles. Original caller identity, generation, revision, binding and
  ownership/open-lifetime obligations agree. This does not require O internals.
- Every committed/admitted/rejected operation, original reply obligation,
  retained publication/delivery and selected consumption corresponds. Published
  and consumed envelopes agree, including status, reason and explicit presence.
  A delivered outcome is not equated with a selected one.
- Ledgers agree after the same prior J charge; limits, depths, live demand and
  q/S admission mapping agree. Refusal reason and zero-debit evidence agree.
- First invocation/reply authorization dispositions and all relevant immutable
  source/caller/binding identities agree. These sidecar facts are preserved even
  though the older coarse local relation does not store authorization separately.
- J's classification, diagnostic semantic value, diagnostic commitment,
  authorization/admission, local End and invocation envelope agree at their
  separate stages. The caller's original J outcome remains paired.

Before J admission, the two systems have the same fixed public entry prefix and
no candidate state yet. Admission extends the relation by R's aligned initial
pair; no claim that local entry starts before the prior debit is needed. After
candidate completion, R retains the original selected outcome; fixed J stages
extend it without erasing charges or publications.

For the outer corollary strengthen L with identical O semantic control, retained
original J handle, actual public selected envelope, committed decision and End,
and root/aggregate publication. The public-policy proof may inspect only original
input and J's public envelope, not e/S rows or private classifier state.

## Transition-case argument to implement and review

| Case | Required transfer and invariant preservation |
| --- | --- |
| Fixed public entry | O/public caller commits J, first authorization, admission and J's first request consumption are distinct. The same stable source/binding/limits give the same admission result and charge. Accepted J initializes the aligned local pair; rejected J creates no inner run or debit and is outside positive K_join completion. |
| Candidate private step | R supplies a finite matching K1 path; a pure private step may stutter only if all protocol, payload, obligation, ledger and public control facts stay fixed. No unbounded private stuttering follows from safety simulation alone. |
| Candidate/helper protocol step | Transfer its exact commit/request/reply/freeze/publication/delivery facts through R with the same identity map. Original helper completion/consumption precedes mode action. Authorization sidecars must satisfy the separate extension described below. |
| S accepted admission | Both product states have identical S readiness and J ownership; q is possible and resource guards agree. Apply bilateral q readiness in R, charge once, and update identical S state. |
| Other S step | Same original S transition on both sides; local candidate projection stutters. S refusal, if a guard fails outside entitlement, keeps its exact reason and zero charge. |
| J commits e then S | Common J phase admits the same commit; no charge. S is not committed first. Candidate private progress cannot substitute for these owner instructions. |
| J consumes S then e | Common selected-handle gates require the same delivered original outcome. Both consume S before e and only once. Even invalid S cannot enable classification before e consumption. |
| Classification/report | Equality of both selected envelopes and original request gives the same guarded table result, independent of mode. Answer means exactly one correlated complement record; every other diagnostic means an empty list. Classification and Send commitment are different facts. |
| Reply authorization/admission | Preserve exact original J reply identity/binding/payload. The stable binding-qualified rule allows first authorization after J End. Schema-valid admitted response is retained once; no ordinary-message rule or invocation exception is substituted. |
| J End/publication | Send precedes End. Publication waits for its captured reply disposition. Admitted diagnostic is present even when J failed; missing reply converts only successful End. J failure remains member_failed. Descendants required for successful publication have already been joined. |
| Public delivery/selection | Retain the original J envelope and original handle without rewriting child reasons. Caller remains eligible and open until its selected consumption. Delivery and selection are distinct. |
| O corollary | Same guarded public envelope yields the same committed decision, End and root publication. Missing/inconsistent J evidence becomes invalid_join_outcome, never an invented candidate diagnosis. |

Two nontrivial bridge obligations must be made explicit rather than hidden in
the phrase "same context":

**Delayed e selection.** The local harness permits e outcome consumption as soon
as delivery is available; J delays it until S is consumed. Project the local
caller scratch state from e commitment/consumption, not from O's PC or J's
different await phase. J applies the same additional gate to both related
e-consumption events. This restriction is safe only because outcome selection is
caller-owned, its readiness depends on identical original delivered evidence,
and a terminal e cannot depend on the caller's later selection to perform more
component work. The proof must show no matching reference path needs a forbidden
early selection as an intermediate step. The existing exact single-event
`CheckLocalRelation` is a useful finite witness; arbitrary weak trace inclusion
without these phase/readiness facts is insufficient. For the generic rule either
derive this property from the stated K1 event-structured relation, or record it as
the precise additional local-interface premise and narrow the claim accordingly.

**Split authorization.** Lift R with equal retained first dispositions. Before
admission, both sides must agree on commitment, source open state, revision and
generation, original binding and resources. Authorization is a stutter only in
the coarse local projection; it is an explicit progressing event in the full
product. Final admission preserves its own current guards and historical
authorization, including source-denied versus source/scope-closed precedence.
For replies, both sides may have reached End, so an open-source-only lemma is
wrong. A generic candidate relation that omits relevant binding/source identity
or permits different readiness after authorization is not enough for this bridge.

## Exact late-first-authorization case

The required directed schedule is: both inner selected consumptions; truthful
classification; J diagnostic Send; J End; first reply authorization; reply
admission; J publication; caller delivery/selection. It must be available for
both Success and Failure End. Publication cannot jump over unresolved admission.

The inspected production conditions are specific. `compositionReplyBinding`
loads the binding using the intent's exact source run, verifies the composition
protocol, message kind, entry-member role, target caller subject/generation and
the entry port obligation. `AuthorizeIntent` still rejects changed source
revision or generation before considering the reply exemption. Stable generation,
revision, no retirement and valid original bindings are declared premises; End
alone does not fail first authorization for this bound reply. `recordCompositionReply`
checks the original template entry-port Send schema and retains the disposition
with original invocation/root identity. `captureCompositionIntents` includes the
earlier committed bound reply in J's freeze. `prepareCompositionScope` waits for
its disposition, gathers accepted responses for failed as well as successful
members, and applies missing_reply conversion only to successful members.

Do not claim an ordinary route grants this exception: raw binding/schema/route
authentication is a later correspondence obligation. O's ownership/open lifetime
supplies the declared eligible destination and selected await; it is not a
substitute for reply binding. Current `DeliverInvocationOutcome` retains the
original caller observation directly, separately from ordinary message admission;
open caller service is needed for consumption, and J's owned children must remain
eligible before J End. No newly committed invocation after End is authorized by
the reply exception.

## Additive implementation plan

Keep all new files under `research/substitution/callable_join*.go`, in the same
package so historical internals need no exporting or restructuring. Reuse the
unchanged K1/component Graph, primitive Operation storage, CheckLocalRelation and
candidate-only component checker. Add a dedicated N config validator, physical
depth2/3 core config, J protocol/report record, J semantic control and fixed O
record. Keep the original S graph and request unchanged. Do not make J an old
wrapper slot with an ordinary answer response.

The old `Successors` publishes a present response only on successful freeze;
`explorer.safety` rejects non-success present envelopes. Those are suitable for
the old candidate subset, not for failed J with a present diagnostic. Give J an
explicit additive publication rule and independent envelope checker. Likewise
old `JoinConfig` validation, join core depth and prefix monitor depth are fixed
to the M profile. Use new physical guards; any reuse of the old e/h/S monitor
requires an explicit checked depth/parent/ledger normalization, not bypassed
validation or relabeling. Prefer small N adapters over changes to old APIs.

Model report data as a comparable semantic value: original id, one of four tags,
cardinality 0/1 and optional original answer record. Do not select concrete byte
bounds or retained collection layout from unseen construction output. Report
schema/layout correspondence is postfreeze work. Write the independent prefix
monitor's table separately from the model classifier. Keep prefix validity,
component conformance, K_join and G_outer as separate verdicts.

The monitor must remember original committed/admitted/requested/authorized
operations; exact reply and publication payloads; original consumed flags;
candidate unmatched-receive evidence; classification completion; J report
commitment/authorization/admission and freeze; J public envelope/delivery/selection;
and O decision/End/root publication. Include every future-relevant field in the
model×monitor key. Existing candidate-component monitor memory must be keyed or
proved derivable from these keyed records. In particular a state merge cannot
forget whether the designated pending event or actual selected consumption
occurred.

Add an explicit finite lifted-relation checker after reference review. For each
reachable replacement/full state and associated R-related K1 state, test forward
event transfer, valid pure stutters, equal sidecar/public context state, and
bilateral enabled declared environment transfers. Check constructor guard and
resource projection cases separately. The A/B checker may use public-state
erasure as the particular R witness; the generic written argument must quantify
over supplied R and must not define conformance as passing replacement products.

## Maxima, rank and validation order

The domain is exactly 16 requests per K1/A/B product, 48 configurations total,
with S answer behavior. No state/edge/test-leaf/maximum count is predetermined.
Use one full product with separate justified projections for K_join and G_outer;
do not count their two predicates as two independent enumerations.

For pending maxima require: original e request consumed; any chosen helper
correctly completed and actually consumed; designated unmatched receive reached;
original S published, delivered and consumed; J awaiting original e with no
classification/report/End/publication; caller awaiting original J with no
decision/End/root publication. No second request or Pending diagnostic exists.
For other modes require both joins and the exact mode diagnostic/envelope through
actual O decision, End and root publication. Failed/absent modes remain failures.

Construct rank from intrinsic monotone protocol/authorization/control milestones
and bounded private instruction positions, never history length or observed
counts. Account for phase changes/reset scratch fields explicitly. Derive a
conservative finite Cartesian state and model×monitor bound from final fields;
derive an upper rank cap before census, and check strict increase on every edge,
including edges to already seen nodes. A failed rank leaves cycle status
unresolved unless separately analyzed. Pure abstract stutters cannot conceal an
infinite private loop: generic progress needs a well-founded stutter argument,
and the finite A/B instances need their own all-mode rank checks.

Explore every edge before deduplication, retain every actual zero-successor
maximum and shortest failure witness, and do not prune failures. A safe finite
prefix is not a maximum. If a practical cutoff is introduced, report incomplete
search rather than completion; no cutoff is planned. Eventual eligible service
excludes infinite idle/retry/restart-only suffixes, not the specified unmatched
receive. Model rank supplies no concrete instruction/dispatch/byte budget.

After the controller's construction gate: implement reference and independent
monitor plus directed construction/adversarial tests; freeze their source and
obtain independent reference review before any A/B acceptance or artifact/output
inspection. Then run K1-first products, aligned local relation plus separate
open-progress checks, lifted finite instances and replacement products. Use
targeted commands following the existing Go package conventions with new test
names fixed by the implementation; do not run the historical broad census merely
to obtain apparent coverage. Artifact mapping, operational limits, concrete
runtime samples/raw audit and final manuscript reconciliation are later distinct
obligations. No tests or new Go commands ran in this preparation stage.

## Required adverse fixtures and unresolved premises

- Earliest e publication/delivery while S is unproduced: e must remain unconsumed
  until original S selection; afterward both caller sides can select e.
- S admission before and after e admission with the same prior J offset: no
  double q charge, depth undercount, refund or silent suppression of a refusal.
- J Send then failed/successful End before first authorization: report accepted
  under exact binding; unbound/wrong-source/generation/revision/caller/obligation
  variants must fail the binding/profile obligation, never gain the exception.
- Failed J with an admitted diagnostic must publish response-present; successful
  J without a diagnostic publishes failed/missing_reply, while failed J without
  one publishes failed/member_failed absent. Both absent diagnostics violate
  K_join and must not be interpreted as candidate_failed by O.
- Classification before either original consume, merely delivered S, helper
  substituted for e, duplicate report/consumption and a tag without the committed
  classification/report instruction must be rejected.
- Truthful requested-absent/actual-member_failed classification can pass prefix
  policy but must fail K1/K_join mode conformance; requested mode is no classifier.
- A schema-valid authentic false report may pass O's public policy while failing
  J truth. This is the distinction between G_outer policy and K_join conformance.
- Pending before helper consumption, before actual unmatched receive, or before
  S selection is incomplete/stuck, not the intended pending maximum. Any release,
  later candidate activity or invented Pending publication is out of profile.

At this checkpoint the generic environment-restriction/delayed-selection bridge,
authorization-extension lemma, lifted transition argument and progress transfer
are designed but not independently checked. The reference premise, finite
instances, compiler/artifact correspondence and operational bounds are also
unestablished. A substantive failure must be retained at its smallest exact
transition/premise. If only the finite instances are discharged, report bounded
nested preservation and name the missing bridge; enumeration itself is not the
constructor theorem. No broader context grammar, recursive nesting, exact-debit
A/B equivalence, scheduler confluence, compiler theorem or recovery result follows.
