#!/usr/bin/env python3
"""Verify all P2 ZIP volumes and original raw bytes; optionally extract to a NEW directory."""
import argparse, contextlib, hashlib, io, json, pathlib, tarfile, zipfile

def hashfile(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def require(test,message):
    if not test: raise ValueError(message)

def safe(name):
    p=pathlib.PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and str(p)==name

class Joined(io.RawIOBase):
    def __init__(self,folder,entries):
        super().__init__(); self.folder=folder; self.entries=iter(entries); self.z=None; self.f=None
    def readable(self): return True
    def readinto(self,b):
        while True:
            if self.f is None:
                entry=next(self.entries,None)
                if entry is None: return 0
                self.z=zipfile.ZipFile(self.folder/entry['name']); self.f=self.z.open(entry['member'])
            chunk=self.f.read(len(b))
            if chunk: b[:len(chunk)]=chunk; return len(chunk)
            self.f.close(); self.z.close(); self.f=None; self.z=None
    def close(self):
        if self.f is not None: self.f.close()
        if self.z is not None: self.z.close()
        super().close()

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('folder',type=pathlib.Path);p.add_argument('report',type=pathlib.Path)
p.add_argument('--extract',type=pathlib.Path)
a=p.parse_args(); folder=a.folder.resolve(strict=True)
index=json.loads((folder/'evidence-index.json').read_text())
require(index['format']=='alan/performance-p2/raw-evidence/v2','unsupported format')
require(bool(index['archives']),'no volumes')
whole=hashlib.sha256(); total=0; checked=[]
for i,e in enumerate(index['archives'],1):
    require(e['name']=='alan-p2-raw-%03d.zip'%i,'out-of-order volume')
    require(e['member']=='alan-p2-raw.tar.gz.part%03d'%i,'out-of-order part')
    path=folder/e['name']; require(path.stat().st_size==e['bytes'],'ZIP size')
    require(hashfile(path)==e['sha256'],'ZIP hash: '+e['name'])
    h=hashlib.sha256(); count=0
    with zipfile.ZipFile(path) as z:
        require(z.namelist()==[e['member']],'unexpected ZIP member')
        with z.open(e['member']) as f:
            for b in iter(lambda:f.read(1024*1024), b''):
                h.update(b); whole.update(b); count+=len(b); total+=len(b)
    require(count==e['part_bytes'] and h.hexdigest()==e['part_sha256'],'part hash/size')
    checked.append({'name':e['name'],'sha256':e['sha256']})
require(total==index['tar_gzip_bytes'] and whole.hexdigest()==index['tar_gzip_sha256'],'joined gzip mismatch')
if a.extract:
    a.extract=a.extract.resolve(); a.extract.mkdir(parents=True,exist_ok=False)
seen=set(); inner=None; original_bytes=0
with Joined(folder,index['archives']) as raw:
    with io.BufferedReader(raw) as buffered:
        with tarfile.open(fileobj=buffered,mode='r|gz') as tar:
            for member in tar:
                require(member.isfile() and safe(member.name),'unsafe/non-file tar member')
                if member.name=='MANIFEST.json':
                    require(inner is None,'duplicate manifest')
                    inner=json.load(tar.extractfile(member)); continue
                require(member.name.startswith('raw/'),'unexpected tar namespace')
                name=member.name[4:]
                require(safe(name) and name not in seen and name in index['files'],'unknown/duplicate raw file')
                expected=index['files'][name]; require(member.size==expected['bytes'],'raw size: '+name)
                out=contextlib.nullcontext(None)
                if a.extract:
                    target=a.extract/name; target.parent.mkdir(parents=True,exist_ok=True); out=target.open('xb')
                h=hashlib.sha256(); count=0
                with tar.extractfile(member) as f, out as sink:
                    for b in iter(lambda:f.read(1024*1024), b''):
                        h.update(b); count+=len(b)
                        if sink is not None: sink.write(b)
                require(count==expected['bytes'] and h.hexdigest()==expected['sha256'],'raw hash: '+name)
                original_bytes+=count; seen.add(name)
require(seen==set(index['files']),'missing original files')
require(inner=={k:index[k] for k in ('format','identity','files','excluded')},'inner/outer manifest mismatch')
record={'ok':True,'identity':index['identity'],'index_sha256':hashfile(folder/'evidence-index.json'),
        'archives':checked,'files_verified':len(seen),'bytes_verified':original_bytes,
        'tar_gzip_sha256':whole.hexdigest(),'script_sha256':hashfile(pathlib.Path(__file__)),
        'extracted_to':str(a.extract) if a.extract else None}
with a.report.open('x') as f: json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'ok':True,'archives':len(checked),'files':len(seen),'bytes':original_bytes}))
