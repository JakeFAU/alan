# ALAN P2 retained execution evidence

Draft PR: https://github.com/JakeFAU/alan/pull/11
Base: 76031c34c1d0eeff325e1a8e9ca4b6e2fa2b6315
Measured production implementation: 2fe47cb75f57bf3f7f79779dc1841c9b9b8f28d0
Frozen delivery: 49101122c31b0d790d364831f044bb996d2649fa
Tree: 5f04fcc3f81ba78b4a53e179657dccc956cd7761

Download all twenty alan-p2-raw-001.zip through alan-p2-raw-020.zip and
alan-p2-evidence-index.zip into one directory. Unzip only the index ZIP there.
The raw ZIPs contain ordered parts of one gzip-compressed tar; they are not
independent subsets. The verifier reads them directly and reconstructs the
stream without relying on shell concatenation or modifying the ZIPs.

Using Python 3 (standard library only):

    python3 verify_p2_volumes.py . fresh-verification.json

To verify and reconstruct every original file under a new directory:

    python3 verify_p2_volumes.py . fresh-extraction-verification.json --extract ./retained-p2

Both report paths and the extraction directory must be new. Budget at least
7.2 GB for reconstructed evidence plus about 477 MB for downloaded volumes.
The index records SHA-256 and size for every original file, every ZIP and part,
and the complete compressed stream. The verifier checks ordered volume names,
archive membership, joined bytes, original file hashes, safe regular-file paths
and exact inner/outer manifest agreement. No database is opened for verification.

14,032 included files / 7,140,508,321 original bytes / 20 volumes.
The index explicitly inventories 2,818 disposable cache files and 30 compiled
executables omitted from publication. Executable source, build records and
hashes are retained. Included raw evidence bytes and the original filename set
were checked unchanged; excluded cache byte contents are not certified.

The immutable source exports are baseline/, candidate/ and final-delivery/source/.
The final-delivery/source.tar and its 482-file manifests bind the delivery tree.
Raw paired measurements, diagnostics, profiles, failed runs, command ledgers,
controlled histories, rejection/correction evidence and independent reviews are
retained at their original relative paths. See the frozen source documentation
under docs/evidence/performance-p2/ for method and reproduction commands.

After extraction, compact results can be reconstructed without database/network
access, choosing a fresh output outside the retained inputs:

    python3 retained-p2/final-delivery/source/docs/evidence/performance-p2/extract_results.py --inputs retained-p2 --source retained-p2/final-delivery/source --out ./fresh-results

Moving evidence changes recorded argv/path provenance. Numeric results and CSV
are deterministic; the source option is an interpretation checkout, not proof
that a new checkout was the measured source.

Qualification limitation: full ordinary integration failed twice on the frozen
delivery. The existing TestCompetingReadCannotSettleAdopterDebt also failed fixed
repetitions on unchanged baseline and delivery. Full integration-race and the
other stated checks passed; these do not erase the failures. Seventeen further
failed histories were retained and inspected. No equal failure-rate or universal
causal explanation is claimed. Final independent approval is for draft delivery
only, not merge/release or an all-green qualification claim.

Publication helpers and this bootstrap were produced after the source freeze.
They do not change or relabel the reviewed/tested source. The local publication
review concerns sealed bytes; public attachment download checks are a separate
record linked on the PR after upload.
