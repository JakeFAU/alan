#!/usr/bin/env python3
"""Download only observed GitHub PR attachment URLs and compare sealed local bytes."""
import argparse,hashlib,json,pathlib,urllib.parse,urllib.request
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('source',type=pathlib.Path);p.add_argument('links',type=pathlib.Path);p.add_argument('output',type=pathlib.Path)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
entries=json.loads(a.links.read_text()); seen=set(); results=[]
for e in entries:
 name,url=e['name'],e['url'];parsed=urllib.parse.urlsplit(url)
 if pathlib.Path(name).name!=name or name in seen:raise ValueError('unsafe/duplicate name')
 if parsed.scheme!='https' or parsed.hostname!='github.com' or not parsed.path.startswith('/user-attachments/files/'):raise ValueError('unobserved attachment route')
 seen.add(name); source=a.source/name; target=a.output/name
 record=dict(name=name,url=url,expected_sha256=digest(source),expected_bytes=source.stat().st_size)
 try:
  with urllib.request.urlopen(url,timeout=45) as response, target.open('xb') as f:
   record.update(http_status=response.status,content_type=response.headers.get('Content-Type'))
   for b in iter(lambda:response.read(1024*1024),b''):f.write(b)
  record.update(bytes=target.stat().st_size,download_sha256=digest(target))
  record['ok']=record['bytes']==record['expected_bytes'] and record['download_sha256']==record['expected_sha256']
 except Exception as error:record.update(ok=False,error=str(error))
 results.append(record);print(json.dumps(record),flush=True)
report={'ok':all(r['ok'] for r in results),'files':results,'links_sha256':digest(a.links),'script_sha256':digest(pathlib.Path(__file__))}
(a.output/'download-verification.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['ok'] else 1)
