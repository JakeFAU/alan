#!/usr/bin/env python3
"""Independent read-only audit; outputs only beside this script, never in evidence/source."""
import collections, datetime, gzip, hashlib, io, json, pathlib, tarfile, tempfile, zipfile
V = pathlib.Path(__file__).resolve().parent
R = pathlib.Path('/private/tmp/alan-p2-tf46z4pm')
A = V / 'alan-p2-evidence-v2'
I = A / 'evidence-index.json'
J = json.loads(I.read_bytes())
CHUNK = 1024 * 1024

def digest(path):
    h = hashlib.sha256()
    n = 0
    with path.open('rb') as f:
        for b in iter(lambda: f.read(CHUNK), b''):
            h.update(b); n += len(b)
    return {'bytes': n, 'sha256': h.hexdigest()}

def safe_name(name):
    p = pathlib.PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and p.as_posix() == name, name

assert J['format'] == 'alan/performance-p2/raw-evidence/v2'
assert pathlib.Path(J['source_directory']).resolve() == R.resolve()
F = J['files']
E = {e['path']: e for e in J['excluded']}
assert len(E) == len(J['excluded']) and not (set(E) & set(F))
actual = set()
for p in R.rglob('*'):
    assert not p.is_symlink(), str(p)
    if p.is_file(): actual.add(p.relative_to(R).as_posix())
assert actual == set(F) | set(E), {'missing': sorted((set(F) | set(E))-actual), 'unlisted': sorted(actual-set(F)-set(E))}
for name, expected in F.items():
    safe_name(name)
    assert digest(R/name) == expected, name
print('All included originals hashed:', len(F), flush=True)
compiled = []
cache_count = 0
for name, e in E.items():
    safe_name(name)
    p = R/name
    assert p.stat().st_size == e['bytes'], name
    if e['reason'] == 'disposable cache':
        parts = pathlib.PurePosixPath(name).parts
        assert 'staticcheck-cache' in parts or '__pycache__' in parts or p.name == '.DS_Store' or p.suffix == '.pyc', name
        cache_count += 1
    else:
        assert e['reason'] == 'compiled executable; source/build/hash retained', e
        with p.open('rb') as f: magic = f.read(4)
        assert magic in (b'\x7fELF', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca'), (name, magic)
        assert digest(p) == {'bytes':e['bytes'], 'sha256':e['sha256']}, name
        compiled.append({'path':name,'bytes':e['bytes'],'sha256':e['sha256']})
source_before = json.loads((R/'final-delivery/source-before.json').read_bytes())
source_after = json.loads((R/'final-delivery/source-after-qualification.json').read_bytes())
assert len(source_before) == 482
assert source_before == source_after
source_names = {n.removeprefix('final-delivery/source/') for n in F if n.startswith('final-delivery/source/')}
assert source_names == set(source_before)
for name, sha in source_before.items(): assert F['final-delivery/source/'+name]['sha256'] == sha, name
assert digest(R/'final-delivery/source-before.json')['sha256'] == 'b85f8c2fb6e20258a1e2968ba3034676546306402d81e4e912ff4d297c43af91'
assert digest(R/'final-delivery/source.tar')['sha256'] == 'f02e3082b456b68a6528ad58ad98d4b085f5a76fe91bcf020a8f1284878cead1'
assert J['identity']['delivery_commit'] == '49101122c31b0d790d364831f044bb996d2649fa'
assert J['identity']['delivery_tree'] == '5f04fcc3f81ba78b4a53e179657dccc956cd7761'
review_sha = digest(R/'reviews/task6-whole-branch-review.md')['sha256']
assert review_sha == '8ead6c431de962ee8eb67bf1e7ab3da9f0e8e6eeb522d671789dc662b67b50dd'
qualification = json.loads((R/'final-delivery/qualification-summary.json').read_bytes())
assert qualification['all_commands_successful'] is False
print('Frozen source and exclusions checked:', len(source_before), cache_count, len(compiled), flush=True)
archive_results = []
with tempfile.TemporaryFile(dir=V) as joined:
    whole = hashlib.sha256(); total = 0
    for seq, a in enumerate(J['archives'], 1):
        assert a['name'] == 'alan-p2-raw-%03d.zip' % seq
        assert a['member'] == 'alan-p2-raw.tar.gz.part%03d' % seq
        zpath = A/a['name']
        assert digest(zpath) == {'bytes':a['bytes'], 'sha256':a['sha256']}, zpath
        assert a['bytes'] < 24*1024*1024
        with zipfile.ZipFile(zpath) as z:
            assert z.namelist() == [a['member']]
            zi = z.getinfo(a['member'])
            assert zi.compress_type == zipfile.ZIP_STORED
            h = hashlib.sha256(); n = 0
            with z.open(zi) as part:
                for b in iter(lambda:part.read(CHUNK), b''):
                    joined.write(b); h.update(b); whole.update(b); n += len(b); total += len(b)
            assert n == a['part_bytes'] and h.hexdigest() == a['part_sha256']
            if seq < len(J['archives']): assert n == 23*1024*1024
            else: assert 0 < n <= 23*1024*1024
        archive_results.append(a)
    assert total == J['tar_gzip_bytes'] and whole.hexdigest() == J['tar_gzip_sha256']
    print('ZIP, part, and joined compressed hashes checked:', len(archive_results), total, flush=True)
    joined.seek(0)
    seen = set(); raw_bytes = 0; inner = None
    with gzip.GzipFile(fileobj=joined, mode='rb') as gz:
        with tarfile.open(fileobj=gz, mode='r|') as tar:
            for entry in tar:
                assert entry.isfile(), entry.name
                safe_name(entry.name)
                f = tar.extractfile(entry)
                if entry.name == 'MANIFEST.json':
                    assert inner is None
                    inner = json.loads(f.read())
                    continue
                assert entry.name.startswith('raw/'), entry.name
                name = entry.name[4:]
                assert name in F and name not in seen, name
                h = hashlib.sha256(); n = 0
                for b in iter(lambda:f.read(CHUNK),b''):
                    h.update(b); n += len(b)
                assert {'bytes':n,'sha256':h.hexdigest()} == F[name], name
                assert entry.size == n
                seen.add(name); raw_bytes += n
        # A full gzip EOF read independently verifies decompression integrity/trailer.
        trailing = 0
        for b in iter(lambda:gz.read(CHUNK),b''):
            assert not b.strip(b'\0'), 'Nonzero bytes beyond the completed tar stream'
            trailing += len(b)
    assert seen == set(F)
    assert inner == {k:J[k] for k in ('format','identity','files','excluded')}
    assert raw_bytes == sum(x['bytes'] for x in F.values())
print('All tar payload bytes checked against original hashes; gzip EOF/CRC checked:', len(seen), raw_bytes, flush=True)
report = {
 'status':'PASS_LOCAL_INTEGRITY_ONLY',
 'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'index':str(I),'index_sha256':digest(I)['sha256'],
 'source_directory':str(R),'included_files':len(F),'included_raw_bytes':raw_bytes,
 'all_included_original_hashes_match':True,'original_filename_set_exact':True,
 'excluded_files':len(E),'excluded_cache_count':cache_count,'excluded_compiled_executables':compiled,
 'excluded_cache_limit':'Cache path policy and present sizes checked; excluded cache bytes are not claimed preserved or published.',
 'excluded_executable_hashes_match':True,
 'archives':archive_results,'gzip_bytes':total,'gzip_sha256':whole.hexdigest(),
 'all_zip_crc_and_hashes_match':True,'all_tar_member_hashes_match_originals':True,
 'inner_outer_manifests_equal':True,'gzip_eof_crc_checked':True,
 'frozen_source_files':482,'frozen_source_before_after_equal':True,'source_identity':J['identity'],
 'sealed_whole_branch_review_sha256':review_sha,
 'qualification_all_commands_successful':False,
 'qualification_limit':'Both unmodified final ordinary full-integration attempts failed; draft delivery only, no passing final ordinary full-integration qualification, no merge or release approval.',
 'packager_sha256':digest(V/'package_p2_volumes.py')['sha256'],
 'supplied_verifier_sha256':digest(V/'verify_p2_volumes.py')['sha256'],
 'independent_auditor_sha256':digest(pathlib.Path(__file__))['sha256'],
 'published_download_verification':'pending actual URLs'
}
assert report['packager_sha256'] == J['packager_sha256']
out = V/'p2-publication-independent.json'
with out.open('x') as f: json.dump(report,f,indent=2);f.write('\n')
print('Report:',out,flush=True)
