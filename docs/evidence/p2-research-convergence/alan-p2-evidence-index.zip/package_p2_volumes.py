#!/usr/bin/env python3
"""Seal raw P2 evidence into a losslessly split tar.gz, in uploadable ZIP volumes."""
import argparse, gzip, hashlib, io, json, pathlib, tarfile, zipfile

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

class Volumes:
    def __init__(self, output):
        self.output, self.pending, self.entries = output, bytearray(), []
        self.whole, self.bytes = hashlib.sha256(), 0
        self.limit = 23*1024*1024
    def write(self, data):
        self.whole.update(data); self.bytes += len(data)
        view = memoryview(data)
        while view:
            n = min(self.limit-len(self.pending), len(view))
            self.pending.extend(view[:n]); view = view[n:]
            if len(self.pending) == self.limit: self.emit()
        return len(data)
    def flush(self): pass
    def emit(self):
        if not self.pending: return
        i = len(self.entries)+1
        member = 'alan-p2-raw.tar.gz.part%03d' % i
        path = self.output / ('alan-p2-raw-%03d.zip' % i)
        part_hash = hashlib.sha256(self.pending).hexdigest()
        with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_STORED) as z:
            z.writestr(member, self.pending)
        assert path.stat().st_size < 24*1024*1024
        self.entries.append({'name':path.name,'bytes':path.stat().st_size,'sha256':digest(path),
                             'member':member,'part_bytes':len(self.pending),'part_sha256':part_hash})
        print(path.name, path.stat().st_size, flush=True)
        self.pending.clear()

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('source',type=pathlib.Path); p.add_argument('output',type=pathlib.Path)
a=p.parse_args(); source=a.source.resolve(strict=True); output=a.output.resolve()
if output==source or source in output.parents: raise ValueError('output must be outside source')
output.mkdir(parents=True,exist_ok=False)
manifest={}; excluded=[]
for path in sorted(source.rglob('*')):
    name=path.relative_to(source).as_posix()
    if path.is_symlink(): raise ValueError('unexpected symlink: '+name)
    if not path.is_file(): continue
    if 'staticcheck-cache' in path.parts or '__pycache__' in path.parts or path.name=='.DS_Store' or path.suffix=='.pyc':
        excluded.append({'path':name,'reason':'disposable cache','bytes':path.stat().st_size}); continue
    with path.open('rb') as f: magic=f.read(4)
    if magic in (b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe',b'\xbe\xba\xfe\xca'):
        excluded.append({'path':name,'reason':'compiled executable; source/build/hash retained','bytes':path.stat().st_size,'sha256':digest(path)}); continue
    manifest[name]={'bytes':path.stat().st_size,'sha256':digest(path)}
identity=json.loads((source/'final-delivery/source-identity.json').read_text())
inner={'format':'alan/performance-p2/raw-evidence/v2','identity':identity,'files':manifest,'excluded':excluded}
(output/'input-manifest.json').write_text(json.dumps(inner,indent=2)+'\n')
volumes=Volumes(output)
with gzip.GzipFile(filename='',mode='wb',fileobj=volumes,mtime=0,compresslevel=6) as compressed:
    with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
        for name,m in manifest.items():
            info=tarfile.TarInfo('raw/'+name); info.size=m['bytes']; info.mode=0o644; info.mtime=0
            with (source/name).open('rb') as f: tar.addfile(info,f)
        data=(json.dumps(inner,sort_keys=True)+'\n').encode()
        info=tarfile.TarInfo('MANIFEST.json'); info.size=len(data); info.mode=0o644; info.mtime=0
        tar.addfile(info,io.BytesIO(data))
volumes.emit()
for name,m in manifest.items():
    path=source/name
    if path.stat().st_size!=m['bytes'] or digest(path)!=m['sha256']: raise ValueError('input changed: '+name)
# Detect added/deleted included files as well as changed bytes.
actual=set()
for path in source.rglob('*'):
    if path.is_symlink(): raise ValueError('new symlink')
    if path.is_file(): actual.add(path.relative_to(source).as_posix())
expected=set(manifest)|{e['path'] for e in excluded}
if actual!=expected: raise ValueError('input file set changed')
index=dict(inner, source_directory=str(source), archives=volumes.entries,
           tar_gzip_bytes=volumes.bytes,tar_gzip_sha256=volumes.whole.hexdigest(),
           input_bytes_unchanged=True,packager_sha256=digest(pathlib.Path(__file__)))
(output/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'archives':len(volumes.entries),'raw_bytes':sum(x['bytes'] for x in manifest.values()),'compressed_bytes':volumes.bytes,'input_bytes_unchanged':True}),flush=True)
