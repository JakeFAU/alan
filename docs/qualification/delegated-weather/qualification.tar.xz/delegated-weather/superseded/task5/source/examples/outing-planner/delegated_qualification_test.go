//go:build integration

package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// The raw checker independently validates both cuts. This additional comparison
// binds their immutable rows, including paid charge/fact prefixes, across reopen.
func requireDelegatedRawPrefix(t *testing.T, before, after string) {
	t.Helper()
	program := `import sqlite3,sys,json
from pathlib import Path
def read(p):
 with sqlite3.connect(Path(p).resolve().as_uri()+'?mode=ro',uri=True) as db:
  return {t:[tuple(r) for r in db.execute('SELECT * FROM "'+t+'"')] for t, in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
a,b=map(read,sys.argv[1:])
fixed=('metadata','programs','composition_deployment','composition_profile','composition_roots','composition_static_members','composition_templates','run_origins')
prefix=('history','intents','attempts','adapter_attempts','adapter_dispatch_admissions','adapter_results','settlements','admissions','message_acknowledgments','composition_charges','composition_facts','composition_admission_decisions','composition_invocations','composition_bindings','composition_members','composition_requests','composition_replies','composition_reservations','composition_freezes','composition_publications','composition_results','composition_outcome_deliveries','composition_root_publications')
for t in fixed: assert sorted(a[t])==sorted(b[t]),('frozen inventory changed',t)
for t in prefix: assert all(r in b[t] for r in a[t]),('retained row prefix changed',t)
print(json.dumps({'frozen_tables':list(fixed),'prefix_tables':list(prefix),'retained_charges':len(a['composition_charges']),'final_charges':len(b['composition_charges']),'preserved':True}))`
	output := rawModelCommand(t, "-c", program, before, after)
	if err := os.WriteFile(strings.TrimSuffix(after, ".db")+"-prefix.json", output, 0600); err != nil {
		t.Fatal(err)
	}
}

// This uses the real compiled CLI's replacement export, including its exact
// original IDs and separate costs, as an optional cross-check of both raw Stores.
func TestDelegatedQualificationCLIReplacement(t *testing.T) {
	binary := publicOutingBinary(t)
	dir := t.TempDir()
	if root := os.Getenv("ALAN_RAW_CAPTURE_DIR"); root != "" {
		if err := os.MkdirAll(root, 0700); err != nil {
			t.Fatal(err)
		}
		var err error
		dir, err = os.MkdirTemp(root, "cli-replacement-")
		if err != nil {
			t.Fatal(err)
		}
	}
	command := exec.CommandContext(t.Context(), binary, "check-replacement", "--config", "testdata/configuration.json", "--fixture", "testdata/fixture.json", "--weather", delegatedWeather, "--output-dir", filepath.Join(dir, "pair"))
	output, err := command.CombinedOutput()
	recordOutingCommand(t, command.Args, output, err)
	if err != nil {
		t.Fatalf("actual CLI replacement: %v\n%s", err, output)
	}
	var report replacementReport
	if err := json.Unmarshal(output, &report); err != nil {
		t.Fatal(err)
	}
	if report.Delegated == nil || !report.Delegated.PositiveReplacement {
		t.Fatal("CLI did not report successful bounded replacement")
	}
	pair := filepath.Join(dir, "pair")
	for _, name := range []string{"baseline", "candidate"} {
		original := filepath.Join(pair, name+".db")
		before, err := os.ReadFile(original)
		if err != nil {
			t.Fatal(err)
		}
		// The CLI has exited and closed the owner. Its read-only Go reader
		// supplies SQLite's empty WAL/read-side SHM for a WAL-header file.
		// No source main bytes or logical records are repaired or changed.
		outingProcessJSON(t, binary, "inspect", original)
		rawModelCommand(t, "model/test_evidence.py", "capture", original, filepath.Join(pair, name+"-captured.db"))
		after, err := os.ReadFile(original)
		if err != nil {
			t.Fatal(err)
		}
		digest := sha256.Sum256(before)
		if digest != sha256.Sum256(after) {
			t.Fatal("read-only capture preparation changed original main file")
		}
		raw, _ := json.MarshalIndent(map[string]any{"original_main_sha256": fmt.Sprintf("%x", digest), "original_main_unchanged": true, "method": "CLI exited and owner closed; public read-only inspect supplies reader sidecars; unchanged mode=ro transactional backup with full row/schema equality"}, "", "  ")
		if err := os.WriteFile(filepath.Join(pair, name+"-read-provenance.json"), append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
	rawModelCommand(t, "model/run.py", "compare", "--baseline", filepath.Join(pair, "baseline-captured.db"), "--candidate", filepath.Join(pair, "candidate-captured.db"), "--configuration", filepath.Join(pair, "derived-configuration.json"), "--fixture", filepath.Join(pair, "fixture.json"), "--manifest", filepath.Join(pair, "deployment-manifest.json"), "--replacement", filepath.Join(pair, "replacement.json"), "--output", filepath.Join(pair, "independent-comparison.json"))
	t.Logf("actual CLI replacement capture: %s", pair)
}

// Retain argv, exit and bytes for fresh public commands during qualification.
func recordOutingCommand(t *testing.T, args []string, output []byte, runErr error) {
	t.Helper()
	root := os.Getenv("ALAN_RAW_CAPTURE_DIR")
	if root == "" {
		return
	}
	dir, err := os.MkdirTemp(root, "command-")
	if err != nil {
		t.Fatal(err)
	}
	code := 0
	if runErr != nil {
		code = -1
		if e, ok := runErr.(*exec.ExitError); ok {
			code = e.ExitCode()
		}
	}
	raw, err := json.MarshalIndent(map[string]any{"argv": args, "exit": code}, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "command.json"), append(raw, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "output.json"), output, 0600); err != nil {
		t.Fatal(err)
	}
}
