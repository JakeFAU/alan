# Raw Store contract preparation — delegated Weather

Read-only source inspection at owning runtime base `7dd7be83f29d7b2b06b8a525a9bb89619b5bbd6d`; `git diff BASE -- internal/executor` was empty. This is wire-contract preparation, not implementation, review approval, a test result, or qualification. Read global/research AGENTS and research `memory/adversarial/known_weaknesses.md`. No future example implementation was used as a semantic oracle. Paths below are relative to `/Users/jacob/.codex/worktrees/weekend-outing-planner/alan`.

## Main conclusions / narrow truthful claim

The retained data supports a **complete inventory, exact original-record linkage, globally ordered composition facts, and a legal model path consistent with all those facts and all remaining causal constraints**. It does not provide an exact global transaction/event chronology for ordinary admissions, acknowledgments, adapter settlements, or endpoint contacts. Do not label a chosen topological ordering of those events the observed trace.

The first source-authorization preclose condition is checkable, not merely guessed: `attempts.result` retains `Authorization.Source.{Run,Epoch,Sequence,Revision}`, disposition, and closure operation; its composition authorization fact has a global order. Resolve the source projection at that exact local sequence and compare the authorization fact with the source's terminal execution/freeze fact. **The authorization fact's own `Sequence` is the ORIGINAL INTENT sequence, not the later authorization snapshot sequence** (`composition_source.go:29`). Check both.

Conversely the stronger historical scheduling statement “the decision was the sole pending internal delivery at its commit” cannot generally be recovered from a final Store: acknowledgments/admissions have no retained order. Capture that actual cut, verify its complete pending inventory then, and bind the capture to the final history prefix. The trusted runner source supplies the conditional delivery-before-next-Commit argument (`runner.go:161`, `runner.go:188`, `runner.go:286`, `runner.go:324`), not a universal liveness theorem. An eventual final acknowledgment does not prove acknowledgment before an earlier unrelated commit.

## Supported storage boundary and exhaustive table inventory

Pin **physical schema 9**, `metadata.schema_version == PRAGMA user_version == 9`, semantics `alan/1d/v1`, external key version 2, composition profile `alan/composition/v1`, `RecordDispatchAdmissions:true`, no continuations/request-authority/reconciliation. Base 3 + composition protocol 4 + dispatch-admission table gives format 9 (`store.go:347–399`, `receipt_conflict.go:14`, `composition_types.go:13–18`, `program.go:16`). Both ordinary direct and delegated Stores can use this same format. A read-only transaction on the already captured `/private/tmp/alan-author-validation-fdac2f8/pre/recommended.db` confirmed format 9 and the 42 tables below for a pre-port direct Store. That observation does not qualify the future delegated feature.

Do not silently accept format 4 as equivalent: it has no dispatch-admission evidence. Formats 3,5–8,10–16 add/remove other protocols/evidence and are outside this fixture checker. If a receipt conflict promotes 9 to 10, reject as unsupported evidence rather than dropping `receipt_conflicts`. Creation/promotion: `store.go:347–399`, `receipt_conflict.go:58–92`.

Enumerate `sqlite_master` and table/column/PK/foreign-key/index metadata; allow only the exact source schema and SQLite-generated indexes. Reject extra tables, views or triggers. Enumerate every row in a single read transaction with `mode=ro` (never immutable against a WAL). Inventory each table, complete primary key, count and exact typed column bytes; preserve SQL NULL versus empty strings, integer versus text, and raw BLOB bytes. Use a specified length-delimited typed encoding for row digests, not lossy JSON conversion of blobs. Keep semantic decoded comparison separate from raw byte inventory. An application export is only a cross-check, never the enumeration source.

Full columns in declaration order; parentheses indicate primary keys. D = descriptor BLOB. Source DDL: `store.go:106–126`, `composition_store.go:15–25`, `invocation.go:16–26`, `dispatch_admission.go:15–18`.

| Table | Columns / key |
|---|---|
| metadata | (singleton), schema_version, semantics, key_version, namespace |
| programs | (id), semantics, bytes |
| subjects | (id), generation, owner, revision, retired, retry_cancelled |
| permissions | (kind,source,target,operation,revision,obligation) |
| runs | (subject,generation), program_id, initial, epoch, sequence, projection |
| history | (subject,generation,sequence), epoch, source_revision, selected_observation, successor, intents |
| observations | (id), subject, generation, D, consumed_sequence |
| intents | (id), subject, generation, sequence, ordinal, source_revision, D; UNIQUE(subject,generation,sequence,ordinal) |
| terminal_obligations | (subject,generation), sequence, outcome, destinations, delivery_status, operation_id, source_revision |
| admissions | (id), domain, transport_id, D, result, observation_id; UNIQUE(domain,transport_id) |
| message_acknowledgments | (intent_id), admission_id |
| attempts | (id), intent_id, D, result |
| lifecycle_results | (id), decision_sequence UNIQUE, D, result |
| run_origins | (subject,generation), kind, operation_id, predecessor_generation, D |
| external_attempts | (intent_id), D |
| external_receipts | (intent_id), D |
| corpus_assets | (id), D |
| adapter_attempts | (intent_id), D |
| adapter_results | (intent_id), D |
| settlements | (id), intent_id, D, observation_id |
| composition_profile | (singleton), version, D |
| composition_roots | (id), D |
| composition_static_members | (subject,generation), root_id, D |
| composition_templates | (id), D |
| composition_facts | (decision_order), id UNIQUE, kind, D |
| composition_invocations | (id), operation_id UNIQUE, template_id, root_id, D, admission |
| composition_bindings | (id), invocation_id UNIQUE, D |
| composition_members | (subject,generation), invocation_id, root_id, member, D; UNIQUE(invocation_id,member) |
| composition_results | (invocation_id), decision_order UNIQUE, D |
| composition_charges | (operation_id,kind), root_id, decision_order, D |
| composition_deployment | (singleton), D |
| composition_permissions | (singleton), D |
| composition_reservations | (operation_id), root_id, D |
| composition_root_publications | (scope_id), root_id, decision_order UNIQUE, D |
| composition_closures | (scope_id), root_id, decision_order UNIQUE, D |
| composition_publications | (operation_id), D |
| composition_outcome_deliveries | (operation_id), observation_id UNIQUE |
| composition_admission_decisions | (operation_id), root_id, D |
| composition_requests | (invocation_id), observation_id UNIQUE, D |
| composition_replies | (operation_id), invocation_id, D |
| composition_freezes | (scope_id), root_id, D |
| adapter_dispatch_admissions | (intent_id), prepared_digest, after_fact |

Structural metadata is meaningful evidence: programs, subjects, permissions, roots, templates, membership, initial projections, deployment, profile, and root origins must exactly match the pinned deployment boundary plus the one permitted dynamically created member. Do not dismiss them as unconstrained blobs. Deployment descriptor is `{Subjects,Runs}` and each initial run is `{ID,ProgramID,Projection}`; permissions descriptor is the original permission array (`store.go:498–508`). Static origins are `{Subject,ProgramID,Initial}` with kind root and NULL operation/predecessor (`store.go:481–492`). Dynamic invocation members have **no run_origins row**; their creation provenance is `composition_members` (`invocation.go:407–438`).

Always empty for this feature: `lifecycle_results`, `external_attempts`, `external_receipts`, `corpus_assets`, `composition_closures`; no terminal destinations, lifecycle operation IDs, continuation/authority payloads, receipt or lifecycle admissions. They remain inventoried. `terminal_obligations` itself is NOT empty: it records ordinary End, with destinations `[]`, delivery_status `{}`, operation_id NULL. Refused invocation is also NOT a reason to require empty `composition_publications` or `composition_outcome_deliveries`.

For direct variants only: templates and all invocation-specific tables (`composition_admission_decisions`, invocations, bindings, members, requests, replies, results, publications, outcome_deliveries) are empty. Delegated refusal retains template metadata and admission decision but creates no binding/member/request/run/charge. All cut-sensitive tables may legitimately be empty before their corresponding stages. Unknown nonempty categories reject; never filter them away.

## Record shapes and links

JSON field names use Go exported names, with omission only where declarations specify it. `RunID={Subject,Generation}`; `Projection={PC,Data,Status,Cursors?}`; `Value={Kind,Number,Text,Flag,List?}` (`program.go:36–93`, `schema/schema.go:14–20`). Lists contain typed records, not plain scalar JSON arrays.

### History, originals, selection

`history.intents` is the full JSON **array of Intent objects**, NOT IDs or a summary. Intent is `{Authority?,ID,Run,Sequence,Ordinal,Kind,Target,Generation,Obligation,Payload}`. Each commit serializes the exact reduction intent array to history, then writes every object to intents in the same transaction, copying source_revision from the source run (`store.go:891–944`). Require a bijection between all embedded intents and all table rows; match complete descriptors, run/sequence/ordinal/revision and IDs. Contiguous history is 1..runs.sequence; first predecessor is runs.initial, final successor equals runs.projection. A filtered export omitting an original cannot pass this bijection.

Observation is `{ID,Run,Kind,Provenance,Source,SourceGeneration,Obligation,Operation,Payload}`. Selection is **both** history.selected_observation and observations.consumed_sequence for the SAME `(subject,generation)`. A higher sequence on another run means nothing. Exactly one reverse selected-history link must exist if consumed_sequence is non-NULL. History.epoch and source_revision describe that local commit; runs.epoch may increase on reopen for open runs (`store.go:696`, `store.go:865–913`). No missing history operation/selection may be hidden as pure computation.

### Ordinary messages, first authorization, admission, acknowledgment

`attempts.id = JSON(["authorization",intentID])`. Descriptor `{Intent:<whole original>,Revision:<original source_revision>}`; result `{ID,IntentID,Allowed,Reason,Source:{Run,Epoch,Sequence,Revision},ClosureOperation}` (`messages.go:47–58`, `messages.go:122–188`). Require exactly the canonical first attempt per authorized original, descriptor equality and source-history projection consistency. Fixed deployment permits no revision/generation changes, retirement, or nonempty ClosureOperation. Ordinary first auth after End is `Allowed:false,Reason:"source_closed"`; retained allowed first auth survives later End. Bound helper replies have a distinct exception and may be authorized after local End (`messages.go:160–175`).

Admission descriptor `{TransportID,Kind,LogicalID,Source,Target,Generation,Obligation,Operation,Payload,IntentID,TerminalSequence,Continuation?}`; result `{TransportID,Accepted,Reason,Bound,ObservationID}` (`messages.go:23–45`). Admission key = JSON(["admission",domain,transportID]); ordinary message descriptor has Kind=message, LogicalID=IntentID=original ID, original Run as Source, exact target/generation/obligation/payload, empty Operation. Ordinary admitted observation ID = JSON(["observation","message",intentID]), provenance ordinary-message (`messages.go:239`, `messages.go:367–395`). Accepted ordinary admission creates its observation atomically; denied ordinary admission does not. Bound may still name the target on refusal. Never equate Accepted:false with absent Bound.

Acknowledgment points to an admission key; it exists for either accepted or refused delivery and adds no observation (`messages.go:243–272`). Thus acknowledgment alone proves neither acceptance nor consumption. Validate all admissions and any additional transport attempts; do not assume table cardinality one transport per intent without declaring the runner-only input restriction. Multiple ordinary transports can share the same logical observation identity. Bound helper reply is the special accepted-without-observation case below.

### Adapter chain and charges

`AdapterAttempt={Authority?,Intent,AuthorizationID,Prepared,Allowed,Reason}`; `Prepared={Request,Digest,Protocol,Endpoint,Model,MaxOutputTokens,MaxResponseBytes,Wire}`; `Request={ID,Key,Capability,Effect,Input,Output,Payload,Assets}` (`adapters.go:20`, `effects/effects.go:74–91`). Bind original intent, authorization, frozen schema/payload/endpoint and exact wire. Attempt insertion, reservation and allowed effect charge are atomic (`adapters.go:236–275`).

Reservation `{OperationID,RootID,Kind,Run,Sequence,Allowed,Reason,AttemptDigest}` uses the original sequence and whole-attempt digest. Reservation fact exists whether allowed or denied; exactly one effect charge iff allowed, `{RootID,OperationID,Kind:"effect",Invocations:0,CreatedRuns:0,Effects:1,DecisionOrder:<reservation fact>}` (`composition_reservation.go:10`, `composition_reservation.go:70–106`). Debit is reservation, not evidence that a network call happened.

Dispatch admission columns bind original ID, prepared digest, and `AfterFact` equal to the global journal prefix at final gate admission (`dispatch_admission.go:8–45`). This means gate passed **after that prefix and before any subsequent fact**, not that endpoint execution/contact occurred. Same-prefix admissions do not have a retained shared global order. With no durable result, retained evidence cannot distinguish crash before transport from transport performed with lost response; endpoint logs/process cut evidence are required for the latter claim. Do not invent a successful result or redispatch event from an allowed attempt.

`AdapterResult={RefusalWitness?,Read?,Reconciled?,Digest,Candidate,Values,Disposition}`. Candidate `{ID,Key,Disposition,Payload,HTTPStatus,RequestID,ResponseID,ReturnedModel,Response,Usage}` (`adapters.go:28`, `effects/effects.go:94`). Native response evidence is `Candidate.Response`; values alone do not prove it. Bind ID/key/request/response bytes to frozen fixture. Result insertion has `external_result` fact; unknown/empty disposition is rejected as a result (`adapters.go:390–450`). Digest hashes result with empty Digest (`adapters.go:742`). No receipt-reconstruction/read/witness fields are allowed in this fixture.

Settlement is a separate transaction: adapter admission + observation + settlements row (`adapters.go:453–512`). Admission TransportID=JSON(["adapter-delivery",intentID]); LogicalID/Operation/IntentID=original ID; Source={capability,1}; Target/Generation=original run; Payload=result.Values. Observation provenance runtime-adapter. Settlement ID=JSON(["adapter-outcome",intentID]), descriptor is the complete AdapterResult, observation_id links to that observation. Selection must occur on the original direct Weather/helper run. Result-before-settlement and settlement-before-selection are distinct supported cuts.

### Invocation and helper chain

Wire structs: `composition_types.go:87–133`; writers `invocation.go:250–267`, `invocation.go:382–531`.

- Invocation `{ID,OperationID,TemplateID,RootID,ParentInvocationID,Caller,SourceRevision,SourceSequence,Depth,Inputs}` is rooted in the exact invocation intent. ID=SHA256(Go JSON(["alan/invocation/v1",[namespace,operationID]])). Dynamic member RunID={SHA256(Go JSON(["alan/invocation-member/v1",[invocationID,memberName]])),1} (`composition_types.go:135–148`).
- Admission `{Invocation,Accepted,Reason,BindingID,Members}` is always retained in `composition_admission_decisions`, with an admission fact. Refusal has no invocation/binding/member/request/charge rows. Accepted `composition_invocations` duplicates both exact invocation and exact admission descriptors; check both directions.
- Binding `{Protocol?,ID,Version,Namespace,InvocationID,OperationID,TemplateID,RootID,Caller,Depth,Members,Programs}` maps member names to exact runs/programs. Member descriptor `{Run,InvocationID,RootID,Member,ProgramID,Initial,Owner}`; owner is `invocation:<invocationID>`. Accepted creation creates subject/run plus only permitted dynamic permissions.
- Request is an Observation copied into `composition_requests.descriptor`: ID hash domain `alan/invocation-request/v1`, Run=exact entry, Kind=message, Provenance=runtime-invocation-request, Source=caller subject/generation, Obligation=entry port obligation, Operation=invocation operation ID, Payload=original inputs (`invocation.go:484–503`). There is **no base admissions row** for this request. It is atomic with accepted admission/member creation/charge; helper selection is later.
- Invocation charge `{RootID,OperationID,Kind:"invocation",Invocations:1,CreatedRuns:len(template.Members),Effects:0,DecisionOrder:<admission fact>}`. Fixed feature len=1, Depth=1; no additional invocation/effect charge on outcome delivery or reopen.
- Reply descriptor `{InvocationID,RootID,Intent,Authorization,Accepted,Reason}` references the exact bound helper message intent and its first authorization. Reply fact and base message admission are retained in the same transaction; Accepted true reason recorded_reply is **Bound=caller but ObservationID empty and SQL observation_id NULL** (`invocation_outcome.go:125–218`). Parent does not receive a plain ordinary-message observation. Acknowledgment still references this base admission. Restrict the post-End authorization exception to the exact bound reply; never to assessment/decision.
- Freeze `{InvocationID,Trigger,Run,Sequence,DecisionOrder,Status,ReplyIntents,InvocationIntents,ExternalIntents}` is atomic with terminal execution/fact and lists all relevant original member intents, sorted (`invocation_outcome.go:222–291`, `invocation_outcome.go:571–626`). Scope key is invocation ID or `root:<rootID>`; terminal_obligations remains independently required. Recompute lists from all member histories at its fact prefix. Freeze contains bound replies, invocations, adapter/external intents, **not ordinary public sends**.
- Outcome `{ID,InvocationID,OperationID,TemplateID,Caller,Status,Reason,ResponsePresent,Response,DecisionOrder}`. `composition_publications` exists for accepted AND rejected admissions. `composition_results` exists only for accepted invocations and duplicates the same outcome/fact order (`invocation_outcome.go:461–530`). Rejected admission can therefore have a publication and authenticated result observation without any `composition_invocations` or `composition_results` row.
- Outcome observation ID hash domain `alan/invocation-result-observation/v1` over outcome.ID; Run=Caller; Kind=invocation; Provenance=runtime-invocation; Source=TemplateID; SourceGeneration=1; Obligation=original invocation obligation; Operation=original ID; payload status/reason/response_present plus response.<field>. `composition_outcome_deliveries` links operation to observation. No base admissions/settlements row is written (`invocation_outcome.go:533–569`). Publication + accepted result-copy (if any) + observation + delivery are committed in **one transaction**. Existing public SettleInvocation does not expose a durable publication-without-delivery cut. Model may separate events abstractly, but do not claim such a runtime crash cut.

Root outcome uses scope/OperationID/InvocationID `root:<rootID>`, Caller=root.Run, outcome.ID domain `alan/root-outcome/v1`, root publication row and outcome fact atomically (`composition_root.go:23–84`). It creates no ordinary message. Root descendant debt excludes known rejected admission, while caller outcome/selection debt remains (`composition_inspect.go:113–129`, `inspection_pending.go:71–83`). Preserve these two categories separately, including rejected-unpublished and rejected-published-unselected cuts. A published failure does not erase unresolved descendant effects.

## Ordered facts, remaining gaps, and checker implementation boundary

Fact descriptor `{AuthorityAdmission?,Version,ID,Kind,Order,RootIDs,Run,Sequence,OperationID,RecordDigest}` (`composition_facts.go:31–46`). Allowed kinds here: execution, authorization, admission, reservation, reply, freeze, outcome, external_result; lifecycle must remain empty. Require contiguous Order=1..N and a source-row/fact bijection. Execution fact digest binds `{Run,Sequence,Epoch,Revision,Selected,Successor,Intents}`, with Successor/Intents as raw JSON objects/array, not quoted JSON strings (`composition_facts.go:56–76`). Authorization digest binds attempts.result; external_result binds adapter_results descriptor (`composition_source.go:19–29`). Other protocol facts bind their whole source descriptor (`invocation_outcome.go:29–123`). These hashes are domain-separated SHA256 over Go JSON; canonical Go field ordering/map-key sorting/HTML escaping must be implemented correctly if recomputed. Raw row-byte inventory hashes are a separate mechanism and do not replace these protocol bindings.

Retained causal orders sufficient for requested source claims: original execution < first authorization; authorization snapshot sequence exact at authorization fact prefix; authorization < linked ordinary selection; admission fact < helper request selection; original adapter < auth < reservation < dispatch prefix < known result fact < original-run selection; bound reply auth < reply fact; terminal execution < freeze; required result/reply/accepted descendant outcomes < successful publication; publication < parent selection < assessment original execution. Use globally ordered facts for cross-run inequalities, not numeric comparison of local sequences. Unordered admitted/settled observations must have a legal placement before their selection, after their exact source predecessor, and before target End for ordinary admission; match cut-stage presence and consumed state.

Information not retained exactly: ordinary admission target sequence/epoch/time, acknowledgment time, adapter settlement time, actual transport entry/contact/response arrival time, dispatch admissions' order relative to one another at a common fact prefix, and full owner-reopen chronology. Existence of rows constrains but does not supply those times. Do not claim actual global order, endpoint contact, capacity duration, or scheduler provenance from fabricated timestamps or rowid. For actual dispatch concurrency at capacity one, combine recorded gate/result-prefix constraints with the declared trusted runner gate and endpoint evidence; a durable reservation alone is not an active network call.

Consequently report separately: (1) complete inventory and exact linkage accepted/rejected; (2) all observed fact orders consistent with a legal finite-model path consuming every event and final debt; (3) first authorization preclose predicate verified/violated/pending at this cut; (4) sole-delivery decision-cut premise captured and verified, or not established from this cut; (5) endpoint/contact claims supported only by independently captured process/endpoint evidence. Unsupported tables/events reject; information gaps must narrow the claim, never remove record coverage or add runtime hooks.

## Program retention/cardinality addendum

Enumerate **all** `programs` rows, including inert unreferenced artifacts omitted by public deployment/snapshot views. Compare the exact ID/semantics/bytes set to the complete frozen pre-execution artifact manifest; reject every extra/missing row, even when no run or template references it. Do not infer this set from snapshot artifacts or referenced runs alone.

`createStore` inserts every `Provision.Programs` artifact before validating roots/templates (`store.go:417–429`); `insertArtifact` checks hash/semantics/bytes and deduplicates equal IDs (`store.go:532–571`). Template members look up already-retained ProgramID bytes (`composition_binding.go:61–69`). Thus the helper prototype is present **before admission**, including on allowance-zero refusal and n=0. Accepted helper run `runs.program_id` and `composition_members.ProgramID` reuse the template member's prototype ID (`invocation.go:407–438`); binding.Programs must match that same ID (`composition_binding.go:242–249`). There is no additional retained bound-program artifact on admission. Endpoint binding produces an ephemeral interpreted program, explicitly never a stored artifact or ID alias (`composition_binding.go:265–271`, `composition_binding.go:291–306`).

For a fixture whose manifest contains exactly two distinct root artifacts and one distinct helper prototype, expect 2 direct / 3 delegated programs at every cut, independent of helper admission and epoch. The general source contract is the exact distinct manifest set, not a hard-coded count: reuse of equal artifacts deduplicates, and a supplied unrelated artifact can exist in Store storage despite never being referenced. The fixed application must reject that extra raw artifact even though runtime provisioning may accept it. No program cardinality should increase after helper admission in this feature.
