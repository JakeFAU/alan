# Task 4 — independent complete raw-Store correspondence

Status: DONE, pending independent review. This report does not claim approval, integration, process-kill qualification or endpoint-contact proof.

Task base: `c86d84411697c59a502c09a0d052af67d089360a`. Task commit: `320cafd` (full identity below). Evidence root: `/private/tmp/alan-delegated-task4-c86d844`; final frozen campaign: its `final/` directory.

## Implementation and scope

Added the independent schema9 reader/correspondence implementation in `examples/outing-planner/model/evidence.py`. `check.py` retains the independently authored finite protocol unchanged and adds CLI routing only. The reader never calls the production compiler, reducer, runtime evidence verifier, native-response verifier, or production report to obtain its verdict. The Go harness creates trusted fixtures, chooses cuts using public runtime controls, captures raw Stores, optionally exports reports, and invokes Python. Its expected classifications are test assertions, not inputs to the checker.

The controller approved the two-source separation and supplied the narrow governing spec/plan edits included in this task. Exactly nine files belong to the commit: those two governing documents, model `check.py`, `evidence.py`, `run.py`, `test_model.py`, `test_evidence.py`, `README.md`, and `delegated_model_test.go`. No production runtime, application behavior, research, dependency, unrelated source, generated evidence or investigation artifact is included. No subagent, branch transition, publication, push, merge or historical commit rewrite was performed.

Reconstruction validates complete program inventory against the selected deployment (including inert rows and the refused helper prototype); exact static authority/resource envelopes; contiguous history and original-intent bijections; predecessor opcodes for observable/pure distinctions; full selected observations; first source authorization against its source snapshot and global fact prefix; one original transport each, admission, acknowledgment and selection; accepted/refused invocation atomic groups; helper binding/request/reply; complete terminal frozen originals; atomic publication/result-copy/delivery; native fixture request/result/schema/suitability; original reservations/dispatches/results/settlements; exact ordered charges; and every source-bound composition fact/digest. All retained rows receive explicit coverage rules. Remaining raw rows fail closed.

The compatible-path search consumes all reconstructed observables against independent `successors`, preserving ordered composition facts and dispatch prefixes while allowing compatible placements for ordinary admissions, acknowledgments and adapter settlements. The output does not claim their observed total chronology. Final state, root status, original mappings, debts and charges are explicit. Rejected correspondence yields a specific invariant witness and nonzero exit, with captured execution provenance; accepted correspondence additionally includes full inventory/schema/coverage and a compatible model path.

## Stable launcher and checker contract

```
python3 -I -B examples/outing-planner/model/run.py check \
  --store FILE --configuration FILE --fixture FILE --manifest FILE \
  [--report FILE] --output FILE
python3 -I -B examples/outing-planner/model/run.py compare \
  --baseline FILE --candidate FILE --configuration FILE --fixture FILE \
  --manifest FILE [--replacement FILE] --output FILE
```

`run.py` declares precisely `('check.py', 'evidence.py')`. It captures both immutable byte buffers before executing either. `execute_sources(sources, paths, launcher_source, argv)` requires exactly those source/path keys, hashes the buffers, compiles those same buffers into fresh namespaces, injects the model namespace as evidence's `MODEL`, and injects the evidence API into the model before invoking `main`. No filesystem/local import, reused local module cache, missing-source fallback or bytecode cache is an execution dependency. Unexecuted test siblings are outside the declared executable source set.

`execution.source_sha256` remains the check.py hash. `source_files` is the complete named hash map. `source_set_sha256` is SHA-256 of `b'outing-source-set/v1\0'` plus sorted compact JSON of that map. Launcher bytes are separately hashed; launcher/interpreter/standard-library integrity remains trusted. Replacement-race tests change both source paths after capture and verify the captured buffers execute and determine metadata. Missing and unexpected executable inputs, missing real evidence path, nonisolated execution and unsupported commands reject.

Final executable identities, shared by enumeration and all 83 raw cut outputs:

- check.py: `4da5c4966b9c83776c4f6e47e3493da66231267ab68a53c5e7843387afb3807d`
- evidence.py: `2eb2eed050baee3564ea07777c668020ed3bcfc73a99e5ccb29b39267bcefcca`
- run.py: `929c1d92d5769cc4d732462fac9cd45e34750628d100b2d12b6b51c30e44921b`
- Complete source set: `f050f3c9bc3e3f848d65a3be57c0a497d33c4185df2e9c4d17f1b3c52a5b7ba8`

`final/source/` captures all nine changed files before final build/run; `source-hashes.json` names all hashes. A post-run hash audit confirmed all nine current files unchanged, every cut's executable and launcher identities matching, 42 inventories per cut, every row classified, and every captured destination still matching its capture hash. `final/capture-audit.json` records that audit. Full source/launcher hashes also remain embedded in each check/compare output and enumeration JSON.

## Raw schema and safe capture contract for Task 5

The reader opens `mode=ro`, enables query-only, starts one read transaction and reads schema plus every row before closing it. No immutable shortcut or silent repair. It pins exact schema objects, normalized DDL, columns/primary keys, foreign keys, indexes and user_version9. The complete 42-table inventory is:

```
adapter_attempts, adapter_dispatch_admissions, adapter_results, admissions,
attempts, composition_admission_decisions, composition_bindings,
composition_charges, composition_closures, composition_deployment,
composition_facts, composition_freezes, composition_invocations,
composition_members, composition_outcome_deliveries, composition_permissions,
composition_profile, composition_publications, composition_replies,
composition_requests, composition_reservations, composition_results,
composition_root_publications, composition_roots, composition_static_members,
composition_templates, corpus_assets, external_attempts, external_receipts,
history, intents, lifecycle_results, message_acknowledgments, metadata,
observations, permissions, programs, run_origins, runs, settlements, subjects,
terminal_obligations
```

Nonempty lifecycle_results, external_attempts, external_receipts, corpus_assets and composition_closures are unsupported. Nonfixture authority, admission, reconciliation, observation, fact, program or operation records fail exact structural/semantic coverage. An extra empty schema object also rejects.

Each row inventory includes exact primary key, typed byte digest and covering rule. Row encoding is a N/I/F/T/B type tag, uint64 big-endian length, and payload for each cell; payloads are null/ASCII integer/IEEE754 double/UTF8 text/unchanged BLOB. Hash prefix is `outing-raw-row/v1` plus NUL. `raw_cut_sha256` binds the sorted table-to-ordered-row-hash map with `outing-raw-cut/v1` plus NUL. Schema metadata is separately retained in output. This is not a lossy JSON digest of SQL values.

The reusable safe capture command is:

```
python3 -I -B examples/outing-planner/model/test_evidence.py capture SOURCE.db FRESH-CUT.db
```

Keep the source cut and any WAL available. The helper opens a read-only transaction, forces its schema snapshot, backs up that transaction, switches only the fresh destination to DELETE journal mode, and compares complete source/destination schema metadata plus every logical row from the same source snapshot. It records all typed row hashes, the equality result, SQLite version and destination file hash in `FRESH-CUT.db.capture.json`. Existing destinations reject. This helper is fixture/capture infrastructure, not a semantic verdict. The live-WAL regression verifies complete equality and that the original remains unchanged/readable and the destination needs no WAL.

`ALAN_RAW_CAPTURE_DIR` names a retained parent directory for Go fixture output. Each unique scenario directory contains frozen `derived-configuration.json`, `fixture.json`, `deployment-manifest.json` written before Create, original `*-live.db`, self-contained named cut `.db`, `.db.capture.json`, optional `*-report.json`, and `*-check.json`. Pair fixtures additionally have `comparison.json`. Caller must preserve capture/source integrity and bind any process chronology separately; the directory name alone is not a provenance theorem. Task5 can call the same safe helper while its owned source/WAL are available.

The Task2 development baseline's lone main-file/WAL-header situation exposed `sqlite3.OperationalError: unable to open database file` under read-only Python. No original was repaired. An early disposable copy opened writable was used only for development, with no completeness claim. The 508-row development candidate inventory likewise was preparation, not the final source-bound qualification. A read-only reproduction is preserved at `final/development-readonly-reproduction.log`: Python3.9.6 / SQLite3.54.0, absent -wal/-shm, `sqlite3.connect(path.as_uri()+'?mode=ro',uri=True).execute('SELECT count(*) FROM sqlite_master').fetchone()`, exit1 with the same error. Go's pinned `github.com/mattn/go-sqlite3 v1.14.52` bundles SQLite3.53.4 (`sqlite3-binding.h`); system sqlite3 is3.54.0. Final qualification cuts use the consistent backup method, not main-file copies.

## RED evidence and corrected reader boundaries

Preserved RED logs are under the task evidence root:

- `reader-red.log`: `python3 -I -B examples/outing-planner/model/test_evidence.py`, before reader implementation: 3 tests, 3 errors for missing STORE_SCHEMA/raw_row_digest. This is API absence RED, not a semantic-control result.
- `reply-candidate-red.log`: `OUTING_RAW_FIXTURE=<development complete pair> python3 -I -B examples/outing-planner/model/test_evidence.py CopiedStoreControls`, before the payload correspondence rule: 1 failure, `AssertionError: InvariantError not raised`. A copied complete Store had a same-shaped helper assessment candidate changed while preserving the intent/history linkage. Adding exact ordered candidate/original-handle checks made it fail at the intended invariant.
- `report-red.log`: `OUTING_RAW_FIXTURE=<captured complete two-candidate pair> python3 -I -B examples/outing-planner/model/test_evidence.py CompleteEvidenceControls.test_report_omitted_reply_and_changed_effect_consequence`, before those report correspondence fields were checked: 2 subtest failures, `InvariantError not raised`, for omitted Replies and false effect Consequence. Full raw-linked report field checks made both reject specifically. Historical RED logs retain output and test name; these two environment values are described by role because the original command lines were not separately archived.

During fixture integration, checks correctly exposed reader assumptions requiring correction: root profiles are ID-sorted; unavailable native results retain declared output defaults; public pending contains invocation-member dependencies; public Pending suppresses recorded-reply acknowledgment while the runner still needs the raw acknowledgment; a known invalid native result can keep public `Consequence: unresolved` despite a durable diagnostic result. The reader was corrected against owning public/source contracts. No runtime behavior or checks were weakened and no runtime defect was found. Initial iteration logs remain separate (`iteration-3.log`, `iteration-4.log`, `recheck-5.log`).

The earlier complete `iteration-6.log` campaign passed with79 cuts and its earlier evidence hash `83dd55635dbb6882875689a1cb6b87cf018fa0d7daba3281d17ce72b160d64ea`. Its exact earlier executable bytes were recovered by reversing the final additions and verified against all79 output hashes; `iteration-6/source/README-capture.txt` explicitly distinguishes recovered matching bytes from contemporaneous source capture. The final campaign separately froze its sources before execution and added the requested n=1 refusal case.

## Final verification commands and results

Commands run from repository root unless the working directory is stated. Every successful command below exited0; expected rejection controls exited1 as asserted. Logs are under `/private/tmp/alan-delegated-task4-c86d844/final`.

```
python3 -I -B examples/outing-planner/model/test_model.py
python3 -I -B examples/outing-planner/model/test_evidence.py
python3 -I -B examples/outing-planner/model/run.py enumerate \
  --output /private/tmp/alan-delegated-task4-c86d844/final/enumeration.json
```

`model-tests.log`:24/24 passed,0.829s. `source-evidence-tests.log`:4 raw source-only tests passed,5 fixture-dependent methods explicitly skipped (9 discovered),0.056s. These skips are not counted as executed controls. `enumeration.log` / `enumeration.json`:346 configurations,31,102 states,79,866 edges under the final two-source launcher. Finite enumeration is separate from concrete correspondence and still labels its own bounded domain.

```
go test -tags integration -c \
  -o /private/tmp/alan-delegated-task4-c86d844/final/raw-evidence-tests \
  ./examples/outing-planner
staticcheck -tags integration ./examples/outing-planner
```

Build passed. Staticcheck2026.2.2 (0.8.2) passed with empty `staticcheck.log`; Go1.27.4 darwin/arm64. Initial restricted cache access needed the ordinary tool-approved Go-cache execution; no automatic approval rejection occurred.

From `examples/outing-planner`:

```
ALAN_RAW_CAPTURE_DIR=/private/tmp/alan-delegated-task4-c86d844/final/captures \
  /private/tmp/alan-delegated-task4-c86d844/final/raw-evidence-tests \
  -test.run '^TestDelegatedRaw' -test.v
```

`go-harness.log`:all four top-level tests passed: fixture matrix22.18s, fourteen cut/resume controls120.48s, public decision controls2.90s, frozen-reply control1.25s. This final source-frozen execution produced83 verified cuts,11 independent pair comparisons and17,051 explicitly covered rows across cuts. Repeated-prefix rows are counted per captured cut, not claimed unique records. Classifications:28 complete,41 pending,9 refused,2 diagnostic_terminal,2 unknown_forecast,1 confirm_first_cycle.

Fixture matrix: direct/candidate initial and final cuts for n0/n1/n2; suitable/unsuitable/no-match; unavailable and mixed unavailable/suitable; helper allowance0 separately at n0,n1,n2; missing durable forecast response; unchanged two-candidate confirm-first cycle. Pair comparison keeps actual direct/delegated costs separate and does not turn equal incomplete answers into replacement success.

Cut/resume matrix: proposal commit, invocation commit, request admission, native result before settlement, settled result before selection, second original forecast commit, helper terminal/freeze, published helper outcome before parent selection, public assessment commit, decision commit, decision authorization, decision admission before selection, refusal before publication, refusal published but unselected. Every cut was then resumed and rechecked.

Public controls: first decision authorization after Outing End retains source_closed and remains valid incomplete evidence; first authorization before End followed by admission after End completes. Original transports are explicitly acknowledged. Frozen helper reply: original reply survives End/freeze, Prepare/Settle cannot publish before admission; post-End bound authorization/admission is accepted as recorded_reply without direct observation; the unacknowledged raw debt remains visible; acknowledgment then publication creates the later parent observation; final run completes.

```
OUTING_RAW_FIXTURE=/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawModel-two-1917707332 \
OUTING_RAW_PENDING_FIXTURE=/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawModel-unknown-3886699137 \
OUTING_MUTATION_DIR=/private/tmp/alan-delegated-task4-c86d844/final/mutations \
  python3 -I -B examples/outing-planner/model/test_evidence.py
```

`mutation-tests.log`:all9/9 methods executed and passed, no skips,2.735s, on final source bytes and final complete/unknown cuts. Fourteen copied-Store semantic controls preserve original hashes and assert specific invariants: extra inert program, hidden original forecast, hidden charge, extra retained child, wrong adapter owner, changed helper request, swapped original native results, same-shaped candidate, same-shaped valid original handle, duplicate original reply, duplicate observation, removed result, cross-run authorization sequence, premature assessment. Copies and `.mutation.json` evidence remain under `final/mutations/`. Valid IDs/equal cardinality are used where relevant so these controls reach intended semantic checks, not only parser failures. Separate report tests omit each of seven raw collections, invocation/root collections and Replies, alter Consequence, and omit or change a valid pending original. The pending-change control preserves cardinality and substitutes another real original operation.

```
python3 -I -B /private/tmp/alan-delegated-task4-c86d844/final/check-optional-export.py
```

Three optional replacement-export controls passed. A synthetic export assembled from the final real production reports (not a CLI-produced replacement artifact) is accepted; substituting another valid forecast handle rejects `replacement report original mapping and separate actual costs`; altered fixture hash rejects `replacement frozen input digests`. Inputs, outputs, exact subprocess command arrays and exits are retained in `synthetic-export-*.json`, `optional-export-*-check.json`, `optional-export-tests.json`. The synthetic export supplies no verdict authority: both raw Stores are independently rechecked first.

`git diff --check` passed. Full complete diff including all three new files was preserved in `final/review.diff` and self-reviewed, followed by status/stat/source-hash audit. No unrelated working-tree changes were included.

## Boundaries and remaining work

All claims are bounded to exact schema9, frozen selected deployment/program manifest, normalized candidates, fixture response domain, at most two candidates/one helper, unchanged fixed authority and one transport identity per original. Wider runtime multiplicity is rejected as outside this example's domain, not declared forbidden runtime behavior. Canonical artifacts, calendar normalization, capture/source integrity, interpreter and standard library remain trusted; no compiler/full-bytecode proof, universal refinement/congruence or scheduling theorem is claimed.

A missing durable result remains epistemically unknown. The selected no-later-result/no-retry continuation is an explicit environment alternative, not proof that an authentic response can never arrive. Dispatch gates prove passage, not endpoint contact. `state_view.contacts` retains its prior symbolic dispatch meaning. `decision_commit_cut.verified` only speaks about that complete captured commit cut; a later Store cannot retroactively supply the historical sole-pending premise. Task5 must bind that cut to the final execution and independently supply endpoint acknowledgment/owner-kill/reopen/process-source evidence, archive the final campaign and run whole-repository checks.

No unresolved runtime discrepancy or known correctness concern remains from this implementation/self-review. The evidence reader is necessarily larger than the finite model; its separate approved file keeps raw wire/row rules distinct from protocol transitions. Independent review remains required before treating this task as approved.

## Commit and final status

Commit: `320cafd2bf113e0ff812b47d68fe846ec42c358a` — `Check delegated Weather raw Store correspondence independently`.

All nine staged files were byte-hash checked against the pre-run frozen source manifest before committing. Staged diff passed whitespace validation and contains exactly the approved nine files. Post-commit `git status --short` is empty. The task report is preserved under the existing ignored `.superpowers` evidence directory, consistent with previous task reports. No push, PR, merge or approval claim.

# Task 4 fix round 1 — concrete continuation and debt relation

Fix base: `320cafd2bf113e0ff812b47d68fe846ec42c358a`. The initial commit was independently **REJECTED** for spec compliance and quality, with the Important finding: **“Final concrete receive/control state and debt are not related to the matched model state.”** The preceding initial self-review statement is historical and superseded by that review. The reviewer report and witness remain unchanged at `/private/tmp/alan-delegated-task4-review.md`, `/private/tmp/alan-delegated-task4-final-wait-probe.py`, and `/private/tmp/alan-delegated-task4-final-wait-probe/`. No approval or integration claim is made for this fix; scoped re-review is required.

The required correction was: “define/check the concrete-to-model final continuation/debt relation, including exact receive kind, source, generation, obligation and original correlation at receive boundaries. Account explicitly for intermediate pure positions rather than treating every open projection as interchangeable. Add a semantic rejection control for a same-shaped wrong retained wait/correlation with otherwise consistent history/fact bookkeeping. This must run for raw checks without an application report.” The related historical receive boundary was also checked and corrected.

## Correction

The controller approved a bounded continuation walk over the pinned artifacts' pure instructions. Only `model/evidence.py`, `model/test_evidence.py` and `model/README.md` change in this fix. No model transition, runtime production behavior, harness, governing requirement, original fixture, artifact, or captured Store changed.

- `receive_match` resolves the actual receive tuple, verifies typed operands and applies the established helper binding. `historical_receives` compares that tuple against the exact selected raw observation using its actual predecessor projection. This runs for every selected receive, before optional report handling.
- `next_boundary` deep-copies the final retained projection and walks only `set`, `branch`, `jump`, `foreach`, `next`, `loop` and `append`. It never executes a receive, emit or End; it stops at that next observable boundary. Missing operands/cursors, unsupported instructions/offsets, invalid indices and an unresolved walk exceeding4,096 pure steps fail closed. A cycling control is covered. The walk handles retained cursor snapshots, indices and nested loop exits, and does not mutate raw records or its input projection.
- `expected_boundary` relates the matched model's exact actor phase and forecast/invocation stage to the concrete next boundary. It compares receive kind/provenance/source/generation/obligation/original correlation, or emit kind/target/generation/obligation/full payload, or End disposition. It covers initial and intermediate pure positions, forecast loops, original result waits, helper request/outcome waits, public message waits, refusal and terminal paths.
- `final_continuations` enforces that relation for every concrete actor, retaining the symbolic position, retained PC, pure-PC path and resolved next boundary. Open states are no longer interchangeable. `concrete_debts` separately derives debt from retained originals, raw authorization/admission/acknowledgment/selection, original effect stages, invocation rows, frozen candidates and local/root termination; equality with the model ledger is required. Both appear in checker output. These checks always run without requiring an application report.

This interprets the supported pure continuation slice for concrete correspondence. It does not replay all historical pure data changes or claim general VM, compiler or arbitrary-bytecode correctness. Production source was consulted only for the pinned pure-instruction/cursor wire semantics and exact receive matching contract, not as a verdict oracle; finite model rules remain unchanged and independent.

## RED

Command (repository root), before implementing the correction:

```
OUTING_RAW_CUTS=/private/tmp/alan-delegated-task4-c86d844/final/captures \
OUTING_MUTATION_DIR=/private/tmp/alan-delegated-task4-c86d844/fix-1/red-mutations \
  python3 -I -B examples/outing-planner/model/test_evidence.py ContinuationControls
```

Exit1. `fix-1/continuation-red.log` records four `AssertionError: InvariantError not raised` failures against the initial evidence implementation (`2eb2eed050baee3564ea07777c668020ed3bcfc73a99e5ccb29b39267bcefcca`). These are semantic acceptance failures, not missing APIs or stale hashes:

1. Final Weather PC moved from decision receive to proposal receive, matching the reviewer witness.
2. Final Weather PC moved into the wrong pure continuation region (decision processing without its receive).
3. The helper's second forecast wait changed to the first forecast's valid, same-shaped original ID.
4. A historical first forecast receive's actual predecessor correlation changed to the second forecast's valid original ID, while leaving the selected original observation intact.

Each copied mutation updates the linked history successor, current run projection when applicable, and corresponding execution fact's source digest. All original schemas, operations, artifact manifests and frozen inputs remain preserved. Original file hashes are checked. The historical variant establishes the related boundary concern with a dedicated probe rather than assuming it from the first reviewer witness. The initial RED method called the raw checker without a report; final GREEN controls additionally run the isolated captured-source CLI and retain execution metadata.

## Final frozen source and GREEN

Final evidence directory: `/private/tmp/alan-delegated-task4-c86d844/fix-1/final`. Six model/source/test/document files were captured before final execution in `source/`, with named identities in `source-hashes.json`:

- check.py: `4da5c4966b9c83776c4f6e47e3493da66231267ab68a53c5e7843387afb3807d` (unchanged).
- evidence.py: `7619ce8a34c100498eefbc8b241a0a590c99f88bc03ce7dc6d42658ffeb45399`.
- run.py: `929c1d92d5769cc4d732462fac9cd45e34750628d100b2d12b6b51c30e44921b` (unchanged).
- Complete source set: `df188f8dc135b6a58a9c431045861e13ff76080a9aab1c00d21d1dd2b72f285c`.
- test_model.py: `b6c5468a420c238ce2aef03ad5202c4eb5cad83d6717f73a6a24dc6368af73c7` (unchanged).
- test_evidence.py: `bd9b4f716212c6ba9a0f1f3c8736c9f6670e01dfd0d1600fd7761cb24c40858d`.
- README.md: `7d2f95852f3d8baf9e4e33c0df9422376995baf3cf548c014e674fbd384b0c92`.

All successful commands below exited0. Expected CLI mutation/probe rejection exits were1 and asserted. Exact output paths and argv are retained in new mutation `.mutation.json`, `rechecks/summary.json` and reviewer-witness records.

```
python3 -I -B examples/outing-planner/model/test_model.py
python3 -I -B examples/outing-planner/model/test_evidence.py
OUTING_RAW_FIXTURE=/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawModel-two-1917707332 \
OUTING_RAW_PENDING_FIXTURE=/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawModel-unknown-3886699137 \
OUTING_RAW_CUTS=/private/tmp/alan-delegated-task4-c86d844/final/captures \
OUTING_MUTATION_DIR=/private/tmp/alan-delegated-task4-c86d844/fix-1/final/mutations \
  python3 -I -B examples/outing-planner/model/test_evidence.py
```

- `model-tests.log`:24/24 passed,0.745s.
- `source-evidence-tests.log`:5 source-only methods passed;7 capture-dependent methods explicitly skipped;12 discovered,0.060s.
- `evidence-tests.log`:12/12 methods passed with no skips,4.841s. All previous14 copied-Store semantic controls and report/pending controls still pass, plus all four new source-bound raw-only controls. New failure outputs explicitly identify `concrete final continuation/model boundary` (three final-state cases) or `historical receive exact match/original correlation` (historical case). Copies and command/provenance/error logs are under `final/mutations`.
- Positive continuation regression checks more than1,000 retained positions across seven direct/candidate fixture pairs (empty,one,two,unavailable,refused n2,n1,n0), comparing the pure walk with the actual next retained observable boundary. It covers all seven supported pure opcodes and checks projections remain unchanged. These are interpreter correspondence tests over retained histories, not newly captured process cuts. Separate source-only controls assert bounded cycle, unknown-opcode and missing-operand rejection without input mutation.

```
python3 -I -B /private/tmp/alan-delegated-task4-c86d844/fix-1/recheck.py \
  /private/tmp/alan-delegated-task4-c86d844/fix-1/final/rechecks
python3 -I -B examples/outing-planner/model/run.py enumerate \
  --output /private/tmp/alan-delegated-task4-c86d844/fix-1/final/enumeration.json
```

`rechecks.log`:83 checks,0 failures;11 comparisons,0 failures. The script uses the isolated current launcher and original preserved Store/config/fixture/manifest/report inputs, saves every exact subprocess argv/exit and verifies each source Store file hash before/after. Comparison semantic mappings and separate costs match their prior outputs. All cut classifications remain unchanged:28 complete,41 pending,9 refused,2 diagnostic_terminal,2 unknown_forecast,1 confirm_first_cycle. No supported cut was dropped or report made mandatory. `enumeration.log`:346 configurations,31,102 states,79,866 edges on the fixed complete source set.

The exact preserved reviewer mutation was additionally checked with the current launcher, the same original frozen inputs and no report. It now exits1 with `concrete final continuation/model boundary: weather:await_decision`, showing actual `outing-proposal` versus expected `outing-decision`. The original reviewer mutation file itself remains unchanged. `reviewer-witness-recheck.json` retains the exact command array, exit/stdout/stderr, preserved probe hash and complete result; `reviewer-witness-check.json` is the source-bound rejection output. The original accepted reviewer result remains untouched in its original directory.

`final/audit.json` confirms all six frozen files remain byte-identical, all83 rechecks and four new negative CLI outputs carry the fixed source-set/launcher hashes, every cut's concrete debt equals its model debt, all42-table row inventories remain covered, and the aggregate17,051 per-cut rows remain unchanged. Existing83 captures are revalidated rather than relabeled as newly produced runtime evidence. No new Go campaign or Staticcheck run was needed: no Go/harness/runtime file changed, and every existing cut/pair was rechecked through the changed reader, as authorized by the controller. Prior Go/Staticcheck results remain historical evidence for their unchanged bytes.

A final operand-kind tightening initially had a missing Python parenthesis. Its immediate syntax failures are preserved separately in `fix-1/precompile-failure/`, including the superseded source snapshot; they supplied no qualifying verdict. The parenthesis was corrected before the final source freeze and all commands above ran cleanly on the final bytes. `fix-1/development-recheck` also preserves the earlier83-cut pass before final regression tightening; it is separate from final evidence.

## Self-review and fix commit

Self-reviewed the complete three-file fix diff preserved in `fix-1/final/review.diff`, then status/stat and `git diff --check`. Checked that the continuation walker uses a fresh copy, stops before all observables, fails on unsupported/unresolved paths, and preserves binding/correlation at both final and historical boundaries. Checked that raw acknowledgment debt remains independent of public report suppression and that the final debt comparison is unconditional. No governing requirement was relaxed; no application report or production verifier supplies a verdict; no runtime/research/unrelated file changed. No unresolved implementation concern remains, but independent scoped re-review is mandatory and Task5 remains pending.

Fix commit: `3af5726d38b0685f37314f00aad7ca39ae7064db` — `Bind raw continuations and debts to the protocol model`. Exactly three staged files were checked against their frozen final byte hashes before commit; cached diff whitespace check passed. Worktree status is clean after commit. Initial restricted Git-index access failed with Operation not permitted; ordinary tool-approved Git metadata access completed staging/commit, with no automatic approval rejection. No amend, push or integration was performed. Status: DONE, awaiting independent scoped re-review.

# Task 4 fix round 2 — optional original mapping in actual CLI exports

Fix base: `3e873c053832629e495790fbdb6ab2ce3e30c7b2`. The controller identifies `3af5726d38b0685f37314f00aad7ca39ae7064db` as the preceding approved Task4 gate, followed by the independently approved application export-timing correction. Earlier REJECT, correction, archived witnesses and source identities above remain preserved. This follow-up is independently reviewable and is not itself claimed approved. Task5's uncommitted work was paused and left untouched.

The actual allowance-zero CLI replacement export reached `replacement report original mapping and separate actual costs` despite both raw Stores independently passing. The exact witness remains unchanged at `/private/tmp/alan-delegated-task5-3af5726/post-fix-development/cli-replacement-refused-450424549/pair`; its original `independent-comparison.json` still records the failure on the prior evidence source. The original integration log is `post-fix-development/cli-table-green.log`.

The owning `forecastOperationPair` at `examples/outing-planner/replacement.go:473` declares both original-ID fields `omitempty`. `compareDelegatedReplacement` adds them only when the corresponding original exists. The Python comparison had always inserted both keys, using an empty string for an absent original, and then compared dictionaries literally. This was a checker/export-contract mismatch, not missing candidate work or a runtime defect.

## Narrow correction

Only `model/evidence.py` and `model/test_evidence.py` change. Expected mapping rows now always retain `candidate_id` and include `baseline_operation_id` / `candidate_operation_id` only when the corresponding independently reconstructed original exists. The full dictionary/list equality check remains unchanged: present IDs, candidate association, row count/order, costs, completion claim and extra fields remain exact. Explicit empty optional fields are not normalized away; they reject against the declared omission contract. No production serializer, model transition, schema, raw correspondence, historical/final continuation or debt rule changed.

Lasting tests use real captured CLI pairs via `OUTING_REPLACEMENT_FIXTURES`, whose directory contains unique `cli-replacement-accepted-*/pair` and `cli-replacement-refused-*/pair` children. `OptionalReplacementControls` invokes the isolated captured-source CLI against complete `*-captured.db` inputs, preserving all input byte hashes before/after. Modified exports are written only into new `OUTING_MUTATION_DIR` subdirectories; original Stores and reports remain unchanged.

## RED and GREEN

Evidence root: `/private/tmp/alan-delegated-task4-c86d844/fix-2`.

RED command, before correcting evidence.py:

```
OUTING_REPLACEMENT_FIXTURES=/private/tmp/alan-delegated-task5-3af5726/post-fix-development \
OUTING_MUTATION_DIR=/private/tmp/alan-delegated-task4-c86d844/fix-2/red \
  python3 -I -B examples/outing-planner/model/test_evidence.py \
  OptionalReplacementControls.test_actual_cli_optional_original_mapping
```

Exit1, one failed refused subtest: `AssertionError: 1 != 0`, with the exact invariant above. The actual accepted export passed in the same method. `red.log`, `red/optional-*/command.json` and `check.json` preserve exact subprocess argv/exits, input hashes, outputs and prior source-set identity `df188f8dc135b6a58a9c431045861e13ff76080a9aab1c00d21d1dd2b72f285c` (evidence.py `7619ce8a34c100498eefbc8b241a0a590c99f88bc03ce7dc6d42658ffeb45399`). The RED uses the actual production export, not a synthetic substitute.

The same command with `OUTING_MUTATION_DIR=.../fix-2/green` and test class `OptionalReplacementControls` passed both methods after the correction (`green.log`, exit0,4.769s). Two actual exports pass; eleven controls reject specifically at the unchanged original-mapping/cost invariant: invented candidate original, explicit empty candidate field, omitted existing baseline original, omitted existing delegated original, substituted genuine baseline ID, substituted genuine delegated ID, extra mapping row, reordered rows, unexpected mapping field, wrong baseline cost and wrong candidate cost.

## Final frozen verification

`fix-2/final/source/` captures check.py, run.py, evidence.py and both Python test files before final execution. `source-hashes.json` records:

- check.py unchanged: `4da5c4966b9c83776c4f6e47e3493da66231267ab68a53c5e7843387afb3807d`.
- evidence.py: `c2fa1074a547b2a3a03d0405dd523d7c1645a93f87f24aebb3484c0f7479067c`.
- run.py unchanged: `929c1d92d5769cc4d732462fac9cd45e34750628d100b2d12b6b51c30e44921b`.
- Complete source set: `01b6c8caa7e8c1681c828b3b0edfda62975b828edcf8989522c91cf85b52440b`.
- test_evidence.py: `e24d295bad3eed3790afe6f4cacb21ab783da3fda7cebf921da02a0e3e72af31`.
- test_model.py unchanged: `b6c5468a420c238ce2aef03ad5202c4eb5cad83d6717f73a6a24dc6368af73c7`.

Commands from repository root, all exit0:

```
python3 -I -B examples/outing-planner/model/test_model.py
python3 -I -B examples/outing-planner/model/test_evidence.py
OUTING_RAW_FIXTURE=/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawModel-two-1917707332 \
OUTING_RAW_PENDING_FIXTURE=/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawModel-unknown-3886699137 \
OUTING_RAW_CUTS=/private/tmp/alan-delegated-task4-c86d844/final/captures \
OUTING_REPLACEMENT_FIXTURES=/private/tmp/alan-delegated-task5-3af5726/post-fix-development \
OUTING_MUTATION_DIR=/private/tmp/alan-delegated-task4-c86d844/fix-2/final/controls \
  python3 -I -B examples/outing-planner/model/test_evidence.py
python3 -I -B /private/tmp/alan-delegated-task4-c86d844/fix-2/recheck-comparisons.py
```

- `final/model-tests.log`:24/24 passed,0.734s.
- `final/source-evidence-tests.log`:5 source-only methods passed,9 capture-dependent methods explicitly skipped;14 discovered,0.049s.
- `final/evidence-tests.log`:14/14 fixture-backed methods passed, no skips,9.231s. Existing raw semantic/report/pending and historical/final continuation controls remain active; the two new methods exercise the two genuine exports and eleven adverse export variants.
- `final/rechecks.log` / `rechecks-summary.json`:all11 existing direct/candidate comparisons passed, independently rechecking22 complete raw cuts spanning accepted, refused n0/n1/n2, diagnostic, unknown/pending and confirm-first cases. Classifications, original identities, exact costs, raw-cut hashes and debts remain unchanged. The recheck asserts the only mapping serialization difference is omission of keys formerly carrying absent-original empty strings, including the unknown case with both second-candidate originals absent. Every exact subprocess argv/exit and original input hash is preserved. These are rechecks of existing cuts, not fresh runtime/process qualification.
- `final/audit.json`:all five frozen files unchanged; all28 source-bound CLI outputs (13 optional controls,4 continuation controls,11 pair comparisons) carry the same fixed source-set/launcher identities.

No Go/race/full repository tests or finite enumeration were rerun for this serialization-only Python fix. The finite model and Go/harness bytes are unchanged; the existing enumeration remains historical evidence on its recorded source set. Task5 owns the fresh actual CLI and final full campaign after scoped review.

## Self-review and commit

Reviewed the complete two-file diff, retained at `fix-2/final/owned-review.diff`; whitespace validation passed. Confirmed expected optional fields are derived only from independently reconstructed raw originals, equality is not weakened, and all new controls preserve actual inputs. No Task5 documentation/tests, runtime/Go code, model transitions or unrelated file was edited or staged. Existing Task5 uncommitted files remain present. No unresolved concern remains from this narrowly scoped correction; independent review is still required.

Fix commit: `4af37867c030cb353df3b85686ff8bdc20fe6ec6` — `Match optional forecast identities in replacement exports`. Exactly the two owned files were staged and byte-checked against the frozen tested source hashes; cached diff whitespace validation passed. The index is clean after commit; only the pre-existing Task5 worktree changes remain. No amend, branch change or push. Status: DONE, awaiting independent scoped review.
