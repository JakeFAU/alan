import pathlib,json,subprocess,hashlib,sys
root=pathlib.Path('/private/tmp/alan-delegated-task4-c86d844/fix-2/final')
captures=pathlib.Path('/private/tmp/alan-delegated-task4-c86d844/final/captures')
log=[]
for previous_path in sorted(captures.glob('*/comparison.json')):
 directory=previous_path.parent;previous=json.loads(previous_path.read_bytes())
 output=root/'rechecks'/directory.name/'comparison.json';output.parent.mkdir(parents=True,exist_ok=True)
 paths={name:directory/filename for name,filename in [('baseline','baseline.db'),('candidate','candidate.db'),('configuration','derived-configuration.json'),('fixture','fixture.json'),('manifest','deployment-manifest.json')]}
 before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths.values()}
 command=[sys.executable,'-I','-B',str(pathlib.Path('examples/outing-planner/model/run.py').resolve()),'compare']
 for name,path in paths.items():command+=['--'+name,str(path)]
 command+=['--output',str(output)]
 run=subprocess.run(command,capture_output=True,text=True)
 checked=json.loads(output.read_bytes())
 assert run.returncode==0 and checked['accepted'],(command,run.stdout,run.stderr)
 assert checked['classification']==previous['classification']
 expected=previous['comparison']
 for mapping in expected['forecast_operations']:
  for optional in ('baseline_operation_id','candidate_operation_id'):
   if mapping.get(optional)=='':mapping.pop(optional)
 assert checked['comparison']==expected
 for role in ('baseline','candidate'):
  assert checked[role]['raw_cut_sha256']==previous[role]['raw_cut_sha256']
  assert checked[role]['debts']==previous[role]['debts']
 assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths.values()}==before
 log.append({'command':command,'exit':run.returncode,'classification':checked['classification'],'source_files':checked['execution']['source_files'],'source_set_sha256':checked['execution']['source_set_sha256'],'original_input_sha256':before})
(root/'rechecks-summary.json').write_text(json.dumps(log,indent=2)+'\n')
print('11 existing pair comparisons passed; 22 raw Stores checked; only absent optional ID fields differ.')
