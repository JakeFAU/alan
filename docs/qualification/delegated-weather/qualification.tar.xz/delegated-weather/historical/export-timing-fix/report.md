# Task 2 export follow-up report

DONE. Implementation commit `3e873c053832629e495790fbdb6ab2ce3e30c7b2` (`Export the final delegated replacement cut`) is based on `3af5726d38b0685f37314f00aad7ca39ae7064db`. Only `examples/outing-planner/replacement.go` and `examples/outing-planner/delegated_replacement_test.go` are committed. Task5 files remain uncommitted and untouched. No branch change or push was performed.

## Failure and implementation

The original replacement command constructs its report and private cost roots after the first execution, then acquires a second owner to validate recovery. A refused delegated helper leaves Outing open, so that second owner increments Outing's epoch from 2 to 3. The saved report still described epoch 2. RED reproduced for each n=0,1,2 refusal with `exported outing epoch 2 differs from final Store epoch 3`, followed by full report inequality.

After successful `validateReplacementReopen`, only delegated candidates now adopt the complete validated reopened report and roots. The original execution's progress pointer is retained; the separate zero-work reopened witness remains unchanged. The outcome is already checked equal by reopen validation. Original operation IDs, evidence, costs and refusal behavior stay covered by the existing table assertions. Bound exhaustion still returns before reopen, with the actual underlying planner outcome and execution progress.

Regression assertions read the actual persisted `replacement.json`, compare it byte-for-byte with command output, then compare each baseline and candidate's full serialized report and actual run epochs against a fresh read-only final Store inspection. They also compare reopened witness run states and ensure the inspection leaves Store bytes unchanged. Accepted, unavailable and refused n=0,1,2 controls share this comparison. The bound-exhaustion control separately checks its final Store cut and absence of reopen.

Legacy candidates do not enter the new production branch. Existing exact cycle digest `692358c9b8224a8e92c8bf5c3dae33b6d190b3687df75a053c98a0ee7f72e728`, zero forecast contacts, unchanged witness equality and omission of delegated fields/manifest pass. No legacy witness hashes were changed. No runtime, checker, protocol, format, program artifact or normalization source was changed.

## Verification

Evidence directory: `/private/tmp/alan-delegated-export-followup-3af5726`. Each run's `.json` records exact argv, cwd, source HEAD/status, all Go source SHA-256 identities, elapsed time and exit code; corresponding `.log` retains complete output.

- `red-final-cut`: initial restricted test attempt could not open the shared Go build cache; exit 1 before behavioral execution. Preserved separately.
- `red-final-cut-loopback`: `go test -count=1 -parallel=4 -run '^TestDelegatedReplacementRetainsEvidence$/refused' -v ./examples/outing-planner`; exit 1 as expected. All three refusal rows showed epoch 2 versus final Store epoch 3.
- `green-focused`: first implementation GREEN; focused replacement set exited 0 before the final test-only addition to read persisted JSON explicitly.
- `final-focused`: `go test -count=1 -parallel=4 -run '^(TestDelegatedReplacement|TestPlannerCLIReplacement)' -v ./examples/outing-planner`; exit 0, package 15.080s (wall 15.689s).
- `final-focused-race`: `go test -race -count=1 -parallel=4 -run '^(TestDelegatedReplacement|TestPlannerCLIReplacement)' -v ./examples/outing-planner`; exit 0, package 227.394s (wall 229.220s). Includes exact `TestDelegatedReplacementPreservesExactLegacyCycleWitness` and legacy inspect/replay/persistence controls.
- Both final runs used identical Go source hashes; those hashes also match the final committed source. No tests remain active.
- `gofmt -l` for both owned files produced no output; `git diff --check` and `git diff --cached --check` passed. Full owned and staged diffs were inspected before committing. `owned.diff` and `commit.diff` retain the complete change.
- `scope-check.json` records zero unrelated tracked-file changes since initial handoff and zero unrelated Go-file changes since RED. `commit.json` records the exact two committed paths and source hashes. `final-status.txt` retains the remaining Task5 worktree changes.

## Limits

This is application export timing for the fixed bounded example. No broad repository checks were run while Task5 was paused, as instructed. No static-analysis or standalone build claim is made. Root still owns independent review; Task5 must rerun actual CLI refused/accepted raw comparisons from a new final source freeze. This follow-up does not claim raw checker campaign completion, general substitution, unrestricted runtime correspondence or broader runtime correctness.
