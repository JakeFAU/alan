import hashlib, json, pathlib, subprocess, sys, time
base=pathlib.Path('/private/tmp/alan-delegated-export-followup-3af5726')
name=sys.argv[1]
argv=sys.argv[2:]
meta={'argv':argv,'cwd':str(pathlib.Path.cwd()),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--short'],text=True),'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path('.').rglob('*.go') if '.git' not in p.parts},'started':time.time()}
(base/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
with (base/(name+'.log')).open('w') as out:
    result=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT)
meta.update(exit_code=result.returncode,elapsed_seconds=time.time()-meta['started'])
(base/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'name':name,'exit_code':result.returncode,'elapsed_seconds':meta['elapsed_seconds']}))
print((base/(name+'.log')).read_text())
sys.exit(result.returncode)
