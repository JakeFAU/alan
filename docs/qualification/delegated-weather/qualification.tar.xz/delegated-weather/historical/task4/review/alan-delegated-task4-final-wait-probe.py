import pathlib,sqlite3,json,hashlib,subprocess,sys
base=pathlib.Path('/private/tmp/alan-delegated-task4-c86d844/final')
fixture=base/'captures/TestDelegatedRawCuts-decision-1229043195'
source=fixture/'cut.db'
out=pathlib.Path('/private/tmp/alan-delegated-task4-final-wait-probe')
out.mkdir(exist_ok=True)
target=out/'mutation.db'
assert not target.exists()
original_hash=hashlib.sha256(source.read_bytes()).hexdigest()
model_source=base/'source/examples/outing-planner/model'
m={'__name__':'review_model'}
exec(compile((model_source/'check.py').read_bytes(),'check.py','exec'),m)
e={'__name__':'review_evidence','MODEL':m}
exec(compile((model_source/'evidence.py').read_bytes(),'evidence.py','exec'),e)
with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as s, sqlite3.connect(str(target)) as d:
 s.backup(d)
 seq,raw=d.execute("SELECT sequence,projection FROM runs WHERE subject='weather'").fetchone()
 projection=json.loads(raw)
 before_pc=projection['PC'];projection['PC']=4
 d.execute("UPDATE runs SET projection=? WHERE subject='weather'",(e['go_json'](projection),))
 d.execute("UPDATE history SET successor=? WHERE subject='weather' AND sequence=?",(e['go_json'](projection),seq))
 row=d.execute("SELECT epoch,source_revision,selected_observation,successor,intents FROM history WHERE subject='weather' AND sequence=?",(seq,)).fetchone()
 history={'Run':e['run_id']('weather'),'Sequence':seq,'Epoch':row[0],'Revision':row[1],'Selected':row[2] or '', 'Successor':json.loads(row[3]),'Intents':json.loads(row[4])}
 for order,raw in d.execute("SELECT decision_order,descriptor FROM composition_facts WHERE kind='execution'").fetchall():
  fact=json.loads(raw)
  if fact['Run']['Subject']=='weather' and fact['Sequence']==seq:
   fact['RecordDigest']=e['identity']('alan/history-row/v1',history)
   d.execute('UPDATE composition_facts SET descriptor=? WHERE decision_order=?',(e['go_json'](fact),order))
 d.commit()
command=[sys.executable,'-I','-B',str(model_source/'run.py'),'check','--store',str(target),'--configuration',str(fixture/'derived-configuration.json'),'--fixture',str(fixture/'fixture.json'),'--manifest',str(fixture/'deployment-manifest.json'),'--output',str(out/'check.json')]
run=subprocess.run(command,capture_output=True,text=True)
result=json.loads((out/'check.json').read_bytes())
summary={'command':command,'exit':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'original_unchanged':original_hash==hashlib.sha256(source.read_bytes()).hexdigest(),'original_sha256':original_hash,'weather_pc_before':before_pc,'weather_pc_after':4,'actual_wait':'outing-proposal','accepted':result.get('accepted'),'classification':result.get('classification'),'symbolic_weather':result.get('state',{}).get('weather'),'debts':result.get('debts'),'decision_commit_cut':result.get('decision_commit_cut')}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
