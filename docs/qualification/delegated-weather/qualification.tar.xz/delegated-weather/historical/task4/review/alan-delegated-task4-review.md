Spec compliance: REJECT.
Code quality: REJECT.

Scope: Task 4 only, base c86d84411697c59a502c09a0d052af67d089360a through head 320cafd2bf113e0ff812b47d68fe846ec42c358a. Reviewed the supplied nine-file diff in contiguous bounded segments. No checkout, index, HEAD, branch, research, original capture, or source-file mutations; no subagents; no repeated test suite or campaign. This is not whole-branch approval.

## Strengths

- `examples/outing-planner/model/run.py:10` captures the exact declared two-source input, checks exact source/path keys, hashes immutable buffers, and compiles them into fresh namespaces with explicit model injection. The named source-set hash preserves `source_sha256` as the model hash. The added launcher controls cover both pathname replacements, missing/extra source inputs, and absent on-disk reader.
- `examples/outing-planner/model/evidence.py:104` reads schema and rows in one read-only transaction, checks exact schema9 objects/DDL/keys/indexes and foreign keys, and inventories all 42 tables with typed row digests. `evidence.py:265` checks the selected deployment's entire raw artifact inventory, including its inert helper prototype. These are substantially stronger boundaries than application-report validation alone.
- `examples/outing-planner/model/evidence.py:458` checks authorization Source.Sequence against the actual retained global fact prefix and separately checks original identity, epoch, disposition and the bound-reply exception. `evidence.py:748` reconstructs terminal freezes and atomic publication/result-copy/outcome delivery, and `evidence.py:815` binds the complete source facts back to retained rows.
- `examples/outing-planner/model/evidence.py:853` consumes every reconstructed observable through the independent model under retained partial-order constraints; it does not invent cross-run numerical chronology. Raw reply acknowledgment debt remains separate from public pending diagnostics. Missing results and gate passage are accurately qualified as epistemic uncertainty and dispatch evidence, respectively.
- `examples/outing-planner/model/test_evidence.py:114` contains substantive same-answer semantic controls. The archived mutation diagnostics show all fourteen intended invariants, including original-owner/request/response, same-shaped candidate/handle, inert program, hidden operation/charge/child, premature assessment, duplicate observation/reply, removed result and cross-run authorization controls. They do not all stop at parser failures.
- `examples/outing-planner/model/test_evidence.py:276` captures a consistent source transaction by backup and checks destination logical equality; it changes journal mode only on the new destination. The report distinguishes source-only skips, fixture-backed executions and the synthetic optional export accurately.

## Important finding

### [P1] Final concrete receive/control state and debt are not related to the matched model state

Location: `examples/outing-planner/model/evidence.py:894`–`896`; related `evidence.py:311`, `evidence.py:924`, `evidence.py:948`, `evidence.py:1130`.

After consuming the event inventory, `correspondence()` compares each concrete projection only as open/succeeded/failed. Every nonterminal symbolic control position collapses to `open`. It never checks that the retained receive/control state and its original correlation agree with the matched symbolic position or symbolic debts. `public_wait()` can recover that concrete receive, but its result is not compared with the model. `public_pending()` is used for an optional report comparison, which compares the report to raw records rather than raw pending state to the model. Consequently, a valid model path for past events can be accepted despite a contradictory final retained continuation.

This violates the explicit requirement at `docs/superpowers/specs/2026-11-17-delegated-weather-design.md:168` that final abstract state and pending debts match the full cut. It is not a request for an independent compiler or general instruction-by-instruction proof: the missing relation is the declared protocol's current receive obligation/control position, already available from the pinned artifact and raw projection.

Focused falsification on the exact archived bytes:

- Original: `/private/tmp/alan-delegated-task4-c86d844/final/captures/TestDelegatedRawCuts-decision-1229043195/cut.db`.
- Copied the original into `/private/tmp/alan-delegated-task4-final-wait-probe/mutation.db`; changed Weather's final PC from 36 (receive `outing-decision`) to 4 (receive `outing-proposal`). Updated only the matching last history successor and that execution fact's digest, preserving all original operations, selections, charges, schema, frozen inputs and program artifacts. The unkeyed digest was updated specifically to isolate the missing semantic check rather than stop at a stale-hash check.
- Ran the archived source-bound CLI once without an optional report. Exit 0, `accepted: true`, classification `pending`, symbolic Weather `await_decision`, and debt `weather:decision_receive`, although the retained Weather continuation awaits a proposal whose original observation has already been consumed. The returned `decision_commit_cut.verified` is correctly false; that narrower safeguard does not repair acceptance of the contradictory general correspondence state.
- Original SHA-256 remained `d289dce43ad2326c365528881790ef40752967263856f7ebe60806c363fd8b7d`. No independently frozen input or artifact was changed. This is a checker semantic mutation control, not a claim that hashes authenticate hostile database rewrites or that the real runtime produced this corruption.

Reproduction script: `/private/tmp/alan-delegated-task4-final-wait-probe.py` (expects a fresh output directory). Exact CLI command, exit, output, original-hash check and summary: `/private/tmp/alan-delegated-task4-final-wait-probe/summary.json`. Full accepted result: `/private/tmp/alan-delegated-task4-final-wait-probe/check.json`.

Required correction: define/check the concrete-to-model final continuation/debt relation, including exact receive kind, source, generation, obligation and original correlation at receive boundaries. Account explicitly for intermediate pure positions rather than treating every open projection as interchangeable. Add a semantic rejection control for a same-shaped wrong retained wait/correlation with otherwise consistent history/fact bookkeeping. This must run for raw checks without an application report. Review the analogous historical receive matching boundary at `evidence.py:311`, which currently checks only that a selection occurred at an opcode named `receive`; I did not run a second mutation to establish a distinct historical-selection finding.

## Critical / minor findings

No Critical finding. No separate Minor blocker or speculative quality objection. The large reader has cohesive raw-evidence responsibility; the approved two-source split itself is sound and does not need reversal.

## Verification and named outside checks

1. **Risk: archived results may describe different source bytes or incomplete captures.** Read the final source hash manifest, capture audit, model/source-evidence/mutation logs, Go harness log tail, empty Staticcheck log, optional-export command records and all fourteen saved mutation diagnostics. Independently hashed all nine archived changed files and current counterparts, checked all 83 captured destination hashes, and enumerated all 83 checker inventories. Confirmed 42 tables per cut, explicit rule on every row, 17,051 covered rows counted per cut, and one source-set hash `f050f3c9bc3e3f848d65a3be57c0a497d33c4185df2e9c4d17f1b3c52a5b7ba8`. Classes: 28 complete, 41 pending, 9 refused, 2 diagnostic_terminal, 2 unknown_forecast, 1 confirm_first_cycle. This was an archive/hash audit, not a rerun of semantic qualification.
2. **Risk: the reported RED controls may be only missing-API failures.** Read preserved `reply-candidate-red.log` and `report-red.log`: one semantic candidate failure and two report subtest failures show `InvariantError not raised`. The report correctly distinguishes the separate API-absence RED.
3. **Risk: final abstract state may ignore the retained receive.** Inspected only the named decision-cut raw projection and its pinned program's receive instructions, then ran the single focused copied-cut probe above against the archived sources. No production source crawl or Go verifier was used.
4. **Scope/trust interpretation.** Read the task brief, reviewer prompt, research AGENTS and read-only known-weaknesses reference, and the governing evidence-input/final-state/trust-boundary clauses. A portion of the first large diff output clipped a documentation sentence; the governing clause was retrieved in the targeted contract check. Executable diff segments were read in full. No research file was modified and `.envrc` was never read.

## Remaining qualification boundaries

- Archived logs support 24 model tests passing; source-only evidence discovery ran four tests and skipped five fixture-dependent methods; the final fixture-backed run executed all nine methods with no skips. No suite was rerun for this review.
- The real CLI source-bound walkthrough, process kill/reopen, endpoint acknowledgment and final campaign/source attribution remain Task 5 work. The optional replacement export is transparently synthetic from real reports, not a CLI-produced replacement artifact.
- Calendar normalization, canonical manifest authority, capture/source integrity, launcher/interpreter/standard library and general compiler/bytecode semantics remain trusted or excluded as declared. These limits do not eliminate the missing concrete final protocol-state relation above.
- Whole-repository and whole-branch gates are not granted here. Correct the Important finding, preserve its witness, and obtain task re-review before treating Task 4 as approved.
