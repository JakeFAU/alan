"""Verify the frozen bundle and re-execute its independent checks in fresh output."""
import argparse, collections, hashlib, json, os, pathlib, subprocess, sys, tempfile

def fresh_output(bundle, requested):
    bundle=bundle.resolve()
    if requested is None:
        directory=pathlib.Path(tempfile.gettempdir()).resolve()
        if directory.is_relative_to(bundle):
            raise ValueError('temporary output directory must be outside bundle')
        return pathlib.Path(tempfile.mkdtemp(prefix='delegated-reproduction-',dir=str(directory))).resolve()
    output=requested.expanduser().resolve()
    if output.is_relative_to(bundle):
        raise ValueError('output must be outside the archived input tree')
    # Exclusive creation rejects existing directories/files and never overwrites.
    output.mkdir(mode=0o700)
    return output

parser=argparse.ArgumentParser()
parser.add_argument('--output',type=pathlib.Path)
args=parser.parse_args()
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_bytes())
for name,want in manifest['files'].items():
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=want:
        raise SystemExit('bundle hash mismatch: '+name)
for name,want in json.loads((root/'source-hashes.json').read_bytes()).items():
    assert hashlib.sha256((root/'source'/name).read_bytes()).hexdigest()==want,('frozen source map',name)
try:
    out=fresh_output(root,args.output)
except (ValueError,OSError) as error:
    parser.error(str(error))
summary={'verified_files':len(manifest['files']),'jobs':[], 'counts':{}}
for index,job in enumerate(manifest['jobs']):
    command=[sys.executable,'-I','-B',str(root/job['launcher']),job['action']]
    for key,value in job['inputs'].items():
        command.extend([key,str(root/value)])
    result=out/('%04d.json'%index)
    command.extend(['--output',str(result)])
    p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    got=json.loads(result.read_bytes())
    expected=job['expected']
    assert p.returncode==(0 if expected['accepted'] else 1),(job['evidence'],p.returncode,p.stderr.decode())
    assert got['accepted']==expected['accepted'],job['evidence']
    assert got['execution']['source_set_sha256']==job['source_set_sha256'],job['evidence']
    for key in ('raw_cut_sha256','classification','successful_replacement'):
        if key in expected: assert got[key]==expected[key],(job['evidence'],key)
    if 'invariant' in expected: assert got['invariant'].split(':')[0]==expected['invariant'].split(':')[0],job['evidence']
    if index and index%50==0: print('Reproduced independent jobs',index,flush=True)
    summary['jobs'].append({'category':job['category'],'evidence':job['evidence'],'argv':command,'exit':p.returncode,'accepted':got['accepted'],'invariant':got.get('invariant')})
source=root/'source/examples/outing-planner/model'
commands=[('model-tests',[sys.executable,'-I','-B',str(source/'test_model.py')],{}),
 ('fixture-evidence-tests',[sys.executable,'-I','-B',str(source/'test_evidence.py')],{
  'OUTING_RAW_FIXTURE':str(root/manifest['fixture_tests']['complete']),
  'OUTING_RAW_PENDING_FIXTURE':str(root/manifest['fixture_tests']['unknown']),
  'OUTING_RAW_CUTS':str(root/'campaign/normal'),
  'OUTING_REPLACEMENT_FIXTURES':str(root/'campaign/normal'),
  'OUTING_MUTATION_DIR':str(out/'mutations')}),
 ('enumeration',[sys.executable,'-I','-B',str(source/'run.py'),'enumerate','--output',str(out/'enumeration.json')],{})]
for name,command,extra in commands:
    environment=dict(os.environ,**extra)
    for key in ('OUTING_RAW_FIXTURE','OUTING_RAW_PENDING_FIXTURE','OUTING_RAW_CUTS','OUTING_MUTATION_DIR','OUTING_REPLACEMENT_FIXTURES'):
        if key not in extra: environment.pop(key,None)
    p=subprocess.run(command,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (out/(name+'.log')).write_bytes(p.stdout)
    assert p.returncode==0,(name,p.stdout.decode())
    summary[name]={'argv':command,'environment':extra,'exit':p.returncode}
for name,want in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==want,('archive input changed during reproduction',name)
summary['counts']=dict(collections.Counter(j['category']+('/accepted' if j['accepted'] else '/rejected') for j in summary['jobs']))
(out/'reproduction-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'output':str(out),'verified_files':summary['verified_files'],'jobs':len(summary['jobs']),'results':summary['counts']}))
