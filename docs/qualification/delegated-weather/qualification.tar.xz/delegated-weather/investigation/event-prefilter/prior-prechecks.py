"""Sequential independent campaigns and compatibility gates before full Go checks."""
import pathlib,subprocess,os,sys
root=pathlib.Path('/private/tmp/alan-delegated-task5-3af5726')
final=root/'final-after-export-fix';captures=final/'captures'
complete=next(captures.glob('TestDelegatedRawModel-two-*'))
unknown=next(captures.glob('TestDelegatedRawModel-unknown-*'))
commands=[
 ('qualified-model-tests',['python3','-I','-B','examples/outing-planner/model/test_model.py'],{}),
 ('qualified-source-evidence-tests',['python3','-I','-B','examples/outing-planner/model/test_evidence.py'],{}),
 ('qualified-enumeration',['python3','-I','-B','examples/outing-planner/model/run.py','enumerate','--output',str(final/'enumeration.json')],{}),
 ('qualified-fixture-evidence-tests',['python3','-I','-B','examples/outing-planner/model/test_evidence.py'],{
 'OUTING_RAW_FIXTURE':str(complete),'OUTING_RAW_PENDING_FIXTURE':str(unknown),'OUTING_RAW_CUTS':str(captures),'OUTING_REPLACEMENT_FIXTURES':str(captures),'OUTING_MUTATION_DIR':str(final/'mutations')}),
 ('qualified-legacy',['/private/tmp/alan-author-validation-fdac2f8/check-compatibility',str(final/'legacy-copies')],{}),
 ('qualified-format',['gofmt','-l','examples/outing-planner/barrier_process_test.go','examples/outing-planner/delegated_model_test.go','examples/outing-planner/process_test.go','examples/outing-planner/delegated_process_test.go','examples/outing-planner/delegated_qualification_test.go'],{}),
]
for name,argv,extra in commands:
 environment=dict(os.environ,**extra)
 for key in ('ALAN_RAW_CAPTURE_DIR','OUTING_RAW_FIXTURE','OUTING_RAW_PENDING_FIXTURE','OUTING_RAW_CUTS','OUTING_REPLACEMENT_FIXTURES','OUTING_MUTATION_DIR'):
  if key not in extra:environment.pop(key,None)
 code=subprocess.call([sys.executable,str(root/'run-command.py'),name]+argv,env=environment)
 if code:sys.exit(code)
 if name=='qualified-format' and (root/(name+'.log')).read_bytes():raise SystemExit('gofmt listed unformatted source')
print('Independent Python campaigns, fixture controls, legacy copies and formatting passed.',flush=True)
