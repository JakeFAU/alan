"""Run each final repository gate once, sequentially; stop on any failure."""
import subprocess,sys,os,pathlib,json
root=pathlib.Path('/private/tmp/alan-delegated-task5-3af5726')
commands=[
 ('qualified-mod-verify',['go','mod','verify']),
 ('qualified-mod-tidy',['go','mod','tidy','-diff']),
 ('qualified-build',['go','build','./...']),
 ('qualified-staticcheck',['staticcheck','./...']),
 ('qualified-staticcheck-integration',['staticcheck','-tags','integration','./...']),
 ('qualified-tests',['go','test','-count=1','-timeout=60m','./...']),
 ('qualified-integration-tests',['go','test','-count=1','-timeout=60m','-tags','integration','./...']),
 ('qualified-race-integration-tests',['go','test','-v','-count=1','-timeout=60m','-race','-tags','integration','./...']),
]
for name,argv in commands:
 environment=dict(os.environ)
 environment.pop('ALAN_RAW_CAPTURE_DIR',None)
 if name=='qualified-race-integration-tests':environment['ALAN_RAW_CAPTURE_DIR']=str(root/'final-after-export-fix/race-captures')
 code=subprocess.call([sys.executable,str(root/'run-command.py'),name]+argv,env=environment)
 if code:sys.exit(code)
print('All required final repository gates passed; verbose full race run includes focused process/CLI coverage.',flush=True)
