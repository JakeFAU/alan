from pathlib import Path
import hashlib,json,socket
root=Path('/private/tmp/alan-delegated-task5-3af5726/event-prefilter-investigation')
path=Path('examples/outing-planner/delegated_model_test.go').resolve()
original=path.read_text();(root/'original.go.txt').write_text(original)
with socket.socket() as listener:
 listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
common=original.replace('"testing"','"testing"\n "sync/atomic"\n "time"\n "net"')
common=common.replace('server := httptest.NewServer(', 'server := httptest.NewUnstartedServer(')
needle='\tt.Cleanup(server.Close)'
common=common.replace(needle,'''    if err:=server.Listener.Close();err!=nil{t.Fatal(err)}
    listener,err:=net.Listen("tcp","127.0.0.1:PORT")
    if err!=nil{t.Fatal(err)}
    server.Listener=listener
    server.Start()
'''.replace('PORT',str(port))+needle)
old='''\towner, err := runtime.Create(t.Context(), path, f.provisions[index], runtime.DefaultLimits())
\tif err != nil {
\t\tt.Fatal(err)
\t}'''
new='''    seed:="SEED"
    if _,err:=os.Stat(seed);os.IsNotExist(err){
        initial,err:=runtime.Create(t.Context(),path,f.provisions[index],runtime.DefaultLimits());if err!=nil{t.Fatal(err)}
        if err:=initial.Close();err!=nil{t.Fatal(err)}
        if info,err:=os.Stat(path+"-wal");err==nil && info.Size()!=0{t.Fatal("closed diagnostic seed still has WAL frames")}
        raw,err:=os.ReadFile(path);if err!=nil{t.Fatal(err)}
        output,err:=os.OpenFile(seed,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if err!=nil{t.Fatal(err)}
        if _,err:=output.Write(raw);err!=nil{t.Fatal(err)};if err:=output.Close();err!=nil{t.Fatal(err)}
    }else if err!=nil{t.Fatal(err)}
    raw,err:=os.ReadFile(seed);if err!=nil{t.Fatal(err)}
    if err:=os.WriteFile(path,raw,0600);err!=nil{t.Fatal(err)}
    owner,err:=runtime.Open(t.Context(),path,runtime.DefaultLimits());if err!=nil{t.Fatal(err)}'''.replace('SEED',str(root/'initial-seed.db'))
assert old in common;common=common.replace(old,new)
needle='''\tobserved := boundary.WithObserver(t.Context(), func(ctx context.Context, event boundary.Event) error {
\t\tcut, err := runtime.InspectExecution'''
common=common.replace(needle,'''    var inspected,events atomic.Int64
    started:=time.Now()
    defer func(){t.Logf("DIAGNOSTIC observer_events=%d full_inspections=%d discovery_elapsed=%s",events.Load(),inspected.Load(),time.Since(started))}()
    observed := boundary.WithObserver(t.Context(), func(ctx context.Context, event boundary.Event) error {
        events.Add(1)
        FILTER
        inspected.Add(1)
        cut, err := runtime.InspectExecution''')
prefilter='''// Diagnostic candidate: identical final coarse filter, before full inspection.
        switch event.Boundary {
        case "execution.committed":
            if event.Intent=="" && event.Phase!="terminal"{return nil}
        case "execution.staged":
            if event.Subject!=weatherSubject{return nil}
        case "invocation.admitted","invocation.result-recorded","adapter.result-recorded","adapter.settled","intent.authorized":
        default:return nil
        }'''
identities={'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'fixed_fixture_address':'127.0.0.1:'+str(port),'method':'temporary Go overlays only; count full-inspection callsite; identical generated two-candidate fixture and configuration; clone safely closed initial seed then ordinary Open gives identical namespace/epoch; no other heavy jobs'}
for label,filter_source in [('before',''),('after',prefilter)]:
 code=common.replace('FILTER',filter_source)
 target=root/(label+'.go');target.write_text(code)
 overlay=root/(label+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(path):str(target)}},indent=2)+'\n')
 identities[label]={'source':str(target),'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'overlay':str(overlay),'overlay_sha256':hashlib.sha256(overlay.read_bytes()).hexdigest()}
(root/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
print(json.dumps(identities,indent=2))
