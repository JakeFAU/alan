"""Controlled, deterministic archive builder; excludes live Stores and binaries."""
from pathlib import Path
import json,hashlib,shutil,tarfile,lzma,io,collections,subprocess
E=Path('/private/tmp/alan-delegated-task5-3af5726')
F=E/'final-after-event-filter'
R=E/'package'
if R.exists(): shutil.rmtree(R)
R.mkdir()
pathmap={}
def copy(p,name):
 p=Path(p)
 if not p.is_file():return
 d=R/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 pathmap[str(p.resolve())]=str(name)
def tree(src,dest,predicate=lambda p:True):
 src=Path(src)
 if not src.exists():return
 for p in sorted(src.rglob('*')):
  if p.is_file() and predicate(p):copy(p,Path(dest)/p.relative_to(src))
def safe(p):
 if p.name in ('baseline.db','candidate.db') and any(part.startswith('cli-replacement-') for part in p.parts):return False
 if p.suffix=='.db':
  if '-live' in p.name:return False
  # Failed/interrupted temporary destinations without capture certification are
  # scratch. Explicit copied-Store mutation.db witnesses remain negative data.
  return p.name=='mutation.db' or Path(str(p)+'.capture.json').is_file()
 return p.suffix in ('.json','.py','.md','.log','.txt','.diff','.sh')
# Source snapshot was frozen before execution, with byte identity audited again.
tree(F/'source','source')
copy(F/'source-hashes.json',Path('source-hashes.json'))
# Every committed raw DB here is a self-contained consistent backup, or an
# explicitly labeled copied-Store semantic mutation. Never include live DBs.
tree(F/'captures','campaign/normal',safe)
tree(E/'final/captures','superseded/task5/captures',safe)
tree(E/'final/source','superseded/task5/source')
tree(E/'final-after-export-fix/source','superseded/full-race-timeout/source')
tree(E/'final-after-export-fix/captures','superseded/full-race-timeout/normal-captures',safe)
tree(E/'final-after-export-fix/race-captures','superseded/full-race-timeout/race-captures',safe)
copy(E/'full-race-timeout.json',Path('superseded/full-race-timeout/status.json'))
tree(E/'archive-inputs','archive-inputs',lambda p:safe(p) or p.name.startswith('diagnostic-original-seed.db'))
tree(E/'event-prefilter-investigation','investigation/event-prefilter',lambda p:safe(p) or p.suffix=='.go')
copy(E/'superseded-campaign.json',Path('superseded/task5/status.json'))
tree(F/'race-captures','campaign/race',safe)
tree(E/'final/race-captures','superseded/task5/interrupted-race-captures',safe)
tree(F/'mutations','campaign/mutations',safe)
tree(F/'walkthrough','campaign/walkthrough',lambda p:safe(p) and (p.suffix!='.db' or p.name.endswith('-captured.db')))
for p in sorted(E.glob('*.command.json')):copy(p,Path('commands')/p.name)
for p in sorted(E.glob('*.log')):
 if p.with_suffix('.command.json').is_file():copy(p,Path('commands')/p.name)
copy(E/'run-command.py',Path('commands/run-command.py'))
copy(E/'final-checks.py',Path('commands/final-checks.py'))
copy(E/'prechecks.py',Path('commands/prechecks.py'))
copy(E/'write-final-qualification.py',Path('commands/write-final-qualification.py'))
copy(E/'audit-captures.py',Path('commands/audit-captures.py'))
copy(E/'test-reproducer-guards.py',Path('commands/test-reproducer-guards.py'))
copy(E/'build-archive.py',Path('commands/build-archive.py'))
copy(E/'repack.py',Path('commands/repack.py'))
copy(E/'closed-cli-probe.json',Path('probe/closed-cli-probe.json'))
copy(E/'closed-cli-inspect.json',Path('probe/closed-cli-inspect.json'))
probe=E/'development-captures/cli-replacement-1766877050/pair'
for name in ('baseline.db','baseline.db-wal','baseline.db-shm','original-sha.json','probe-captured.db','probe-captured.db.capture.json','replacement.json'):
 copy(probe/name,Path('probe')/name)
# The stale refusal export remains an expected semantic cross-check rejection.
tree(E/'final/walkthrough','campaign/walkthrough-before-correction',lambda p:safe(p) and (p.suffix!='.db' or p.name.endswith('-captured.db')))
copy(E/'refusal-export-timing.json',Path('campaign/refusal-export-timing.json'))
fix=E/'export-fix-evidence'
tree(fix,'historical/export-fix',safe)
tree('/private/tmp/alan-delegated-task4-c86d844/fix-2','historical/checker-export-fix',safe)
copy('/private/tmp/alan-delegated-task4-rereview2.md',Path('historical/checker-export-fix/review.md'))
tree('/private/tmp/alan-delegated-export-followup-3af5726','historical/export-timing-fix',safe)
copy('/private/tmp/alan-delegated-export-review.md',Path('historical/export-timing-fix/review.md'))
tree(E/'post-fix-development','historical/optional-export-RED',safe)
copy(E/'second-export-red.json',Path('historical/optional-export-RED/status.json'))
copy('/private/tmp/alan-delegated-decisions.md',Path('DECISIONS.md'))
# Preserve initial REJECT and corrected independent APPROVE, the exact original
# reviewer witness and pre-fix source bytes, plus four retained semantic REDs.
T4=Path('/private/tmp/alan-delegated-task4-c86d844')
tree(T4/'final/source','historical/task4/source-before-fix')
tree(T4/'fix-1/final/source','historical/task4/source-after-continuation-fix')
tree(T4/'final/captures','historical/task4/old-captures',lambda p:safe(p) and ('-live' not in p.name))
tree(T4/'fix-1/final/rechecks','historical/task4/rechecks',safe)
tree(T4/'fix-1/red-mutations','historical/task4/red-mutations',safe)
for f in ('continuation-red.log','continuation-green.log','continuation_methods.txt'):
 copy(T4/'fix-1'/f,Path('historical/task4')/f)
for f in ('reviewer-witness-check.json','reviewer-witness-recheck.json','audit.json','source-hashes.json'):
 copy(T4/'fix-1/final'/f,Path('historical/task4/fix1')/f)
for f in ('reader-red.log','reply-candidate-red.log','report-red.log'):
 copy(T4/f,Path('historical/task4')/f)
for f in ('alan-delegated-task4-review.md','alan-delegated-task4-rereview1.md','alan-delegated-task4-final-wait-probe.py'):
 copy(Path('/private/tmp')/f,Path('historical/task4/review')/f)
tree('/private/tmp/alan-delegated-task4-final-wait-probe','historical/task4/review/original-probe',safe)
T3=Path('/private/tmp/alan-delegated-task3-aecd734')
tree(T3/'source','historical/task3/source')
for f in ('red-controls.log','enumeration.json','summary.json','unit-final.log'):
 copy(T3/f,Path('historical/task3')/f)
for n in (1,2,3,4):
 p=Path('.superpowers/sdd/2026-11-17-delegated-weather')/('task-%d-report.md'%n)
 copy(p,Path('historical/reports')/p.name)
# Three pre-port legacy inputs, canonical bytes, expected reports and the exact
# compatibility script; no historical executables enter the archive.
pre=Path('/private/tmp/alan-author-validation-fdac2f8/pre')
original_hashes=json.loads((E/'archive-inputs/original-main-hashes.json').read_bytes())
for name in ('recommended','no-match','check-confirm-first/candidate'):
 original=pre/(name+'.db')
 assert hashlib.sha256(original.read_bytes()).hexdigest()==original_hashes[str(original)]
 wal=Path(str(original)+'-wal')
 assert not wal.exists() or wal.stat().st_size==0,('legacy original is not safely checkpointed',str(original))
 copy(original,Path('legacy/pre')/(name+'.db'))
 for suffix in ('-wal','-shm'):
  sidecar=Path(str(original)+suffix)
  if sidecar.exists():copy(sidecar,Path('legacy/pre')/(name+'.db'+suffix))
for n in ('recommended','no-match'):
 for p in pre.glob(n+'*'):
  if p.is_file() and (safe(p) or p.name.endswith(('.db-wal','.db-shm'))):copy(p,Path('legacy/pre')/p.name)
for f in ('candidate.db','derived-configuration.json'):
 copy(pre/'check-confirm-first'/f,Path('legacy/pre/check-confirm-first')/f)
for p in pre.glob('blocked-*.json'):copy(p,Path('legacy/pre')/p.name)
copy('/private/tmp/alan-author-validation-fdac2f8/check-compatibility',Path('legacy/check-compatibility-original'))
tree(F/'legacy-copies','legacy/current-results',lambda p:safe(p) and p.suffix!='.db')
copy(F/'enumeration.json',Path('campaign/enumeration.json'))
copy(F/'capture-audit.json',Path('campaign/capture-audit.json'))
copy(E/'reproduce.py',Path('reproduce.py'))
copy(E/'archive-README.md',Path('README.md'))
for name in ('examples/outing-planner/QUALIFICATION.md','examples/outing-planner/README.md','examples/outing-planner/model/README.md','docs/outing-planner.md'):
 copy(Path(name),Path('documentation')/name)
copy('/private/tmp/alan-delegated-process-contract.md',Path('historical/source-audits/process-contract.md'))
copy('/private/tmp/alan-delegated-storage-contract.md',Path('historical/source-audits/storage-contract.md'))
# Recover the original tiny API-absence RED test bytes and verify their recorded
# digest; this is explicitly reconstructed matching source, not a fresh capture.
red=b'//go:build integration\n\npackage main\n\nimport "testing"\n\nfunc TestDelegatedProcessRecovery(t *testing.T) { t.Fatal("delegated process cuts not yet implemented") }\n'
redcmd=json.loads((E/'process-red.command.json').read_bytes())
assert hashlib.sha256(red).hexdigest()==redcmd['source_files']['examples/outing-planner/delegated_process_test.go']
(R/'commands/process-red-source.go.txt').write_bytes(red)
# The initial RED source was not contemporaneously frozen. Recover each recorded
# file from read-only base Git objects (plus the exact tiny stub) and require its
# original per-file digest. Label this chronology explicitly.
recovered={}
for name,want in redcmd['source_files'].items():
 data=red if name=='examples/outing-planner/delegated_process_test.go' else subprocess.check_output(['git','show','3af5726d38b0685f37314f00aad7ca39ae7064db:'+name])
 assert hashlib.sha256(data).hexdigest()==want,('initial RED recovered source mismatch',name)
 destination=R/'historical/task5/initial-red-source'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
 recovered[name]=want
(R/'historical/task5/initial-red-source/PROVENANCE.json').write_text(json.dumps({'method':'recovered from read-only base Git objects plus exact initial stub; every byte buffer matched its recorded command-time SHA256; not contemporaneous source capture','source_files':recovered},indent=2)+'\n')

# Bind source-set identities to exact archived executable byte sets.
launchers={}
for folder in ('source/examples/outing-planner/model','historical/task4/source-before-fix/examples/outing-planner/model','historical/task4/source-after-continuation-fix/examples/outing-planner/model'):
 files={n:hashlib.sha256((R/folder/n).read_bytes()).hexdigest() for n in ('check.py','evidence.py')}
 identity=hashlib.sha256(b'outing-source-set/v1\0'+json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 launchers[identity]=folder+'/run.py'
jobs=[];skipped=[];seen=set()
for p in sorted(R.rglob('*.json')):
 try:x=json.loads(p.read_bytes())
 except (ValueError,UnicodeError):continue
 if not isinstance(x,dict) or 'accepted' not in x or 'execution' not in x:continue
 execution=x['execution'];argv=execution.get('command',[])
 action=next((a for a in ('check','compare') if a in argv),None)
 if action is None:continue
 inputs={};missing=[]
 for flag in ('--store','--baseline','--candidate','--configuration','--fixture','--manifest','--report','--replacement'):
  if flag in argv:
   old=argv[argv.index(flag)+1]
   if old not in pathmap:missing.append(old)
   else:inputs[flag]=pathmap[old]
 identity=execution.get('source_set_sha256')
 if missing or identity not in launchers:
  skipped.append({'evidence':str(p.relative_to(R)),'missing_inputs':missing,'unknown_source_set':identity if identity not in launchers else None});continue
 key=(identity,action,tuple(inputs.items()),bool(x['accepted']))
 if key in seen:continue
 seen.add(key)
 expected={k:x[k] for k in ('accepted','invariant','raw_cut_sha256','classification','successful_replacement') if k in x}
 category='final_independent_check'
 if str(p.relative_to(R)).startswith('historical/'): category='historical_source_or_recheck'
 if str(p.relative_to(R)).startswith('superseded/task5/'): category='superseded_pre_export_fix'
 if str(p.relative_to(R)).startswith('superseded/full-race-timeout/'): category='superseded_post_export_fix_timeout'
 if str(p.relative_to(R)).startswith('investigation/event-prefilter/'): category='diagnostic_overlay_trial'
 if str(p.relative_to(R)).startswith('campaign/walkthrough-before-correction/'): category='preserved_export_RED'
 if 'review/original-probe/' in str(p.relative_to(R)): category='historical_wrong_acceptance_before_fix'
 jobs.append({'category':category,'evidence':str(p.relative_to(R)),'launcher':launchers[identity],'source_set_sha256':identity,'action':action,'inputs':inputs,'expected':expected})
# Re-enact the four preserved semantic RED Stores with old source, and reject
# those exact bytes with fixed source. These are new reproduction commands,
# never represented as the original historical argv (the RED log used API calls).
old_identity=next(k for k,v in launchers.items() if v.startswith('historical/'))
fixed_identity=next(k for k,v in launchers.items() if v.startswith('source/'))
for capture in sorted((R/'historical/task4/red-mutations').glob('*/mutation.db.capture.json')):
 metadata=json.loads(capture.read_bytes());original=Path(metadata['source'])
 inputs={'--store':str(capture.with_suffix('').with_suffix('').relative_to(R))}
 # The .db.capture.json suffix must strip only .capture.json.
 inputs['--store']=str(capture.with_name('mutation.db').relative_to(R))
 for flag,name in (('--configuration','derived-configuration.json'),('--fixture','fixture.json'),('--manifest','deployment-manifest.json')):
  inputs[flag]=pathmap[str((original.parent/name).resolve())]
 control=capture.parent.name.split('-')[0]
 for identity,accepted,category in ((old_identity,True,'historical_RED_acceptance_reenactment'),(fixed_identity,False,'fixed_rejection_of_preserved_RED')):
  expected={'accepted':accepted}
  if not accepted: expected['invariant']='historical receive exact match/original correlation' if control=='historical_correlation' else 'concrete final continuation/model boundary'
  jobs.append({'category':category,'evidence':str(capture.parent.relative_to(R)),'launcher':launchers[identity],'source_set_sha256':identity,'action':'check','inputs':dict(inputs),'expected':expected,'provenance':'New reproduction command over exact preserved RED mutation; historical log records direct API acceptance, not this argv.'})
complete=next((R/'campaign/normal').glob('TestDelegatedRawModel-two-*'))
unknown=next((R/'campaign/normal').glob('TestDelegatedRawModel-unknown-*'))
files={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(R.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'}
manifest={'version':1,'original_task_base':'3af5726d38b0685f37314f00aad7ca39ae7064db','source_checkout_head':(F/'base-head.txt').read_text().strip(),'source_binding':'hashes of frozen source bytes, not a self-referential archive commit','archive_format':'tar+xz, LZMA2 preset9, normalized tar metadata and content-duplicate hardlinks','excluded':['executables','build caches','bytecode caches','live Store main files and sidecars','unrelated development scratch'],'files':files,'path_map':pathmap,'jobs':jobs,'nonreplayed_outputs':skipped,'fixture_tests':{'complete':str(complete.relative_to(R)),'unknown':str(unknown.relative_to(R))},'job_counts':dict(collections.Counter(j['category']+('/accepted' if j['expected']['accepted'] else '/rejected') for j in jobs))}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
archive=E/'qualification.tar.xz'
with lzma.open(archive,'wb',format=lzma.FORMAT_XZ,preset=9) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
 seen_content={}
 for p in sorted(R.rglob('*')):
  if not p.is_file():continue
  data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo('delegated-weather/'+str(p.relative_to(R)));info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  if digest in seen_content:
   info.type=tarfile.LNKTYPE;info.linkname=seen_content[digest];info.size=0;tar.addfile(info)
  else:
   seen_content[digest]=info.name;info.size=len(data);tar.addfile(info,io.BytesIO(data))
print(json.dumps({'files':len(files),'jobs':len(jobs),'results':manifest['job_counts'],'nonreplayed_outputs':len(skipped),'archive_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
