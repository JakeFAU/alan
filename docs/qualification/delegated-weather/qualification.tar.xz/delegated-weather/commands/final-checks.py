"""Run each final repository gate once, sequentially; stop on any failure."""
import subprocess,sys,os,pathlib,json
root=pathlib.Path('/private/tmp/alan-delegated-task5-3af5726')
commands=[
 ('verified-mod-verify',['go','mod','verify']),
 ('verified-mod-tidy',['go','mod','tidy','-diff']),
 ('verified-build',['go','build','./...']),
 ('verified-staticcheck',['staticcheck','./...']),
 ('verified-staticcheck-integration',['staticcheck','-tags','integration','./...']),
 ('verified-tests',['go','test','-count=1','-timeout=60m','./...']),
 ('verified-integration-tests',['go','test','-count=1','-timeout=60m','-tags','integration','./...']),
 ('verified-race-integration-tests',['go','test','-v','-count=1','-timeout=60m','-race','-tags','integration','./...']),
]
for name,argv in commands:
 environment=dict(os.environ)
 environment.pop('ALAN_RAW_CAPTURE_DIR',None)
 if name=='verified-race-integration-tests':environment['ALAN_RAW_CAPTURE_DIR']=str(root/'final-after-event-filter/race-captures')
 code=subprocess.call([sys.executable,str(root/'run-command.py'),name]+argv,env=environment)
 if code:sys.exit(code)
print('All required final repository gates passed; verbose full race run includes focused process/CLI coverage.',flush=True)
