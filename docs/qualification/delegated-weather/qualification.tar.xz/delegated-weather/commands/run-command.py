import subprocess, sys, json, time, pathlib, hashlib, os
root=pathlib.Path('/private/tmp/alan-delegated-task5-3af5726')
name=sys.argv[1]; argv=sys.argv[2:]; start=time.time()
files=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','--','*.go','go.mod','go.sum','examples/outing-planner/model/*.py']).decode().splitlines()
sources={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in files if pathlib.Path(p).is_file()}
helper_files={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in argv if p.endswith(('.py','.sh')) and pathlib.Path(p).is_file()}
recorder_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
with (root/(name+'.log')).open('wb') as log: code=subprocess.call(argv,stdout=log,stderr=subprocess.STDOUT)
record={'argv':argv,'cwd':os.getcwd(),'exit':code,'seconds':time.time()-start,'source_files':sources,'executed_helper_files':helper_files,'recorder_sha256':recorder_sha256,'environment':{k:v for k,v in os.environ.items() if k.startswith(('ALAN_RAW','OUTING_RAW','OUTING_MUTATION','OUTING_REPLACEMENT'))}}
(root/(name+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('argv','exit','seconds')}),flush=True)
sys.exit(code)
