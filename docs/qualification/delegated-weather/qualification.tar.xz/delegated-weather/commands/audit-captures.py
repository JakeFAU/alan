from pathlib import Path
import json,hashlib,collections
root=Path('/private/tmp/alan-delegated-task5-3af5726/final-after-event-filter')
source=json.loads((root/'source-hashes.json').read_bytes())
for name,want in source.items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==want,('current source changed',name)
 assert hashlib.sha256((root/'source'/name).read_bytes()).hexdigest()==want,('frozen source changed',name)
expected_set='01b6c8caa7e8c1681c828b3b0edfda62975b828edcf8989522c91cf85b52440b'
summary={'source_identity':json.loads((root/'source-identity.json').read_bytes()),'campaigns':{}}
for label,folder in [('normal','captures'),('race','race-captures')]:
 directory=root/folder
 counts=collections.Counter();rows=0;checks=[];captures=[];decisions=[]
 for p in sorted(directory.glob('*/*-check.json')):
  x=json.loads(p.read_bytes());assert x['accepted'],str(p)
  assert x['execution']['source_set_sha256']==expected_set,str(p)
  assert len(x['inventory'])==42,str(p)
  assert x['concrete_debts']==x['debts'],str(p)
  counts[x['classification']]+=1
  rows+=sum(v.get('count',0) if isinstance(v,dict) else len(v) for v in x['inventory'].values())
  checks.append(str(p.relative_to(root)))
  if x['decision_commit_cut']['verified']:decisions.append(str(p.relative_to(root)))
 for p in sorted(directory.rglob('*.db.capture.json')):
  x=json.loads(p.read_bytes());target=p.with_name(p.name.removesuffix('.capture.json'))
  assert x['complete_source_and_destination_rows_equal'],str(p)
  assert len(x['inventory'])==42,str(p)
  assert hashlib.sha256(target.read_bytes()).hexdigest()==x['destination_sha256'],str(p)
  captures.append(str(p.relative_to(root)))
 comparisons=[]
 for p in sorted(directory.glob('cli-replacement-*/pair/independent-comparison.json')):
  x=json.loads(p.read_bytes());assert x['accepted'],str(p)
  assert x['execution']['source_set_sha256']==expected_set,str(p)
  comparisons.append({'path':str(p.relative_to(root)),'classification':x['classification'],'baseline':x['baseline']['classification'],'candidate':x['candidate']['classification']})
 witnesses=[str(p.relative_to(root)) for p in sorted(directory.glob('*/process-witness.json'))]
 assert len(witnesses)==13,(label,len(witnesses))
 assert len(checks)==110,(label,len(checks))
 assert len(comparisons)==2,(label,len(comparisons))
 summary['campaigns'][label]={'checks':len(checks),'covered_rows_per_cut_sum':rows,'classifications':dict(counts),'capture_files':len(captures),'decision_commit_premises_verified':decisions,'process_witnesses':witnesses,'real_cli_comparisons':comparisons,'check_paths':checks}
(root/'capture-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:{'cuts':v['checks'],'rows':v['covered_rows_per_cut_sum'],'classifications':v['classifications'],'process_witnesses':len(v['process_witnesses']),'real_cli_comparisons':v['real_cli_comparisons']} for k,v in summary['campaigns'].items()},indent=2))
