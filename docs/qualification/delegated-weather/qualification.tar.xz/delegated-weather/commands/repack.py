"""Recreate the controlled archive bytes from an intact extracted bundle."""
import lzma,io,pathlib,tarfile,sys,hashlib
root=pathlib.Path(sys.argv[1]).resolve();destination=pathlib.Path(sys.argv[2]).resolve()
if destination.is_relative_to(root): raise SystemExit('archive output must be outside bundle')
with lzma.open(destination,'wb',format=lzma.FORMAT_XZ,preset=9) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
 seen_content={}
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo('delegated-weather/'+str(p.relative_to(root)));info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  if digest in seen_content:
   info.type=tarfile.LNKTYPE;info.linkname=seen_content[digest];info.size=0;tar.addfile(info)
  else:
   seen_content[digest]=info.name;info.size=len(data);tar.addfile(info,io.BytesIO(data))
print(hashlib.sha256(destination.read_bytes()).hexdigest())
