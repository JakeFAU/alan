from pathlib import Path
import json
E=Path('/private/tmp/alan-delegated-task5-3af5726');F=E/'final-after-event-filter'
keys=['mod-verify','mod-tidy','build','staticcheck','staticcheck-integration','tests','integration-tests','race-integration-tests']
commands=[json.loads((E/('verified-'+key+'.command.json')).read_bytes()) for key in keys]
assert all(c['exit']==0 for c in commands)
audit=json.loads((F/'capture-audit.json').read_bytes())
lines=['Final verification passed with no race diagnostic. Normal and race campaigns each retained:','', '| Campaign | Accepted cuts | Covered row entries summed per cut | Process SIGKILL witnesses | Actual CLI pair comparisons |','| --- | ---: | ---: | ---: | ---: |']
for label in ['normal','race']:
 x=audit['campaigns'][label]
 lines.append(f"| {label} | {x['checks']} | {x['covered_rows_per_cut_sum']:,} | {len(x['process_witnesses'])} | {len(x['real_cli_comparisons'])} |")
lines.extend(['','The row sum counts repeated retained prefixes per cut. Each cut covers all 42 tables.','The two real CLI comparisons per campaign separately check four complete Stores;','the walkthrough adds its own accepted/refused pairs. The fixture-backed Python','campaign ran all 14 methods without skips, including the two real exports and','11 adverse export variants. Source-only execution ran five methods and explicitly','skipped nine capture-dependent methods. All 24 model methods passed.','', '| Required full gate (actual argv) | Exit | Elapsed seconds |','| --- | ---: | ---: |'])
for c in commands: lines.append('| `'+ ' '.join(c['argv'])+f"` | {c['exit']} | {c['seconds']:.3f} |")
lines.extend(['','Elapsed values are diagnostic run observations, not application benchmarks.'])
section=(E/'qualification-final-template.md').read_text().replace('{{FINAL_RESULTS}}','\n'.join(lines))
replacements={'contains409':'contains 409','all110':'all 110','all14':'all 14','Old83':'Old 83','old83':'old 83','schema9':'schema 9','gen1':'gen 1','epoch2':'epoch 2','epoch1':'epoch 1','epoch0':'epoch 0','seq18':'seq 18','seq8':'seq 8','seq5':'seq 5','seq43':'seq 43','seq82':'seq 82','seq38':'seq 38','seq56':'seq 56','seq39':'seq 39','in6m':'in 6m','versus59':'versus 59','in1m':'in 1m','were369/365':'were 369/365','model remains346':'model remains 346','configurations,31,102':'configurations, 31,102','states and79,866':'states and 79,866','inputs,0–2':'inputs, 0–2','Research§':'Research §','and§':'and §','unchanged60m':'unchanged 60m'}
for a,b in replacements.items():section=section.replace(a,b)
p=Path('examples/outing-planner/QUALIFICATION.md');text=p.read_text();marker='\n## Delegated Weather: final bounded campaign';text=text.split(marker)[0].rstrip()+'\n'+section;p.write_text(text)
print('Wrote source-bound final qualification with actual gate results.')
