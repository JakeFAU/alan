import ast,pathlib,tempfile,hashlib,json
source=pathlib.Path('/private/tmp/alan-delegated-task5-3af5726/reproduce.py').read_bytes()
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='fresh_output')
namespace={'pathlib':pathlib,'tempfile':tempfile}
exec(compile(ast.Module(body=[node],type_ignores=[]),'reproduce.py:actual-fresh-output','exec'),namespace)
create=namespace['fresh_output'];results=[]
with tempfile.TemporaryDirectory() as directory:
 root=pathlib.Path(directory);bundle=root/'bundle';bundle.mkdir();sentinel=bundle/'evidence';sentinel.write_text('unchanged')
 existing=root/'existing';existing.mkdir();(existing/'evidence').write_text('preserved')
 for label,path in [('existing',existing),('bundle',bundle),('inside',bundle/'new-output')]:
  try:create(bundle,path)
  except (ValueError,FileExistsError):results.append(label+' rejected')
  else:raise AssertionError(label+' accepted')
 assert not (bundle/'new-output').exists() and sentinel.read_text()=='unchanged' and (existing/'evidence').read_text()=='preserved'
 link=root/'alias';link.symlink_to(bundle,target_is_directory=True)
 try:create(bundle,link/'new-output')
 except ValueError:results.append('symlink into bundle rejected')
 else:raise AssertionError('symlink input accepted')
 fresh=create(bundle,root/'new');assert fresh.is_dir();results.append('new outside directory created exclusively')
 default=create(bundle,None);assert default.is_dir() and not default.is_relative_to(bundle);default.rmdir();results.append('default fresh outside directory')
print(json.dumps({'source_sha256':hashlib.sha256(source).hexdigest(),'guards':results}))
