import os, pathlib, subprocess, sys, datetime, shlex, json
root=pathlib.Path('/tmp/alan-phase3b3-baseline'); root.mkdir(exist_ok=True)
label=sys.argv[1]; args=sys.argv[2:]
env=os.environ.copy(); env.update(GOTOOLCHAIN='local',GOCACHE='/tmp/alan-phase3a-go-build',GOPROXY='off',GOSUMDB='off',ALAN_PHASE3B3_EVIDENCE=str(root))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
record={'command':shlex.join(args),'cwd':os.getcwd(),'environment':{k:env[k] for k in ('GOTOOLCHAIN','GOCACHE','GOPROXY','GOSUMDB','ALAN_PHASE3B3_EVIDENCE','ALAN_PHASE3B3_EXPECT_S2_COMPLETION') if k in env},'started':started,'exit_code':p.returncode}
(root/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n'); (root/(label+'.log')).write_text(p.stdout)
print(json.dumps(record)); print(p.stdout); sys.exit(p.returncode)
