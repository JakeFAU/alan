"""Compare exported evidence only. Never opens any SQLite file."""
import copy
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parent
rows, differences, fixtures = [], [], []
for version in range(3, 13):
    for api in ['Replay', 'Inspect', 'InspectExecution', 'Open']:
        names = ['replay.json', 'raw.json', 'typed.json'] if api == 'Open' else ['export.json']
        entry = {'version': version, 'api': api, 'old': 'pass', 'current': 'pass', 'exports': []}
        for name in names:
            rel = Path(f'v{version:02d}') / api / name
            old = (root / 'readers/old' / rel).read_bytes()
            current = (root / 'readers/current' / rel).read_bytes()
            entry['exports'].append({'path': str(rel), 'equal_bytes': old == current,
                                     'old_sha256': hashlib.sha256(old).hexdigest(),
                                     'current_sha256': hashlib.sha256(current).hexdigest()})
            if old != current:
                differences.append({'path': str(rel), 'json_equal': json.loads(old) == json.loads(current)})
        rows.append(entry)
    p = root / 'readers/old' / f'v{version:02d}'
    raw = json.loads((p / 'Inspect/export.json').read_text())
    before = json.loads((p / 'InspectExecution/export.json').read_text())
    after = json.loads((p / 'Open/typed.json').read_text())
    expected = copy.deepcopy(before)
    renewed = []
    for run in expected['Snapshot']['Runs']:
        if run['Projection']['Status'] == 'open':
            run['Epoch'] += 1
            renewed.append(run['ID'])
    assert expected == after, (version, 'Open changed more than open-run epochs')
    snap = before['Snapshot']
    fixtures.append({'version': version, 'namespace': snap['Namespace'], 'features': snap['Features'],
                     'table_rows': {k: len(v or []) for k, v in raw['Tables'].items()},
                     'history_steps': before['History']['Total'],
                     'continuations': snap.get('Continuations', []), 'renewed_runs': renewed,
                     'open_only_changed_expected_epochs': True})
for name, value in [('reader-matrix.json', rows), ('differences.json', differences), ('fixture-summary.json', fixtures)]:
    (root / name).write_text(json.dumps(value, indent=2) + '\n')
after = {str(p.relative_to(root / 'originals')): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted((root / 'originals').rglob('*')) if p.is_file()}
(root / 'originals-after.json').write_text(json.dumps(after, indent=2) + '\n')
assert after == json.loads((root / 'originals-before.json').read_text()), 'archived original bytes changed'
assert not differences, differences
print('40 paired API outcomes; 60 byte-identical JSON export pairs; 10 exact activation-only Open deltas; 10 unchanged originals')
