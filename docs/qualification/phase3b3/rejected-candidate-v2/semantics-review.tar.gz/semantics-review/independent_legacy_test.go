package executor
import("encoding/json"; "testing"; "os")
func TestIndependentLegacyAttemptAuthorityMetadata(t *testing.T) {
 s,path:=messageStore(t,externalProvision(t,"http://127.0.0.1:1234/apply","idempotent"))
 if _,err:=s.Commit(t.Context(),current(t,s,"client").Authority(),"");err!=nil {t.Fatal(err)}
 a,_,err:=s.prepareExternal(t.Context(),identity("client",int64(1),int64(1),0));if err!=nil {t.Fatal(err)}
 if _,err=InspectExecution(t.Context(),path,DefaultLimits());err!=nil {t.Fatalf("clean inspection: %v",err)}
 clean,_:=json.Marshal(a);if err:=os.WriteFile("/tmp/alan-phase3b3-semantics-review/clean-attempt.json",clean,0600);err!=nil {t.Fatal(err)}
 a.Authority=&EffectAuthority{Version:RequestAuthorityVersion,Namespace:s.Namespace(),Allowed:true,Reason:"authorized"}
 raw,err:=json.Marshal(a);if err!=nil {t.Fatal(err)}
 if _,err=s.conn.ExecContext(t.Context(),"UPDATE external_attempts SET descriptor=? WHERE intent_id=?",raw,a.Intent.ID);err!=nil {t.Fatal(err)}
 if err:=os.WriteFile("/tmp/alan-phase3b3-semantics-review/mutated-attempt.json",raw,0600);err!=nil {t.Fatal(err)}
 _,replayErr:=Replay(t.Context(),path,DefaultLimits());t.Logf("Replay mutated legacy attempt: %v",replayErr)
 snap,inspectErr:=InspectExecution(t.Context(),path,DefaultLimits());t.Logf("Inspect mutated legacy attempt: %v",inspectErr)
 if err:=s.Close();err!=nil {t.Fatal(err)}; db,err:=os.ReadFile(path);if err!=nil {t.Fatal(err)};if err=os.WriteFile("/tmp/alan-phase3b3-semantics-review/legacy-metadata-rejected.sqlite",db,0600);err!=nil {t.Fatal(err)}
 if inspectErr==nil {t.Fatalf("legacy inspection accepted forbidden typed Authority: feature=%v witness=%+v",snap.Features.RequestAuthority,snap.Effects[0].ExternalAttempt.Authority)}
}
