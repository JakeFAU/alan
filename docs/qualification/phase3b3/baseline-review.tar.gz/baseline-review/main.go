package main

import (
 "context"
 "encoding/json"
 "errors"
 "fmt"
 "os"

 "github.com/JakeFAU/alan/runtime"
)

type outcome struct {
 Path string
 InspectError string
 InspectCorrupt bool
 ReplayError string
 ReplayCorrupt bool
}
func main() {
 ctx:=context.Background()
 out:=[]outcome{}
 for i,path:=range os.Args[1:] {
  snapshot, inspectErr:=runtime.InspectExecution(ctx,path,runtime.DefaultLimits())
  _,replayErr:=runtime.Replay(ctx,path,runtime.DefaultLimits())
  result:=outcome{path,fmt.Sprint(inspectErr),errors.Is(inspectErr,runtime.ErrCorrupt),fmt.Sprint(replayErr),errors.Is(replayErr,runtime.ErrCorrupt)}
  out=append(out,result)
  valid:=i==0 && inspectErr==nil && replayErr==nil && snapshot!=nil
  refused:=i!=0 && snapshot==nil && result.InspectCorrupt && result.ReplayCorrupt
  if !valid && !refused { json.NewEncoder(os.Stdout).Encode(out); os.Exit(1) }
 }
 enc:=json.NewEncoder(os.Stdout); enc.SetIndent("","  "); enc.Encode(out)
}
