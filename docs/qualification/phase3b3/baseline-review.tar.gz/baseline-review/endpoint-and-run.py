import json,pathlib,sqlite3,subprocess,datetime,os,hashlib,shutil
r=pathlib.Path('/tmp/alan-phase3b3-baseline');o=pathlib.Path('/tmp/alan-phase3b3-baseline-review');s=json.loads((r/'selected-witnesses.json').read_text());count=0
for name,folder in s.items():
 d=r/folder;endpoints=json.loads((d/'endpoint-ledgers-before-replay.json').read_text())
 for cap,snapshot in endpoints.items():
  copydir=o/'endpoint-db-disposable'/folder;copydir.mkdir(parents=True,exist_ok=True)
  for suffix in ('','-wal','-shm'):
   src=d/(cap+'.sqlite'+suffix)
   if src.exists():shutil.copyfile(src,copydir/src.name)
  db=sqlite3.connect('file:'+str(copydir/(cap+'.sqlite'))+'?mode=ro',uri=True)
  requests=[json.loads(x[0]) for x in db.execute('select request from contacts order by number')]
  applications=[json.loads(x[0]) for x in db.execute('select receipt from applications order by number')]
  keys=[(x[0],x[1],x[2],json.loads(x[3])) for x in db.execute('select key,profile,delta,descriptor from keys order by key')]
  assert requests==(snapshot['Requests'] or []),(name,cap,'contacts mismatch')
  assert applications==snapshot['Applications'],(name,cap,'applications mismatch')
  assert len(keys)==len(applications)
  for key,profile,delta,request in keys:
   assert request in requests and request['Key']==key and request['Profile']==profile and request['Delta']==delta
   assert any(a['Key']==key and a['Profile']==profile and a['Delta']==delta for a in applications)
  db.close();count+=1
(o/'endpoint-db-check.json').write_text(json.dumps({'endpoint_databases_verified':count,'result':'PASS'},indent=2)+'\n')
print('independent raw endpoint database checks: PASS',count)
cmd=['go','run',str(o/'main.go'),str(o/'valid-copy.sqlite'),str(o/'equal-payload-cross-result.sqlite')]
env={**os.environ,'GOTOOLCHAIN':'local','GOCACHE':'/tmp/alan-phase3a-go-build','GOPROXY':'off','GOSUMDB':'off'}
res=subprocess.run(cmd,cwd='/private/tmp/alan-phase3b3-runtime',env=env,text=True,capture_output=True)
(o/'selected-history-control.stdout.log').write_text(res.stdout);(o/'selected-history-control.stderr.log').write_text(res.stderr)
(o/'selected-history-control.command.json').write_text(json.dumps({'argv':cmd,'cwd':'/private/tmp/alan-phase3b3-runtime','environment':{k:env[k] for k in ('GOTOOLCHAIN','GOCACHE','GOPROXY','GOSUMDB')},'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':res.returncode},indent=2)+'\n')
print(res.stdout);assert res.returncode==0
n=0
for label,folder in s.items():
 for f,digest in json.loads((r/folder/'digests.json').read_text()).items():
  assert hashlib.sha256((r/folder/f).read_bytes()).hexdigest()==digest,(label,f)
  n+=1
print('original archived bytes retained:',n,'digest entries unchanged')
