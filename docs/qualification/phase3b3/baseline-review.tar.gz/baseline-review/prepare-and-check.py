import hashlib,json,pathlib,sqlite3,shutil
root=pathlib.Path('/tmp/alan-phase3b3-baseline'); out=pathlib.Path('/tmp/alan-phase3b3-baseline-review')
selected=json.loads((root/'selected-witnesses.json').read_text()); checks=[]
def runid(x):return x['Subject'],x['Generation']
def ref(x):return (*runid(x['Run']),x['Sequence'])
for label,dirname in selected.items():
 d=root/dirname; tables=json.loads((d/'inspect.json').read_text())['Tables']
 operations={x['id']:json.loads(x['descriptor']) for x in tables['intents']}
 observations={x['id']:(x,json.loads(x['descriptor'])) for x in tables['observations']}
 history={(x['subject'],x['generation'],x['sequence']):x for x in tables['history']}
 admissions={x['observation_id']:(json.loads(x['descriptor']),json.loads(x['result'])) for x in tables['admissions']}
 attempts={x['intent_id']:json.loads(x['descriptor']) for x in tables['adapter_attempts']}
 results={x['intent_id']:json.loads(x['descriptor']) for x in tables['adapter_results']}
 settlements={x['intent_id']:x for x in tables['settlements']}
 permissions={tuple(x[k] for k in ('source','target','operation','revision','obligation')) for x in tables['permissions'] if x['kind']=='adapter'}
 for opid,attempt in attempts.items():
  operation=operations[opid]
  held=(*runid(operation['Run'])[:1],operation['Target'],operation['Obligation'],1,operation['Obligation']) in permissions
  assert attempt['Allowed']==held,(label,opid,'permission tuple')
  assert attempt['Intent']==operation
  assert attempt['Prepared']['Request']['ID']==opid
 endpoints=json.loads((d/'endpoint-ledgers-before-replay.json').read_text())
 for capability,ledger in endpoints.items():
  assert ledger['Contacts']==len(ledger['Requests'] or [])==len(ledger['Applications'])
  for request,application in zip(ledger['Requests'] or [],ledger['Applications']):
   matches=[opid for opid,a in attempts.items() if a['Allowed'] and a['Prepared']['Request']['Key']==request['Key'] and a['Prepared']['Request']['Capability']==capability]
   assert len(matches)==1
   assert json.loads(results[matches[0]]['Candidate']['Response'])==application
 count=0
 for binding in json.loads((d/'original-bindings.json').read_text()) if (d/'original-bindings.json').exists() else []:
  request=operations[binding['RequestOperation']]; server=binding['Server']; requester=binding['Requester']
  assert requester['Generation']==server['Generation']==1
  assert request['Run']==requester and request['Target']==server['Subject'] and request['Generation']==server['Generation']
  row,observation=observations[binding['RequestObservation']]
  assert observation['Run']==server and observation['Source']==requester['Subject'] and observation['SourceGeneration']==requester['Generation']
  assert observation['Payload']==request['Payload']
  admission,result=admissions[binding['RequestObservation']]
  assert result['Accepted'] and result['Bound']==server and admission['IntentID']==request['ID'] and admission['Source']==requester
  assert history[ref(binding['RequestSelection'])]['selected_observation']==row['id'] and row['consumed_sequence']==binding['RequestSelection']['Sequence']
  service=operations[binding['ServiceOperation']]
  assert service['Run']==server and service['Sequence']==binding['ServiceSequence']>binding['RequestSelection']['Sequence']
  assert service in json.loads(history[(*runid(server),service['Sequence'])]['intents'])
  row,result=observations[binding['ResultObservation']]
  assert result['Run']==server and result['Operation']==service['ID'] and settlements[service['ID']]['observation_id']==row['id']
  assert result['Payload']==results[service['ID']]['Values']
  assert history[ref(binding['ResultSelection'])]['selected_observation']==row['id'] and row['consumed_sequence']==binding['ResultSelection']['Sequence']>service['Sequence']
  if binding['ReplySelection'] is not None:
   reply=operations[binding['ReplyOperation']]; row,observation=observations[binding['ReplyObservation']]
   assert reply['Run']==server and reply['Target']==requester['Subject'] and reply['Generation']==requester['Generation']
   assert reply['Sequence']>binding['ResultSelection']['Sequence']
   assert reply['Payload']==observation['Payload'] and observation['Run']==requester and observation['Source']==server['Subject'] and observation['SourceGeneration']==server['Generation']
   assert reply['Payload']['response_id']==request['Payload']['request_id'] and reply['Payload']['service_operation']['Text']==service['ID']
   assert all(reply['Payload'][k]==results[service['ID']]['Values'][k] for k in ('mutation','total'))
   assert history[ref(binding['ReplySelection'])]['selected_observation']==row['id'] and row['consumed_sequence']==binding['ReplySelection']['Sequence']
  count+=1
 checks.append({'case':label,'raw_bindings_checked':count,'adapter_decisions_checked':len(attempts)})
# Create consistent disposable database copies using SQLite backup; originals remain read-only.
source=root/selected['local']/'runtime.sqlite'
stage=out/'runtime-db-disposable';stage.mkdir(parents=True,exist_ok=True)
for suffix in ('','-wal','-shm'):
 src=pathlib.Path(str(source)+suffix)
 if src.exists():shutil.copyfile(src,stage/('runtime.sqlite'+suffix))
connection=sqlite3.connect('file:'+str(stage/'runtime.sqlite')+'?mode=ro',uri=True)
for name in ['valid-copy','equal-payload-cross-result']:
 target=out/(name+'.sqlite');target.unlink(missing_ok=True)
 dest=sqlite3.connect(target);connection.backup(dest);dest.close()
connection.close()
db=sqlite3.connect(out/'equal-payload-cross-result.sqlite')
rows=db.execute("select id,descriptor from observations where id like '%adapter%'").fetchall()
parsed=[(ident,json.loads(descriptor)) for ident,descriptor in rows]
a=next(x for x in parsed if x[1]['Run']['Subject']=='a'); b=next(x for x in parsed if x[1]['Run']['Subject']=='b')
assert a[1]['Payload']==b[1]['Payload']
changed=db.execute('update history set selected_observation=? where subject=? and generation=? and sequence=? and selected_observation=?',(b[0],'a',1,7,a[0])).rowcount
assert changed==1;db.commit();db.close()
result={'raw_evidence_checks':checks,'mutation':{'source':str(source),'table':'history','run':{'Subject':'a','Generation':1},'sequence':7,'old_selected_observation':a[0],'new_selected_observation':b[0],'equal_payload':True,'rows_changed':changed}}
(out/'raw-checks-and-mutation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
