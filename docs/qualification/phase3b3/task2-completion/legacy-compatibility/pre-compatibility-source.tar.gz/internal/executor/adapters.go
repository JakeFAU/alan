package executor

import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"time"

	"github.com/JakeFAU/alan/effects"
	"github.com/JakeFAU/alan/internal/boundary"
	publicschema "github.com/JakeFAU/alan/schema"
)

type AdapterAttempt struct {
	Authority       *EffectAuthority `json:",omitempty"`
	Intent          Intent
	AuthorizationID string
	Prepared        effects.Prepared
	Allowed         bool
	Reason          string
}
type AdapterResult struct {
	RefusalWitness string                 `json:",omitempty"`
	Read           *receiptReadDecision   `json:",omitempty"`
	Reconciled     *receiptReconstruction `json:",omitempty"`
	Digest         string
	Candidate      effects.Candidate
	Values         map[string]Value
	Disposition    string
}

type adapterWork struct {
	read    *receiptReadOrdinal
	refusal string
	attempt AdapterAttempt
	adapter effects.Adapter
	timeout time.Duration
	event   boundary.Event
}
type adapterCompletion struct {
	read      *receiptReadOrdinal
	attempt   AdapterAttempt
	candidate effects.Candidate
	event     boundary.Event
	err       error
}

func readAssets(ctx context.Context, q queryer) ([]effects.Asset, error) {
	ids, e := stringList(ctx, q, "SELECT id FROM corpus_assets ORDER BY id")
	if e != nil {
		return nil, e
	}
	assets := []effects.Asset{}
	for _, id := range ids {
		var b []byte
		if e = q.QueryRowContext(ctx, "SELECT descriptor FROM corpus_assets WHERE id=?", id).Scan(&b); e != nil {
			return nil, e
		}
		var a effects.Asset
		if decode(b, &a) != nil || !sameJSON(b, a) || a.ID != id || a.Check() != nil {
			return nil, corrupt("corpus asset")
		}
		assets = append(assets, a)
	}
	if e = effects.CheckAssets(assets); e != nil {
		return nil, corrupt("corpus bounds")
	}
	return assets, nil
}
func adapterRequest(ctx context.Context, q queryer, id, namespace string, l Limits) (effects.Request, retainedIntent, error) {
	i, e := loadIntent(ctx, q, id)
	if e != nil {
		return effects.Request{}, i, e
	}
	if i.Kind != "adapter" || i.Generation != 1 {
		return effects.Request{}, i, fmt.Errorf("invalid adapter intent")
	}
	run, e := loadRun(ctx, q, i.Run)
	if e != nil {
		return effects.Request{}, i, e
	}
	p, e := loadProgram(ctx, q, run.ProgramID, l)
	if e != nil {
		return effects.Request{}, i, e
	}
	if p.Author == nil {
		return effects.Request{}, i, fmt.Errorf("adapter requires retained author contract")
	}
	effect, ok := p.Author.Effects[i.Obligation]
	if !ok || effect.Capability != i.Target {
		return effects.Request{}, i, fmt.Errorf("undeclared adapter capability")
	}
	if e = effect.Input.Record.Validate(i.Payload); e != nil {
		return effects.Request{}, i, fmt.Errorf("adapter input schema: %w", e)
	}
	assets, e := readAssets(ctx, q)
	return effects.Request{ID: id, Key: ExternalKey(namespace, id), Capability: i.Target, Effect: i.Obligation, Input: effect.Input, Output: effect.Output, Payload: i.Payload, Assets: assets}, i, e
}
func loadAdapterAttempt(ctx context.Context, q queryer, id string) (AdapterAttempt, error) {
	var a AdapterAttempt
	var b []byte
	e := q.QueryRowContext(ctx, "SELECT descriptor FROM adapter_attempts WHERE intent_id=?", id).Scan(&b)
	if e != nil {
		return a, e
	}
	if decode(b, &a) != nil || !sameJSON(b, a) || a.Intent.ID != id {
		return a, corrupt("adapter attempt encoding")
	}
	return a, nil
}
func loadAdapterResult(ctx context.Context, q queryer, id string) (AdapterResult, error) {
	var r AdapterResult
	var b []byte
	e := q.QueryRowContext(ctx, "SELECT descriptor FROM adapter_results WHERE intent_id=?", id).Scan(&b)
	if e != nil {
		return r, e
	}
	if decode(b, &r) != nil || !sameJSON(b, r) || (r.Reconciled == nil && r.Candidate.ID != id || r.Reconciled != nil && r.Reconciled.Target != id) {
		return r, corrupt("adapter result encoding")
	}
	return r, nil
}
func adapterGrant(ctx context.Context, q queryer, i retainedIntent) (bool, error) {
	var n int
	e := q.QueryRowContext(ctx, "SELECT count(*) FROM permissions WHERE kind='adapter' AND source=? AND target=? AND operation=? AND revision=? AND obligation=?", i.Run.Subject, i.Target, i.Obligation, i.revision, i.Obligation).Scan(&n)
	return n == 1, e
}

// prepareAdapterWork runs trusted pure serialization outside the Store lock.
// It checks a retained attempt first: recovery never needs an adapter for results
// already known, nor can registration cause uncertain attempts to be repeated.
func (s *Store) prepareAdapterWork(ctx context.Context, id string, registry map[string]effects.Adapter, timeout time.Duration) (*adapterWork, error) {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return nil, sql.ErrConnDone
	}
	old, e := loadAdapterAttempt(ctx, s.conn, id)
	if e == nil {
		s.mu.Unlock()
		record := recordedDispatch{id: id, kind: "adapter", source: old.Intent.Run}
		if present, err := s.settleRecordedDispatch(ctx, record); err != nil || present {
			return nil, err
		}
		if old.Allowed {
			if !s.reconciliation || old.Intent.Target != receiptReadCapability {
				return nil, nil
			}
			reader, ok := controlledReader(registry[old.Intent.Target])
			if !ok || reader.Endpoint != old.Prepared.Endpoint {
				return nil, fmt.Errorf("bound receipt reader unavailable")
			}
			event := boundary.Event{Boundary: "adapter.authorized", Phase: "pre-transport", Subject: old.Intent.Run.Subject, Generation: old.Intent.Run.Generation, Sequence: old.Intent.Sequence, Intent: id, Attempt: old.AuthorizationID}
			return &adapterWork{attempt: old, adapter: reader, event: event, timeout: timeout}, nil
		}
		disposition := "source_denied"
		if old.Reason == "grant_denied" || old.Authority != nil && !old.Authority.Allowed {
			disposition = "grant_denied"
		}
		result, err := s.recordAdapterResult(ctx, old, effects.Candidate{ID: id, Key: old.Prepared.Request.Key, Disposition: disposition})
		if err != nil {
			return nil, err
		}
		return nil, s.settleAdapter(ctx, old, result)
	}
	if !errors.Is(e, sql.ErrNoRows) {
		s.mu.Unlock()
		return nil, e
	}
	request, intent, e := adapterRequest(ctx, s.conn, id, s.namespace, s.limits)
	s.mu.Unlock()
	if e != nil {
		return nil, e
	}
	adapter := registry[intent.Target]
	if adapter == nil {
		return nil, fmt.Errorf("adapter capability %q unavailable", intent.Target)
	}
	if s.reconciliation {
		if intent.Target == receiptReadCapability {
			if _, ok := controlledReader(adapter); !ok {
				return nil, fmt.Errorf("untrusted receipt reader")
			}
		}
		if intent.Target == receiptCounterCapability && !controlledCounter(adapter) {
			return nil, fmt.Errorf("untrusted controlled counter")
		}
	}
	// No locks, I/O or durable authority are exposed to Prepare. Implementations are
	// trusted to follow the documented pure/bounded contract.
	p, e := adapter.Prepare(effects.Copy(request))
	if e != nil {
		return nil, fmt.Errorf("adapter configuration/preparation rejected")
	}
	p = effects.Freeze(p)
	if !reflect.DeepEqual(p.Request, request) || effects.CheckPrepared(p) != nil || p.MaxResponseBytes > s.limits.MaxObservationBytes/8 {
		return nil, fmt.Errorf("prepared adapter request or bounds invalid")
	}
	auth, e := s.AuthorizeIntent(ctx, id)
	if e != nil {
		return nil, e
	}
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return nil, sql.ErrConnDone
	}
	tx, e := beginOwnedTx(ctx, s.conn)
	if e != nil {
		s.mu.Unlock()
		return nil, e
	}
	defer tx.Rollback()
	current, _, e := adapterRequest(ctx, tx, id, s.namespace, s.limits)
	if e != nil {
		s.mu.Unlock()
		return nil, e
	}
	if !reflect.DeepEqual(current, request) {
		s.mu.Unlock()
		return nil, ErrConflict
	}
	if slot, guarded := s.continuationSlot(intent.Run); guarded {
		if e = checkContinuationPreparation(ctx, tx, slot, intent, p); e != nil {
			s.mu.Unlock()
			return nil, e
		}
	}
	grant, e := adapterGrant(ctx, tx, intent)
	if e != nil {
		s.mu.Unlock()
		return nil, e
	}
	a := AdapterAttempt{Intent: intent.Intent, AuthorizationID: auth.ID, Prepared: p, Allowed: auth.Allowed && grant, Reason: auth.Reason}
	if auth.Allowed && !grant {
		a.Reason = "grant_denied"
	}
	enabled, e := requestAuthorityEnabled(ctx, tx)
	if e != nil {
		s.mu.Unlock()
		return nil, e
	}
	if enabled {
		a.Authority, e = evaluateEffectAuthority(ctx, tx, intent, authorityCurrentPrefix)
		if e != nil {
			s.mu.Unlock()
			return nil, e
		}
		a.Allowed = auth.Allowed && a.Authority.Allowed
		a.Reason = auth.Reason
		if auth.Allowed && !a.Authority.Allowed {
			a.Reason = a.Authority.Reason
		}
	}
	a.Allowed, a.Reason, e = compositionReservationDecision(ctx, tx, intent.Intent, a.Allowed, a.Reason)
	if e != nil {
		s.mu.Unlock()
		return nil, e
	}
	b, e := json.Marshal(a)
	if e == nil {
		_, e = tx.ExecContext(ctx, "INSERT INTO adapter_attempts VALUES(?,?)", id, b)
	}
	if e == nil {
		e = recordCompositionReservation(ctx, tx, intent.Intent, a.Allowed, a.Reason, a)
	}
	if e == nil {
		e = s.commitOwnedTx(ctx, tx)
	}
	s.mu.Unlock()
	if e != nil {
		return nil, e
	}
	event := boundary.Event{Boundary: "adapter.authorized", Phase: "pre-transport", Subject: intent.Run.Subject, Generation: intent.Run.Generation, Epoch: auth.Source.Epoch, Sequence: intent.Sequence, Intent: id, Attempt: auth.ID}
	if !a.Allowed {
		d := "source_denied"
		if a.Reason == "grant_denied" || a.Authority != nil && !a.Authority.Allowed {
			d = "grant_denied"
		}
		c := effects.Candidate{ID: id, Key: request.Key, Disposition: d}
		r, e := s.recordAdapterResult(ctx, a, c)
		if e != nil {
			return nil, e
		}
		return nil, s.settleAdapter(ctx, a, r)
	}
	return &adapterWork{attempt: effects.Copy(a), adapter: adapter, timeout: timeout, event: event}, nil
}
func transportAdapter(ctx context.Context, w adapterWork) adapterCompletion {
	r := adapterCompletion{attempt: w.attempt, event: w.event, read: w.read}
	if w.refusal != "" {
		r.candidate = effects.Candidate{ID: w.attempt.Intent.ID, Key: w.attempt.Prepared.Request.Key, Disposition: w.refusal}
		return r
	}
	if e := boundary.Reached(ctx, w.event); e != nil {
		r.err = e
		return r
	}
	limited, cancel := context.WithTimeout(ctx, w.timeout)
	defer cancel()
	if err := dispatchEvent(ctx, w.event, "dispatch.admitted", "pre-call"); err != nil {
		r.err = err
		return r
	}
	if w.read != nil {
		reader, _ := controlledReader(w.adapter)
		r.candidate = reader.ExecuteRead(limited, effects.Copy(w.attempt.Prepared), w.read.Query)
	} else {
		r.candidate = w.adapter.Execute(limited, effects.Copy(w.attempt.Prepared))
	}
	r.event.Boundary = "adapter.response"
	r.event.Phase = "pre-record"
	r.err = boundary.Reached(ctx, r.event)
	finished := w.event
	finished.Boundary = "adapter.finished"
	finished.Phase = "transport-ended"
	r.err = errors.Join(r.err, boundary.Reached(ctx, finished))
	return r
}
func (s *Store) accountAdapter(ctx context.Context, c adapterCompletion) error {
	if c.candidate.Disposition == "unknown" || c.candidate.Disposition == "" {
		e := c.event
		e.Boundary = "adapter.unknown"
		e.Phase = "unresolved"
		return errors.Join(c.err, boundary.Reached(ctx, e))
	}
	var r AdapterResult
	var e error
	if c.read != nil {
		r, e = s.recordReadResult(ctx, c.attempt, *c.read, c.candidate)
	} else {
		r, e = s.recordAdapterResult(ctx, c.attempt, c.candidate)
	}
	if e != nil {
		return errors.Join(c.err, e)
	}
	event := c.event
	event.Boundary = "adapter.result-recorded"
	event.Phase = "pre-settlement"
	if e = boundary.Reached(ctx, event); e != nil {
		return errors.Join(c.err, e)
	}
	if r.Read != nil {
		_, e = s.settleRecordedDispatch(ctx, recordedDispatch{id: c.attempt.Intent.ID, kind: "adapter", source: c.attempt.Intent.Run})
	} else {
		e = s.settleAdapter(ctx, c.attempt, r)
	}
	if e != nil {
		return errors.Join(c.err, e)
	}
	event.Boundary = "adapter.settled"
	event.Phase = "pre-consumption"
	return errors.Join(c.err, boundary.Reached(ctx, event))
}
func (s *Store) recordAdapterResult(ctx context.Context, a AdapterAttempt, c effects.Candidate) (AdapterResult, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	r := AdapterResult{}
	if s.closed {
		return r, sql.ErrConnDone
	}
	tx, e := beginOwnedTx(ctx, s.conn)
	if e != nil {
		return r, e
	}
	defer tx.Rollback()
	retained, e := loadAdapterAttempt(ctx, tx, a.Intent.ID)
	if e != nil {
		return r, e
	}
	if !reflect.DeepEqual(retained, a) || c.ID != a.Intent.ID || c.Key != a.Prepared.Request.Key {
		return r, ErrConflict
	}
	if e = validateAdapterAttempt(ctx, tx, a, s.namespace, s.limits); e != nil {
		return r, e
	}
	if s.reconciliation && a.Intent.Target == receiptReadCapability && a.Allowed {
		// Only the actual gate may create a local refusal, and only the
		// ordinal-bound recorder may create a transport result.
		old, err := loadAdapterResult(ctx, tx, a.Intent.ID)
		if errors.Is(err, sql.ErrNoRows) {
			return r, ErrConflict
		}
		if err != nil {
			return r, err
		}
		if old.Read != nil || !reflect.DeepEqual(old.Candidate, c) {
			return r, ErrConflict
		}
		return old, nil
	}
	if c.Disposition == "unknown" || c.Disposition == "" {
		return r, fmt.Errorf("unknown outcome has no result")
	}
	if a.Allowed {
		if err := requireAuthorityExposure(ctx, tx, a.Intent.ID, authorityCurrentPrefix); err != nil {
			return AdapterResult{}, err
		}
	}
	if !a.Allowed && c.Disposition != "grant_denied" && c.Disposition != "source_denied" {
		return r, ErrConflict
	}
	values, d := effects.Result(a.Prepared.Request.Output.Record, c)
	r = AdapterResult{Candidate: effects.Copy(c), Values: values, Disposition: d}
	r.Digest = adapterResultDigest(r)
	if e = validateAdapterResult(a, r, s.limits); e != nil {
		return r, e
	}
	b, e := json.Marshal(r)
	if e != nil {
		return r, e
	}
	var prior []byte
	e = tx.QueryRowContext(ctx, "SELECT descriptor FROM adapter_results WHERE intent_id=?", a.Intent.ID).Scan(&prior)
	if e == nil {
		if bytes.Equal(prior, b) {
			return r, s.commitOwnedTx(ctx, tx)
		}
		if !a.Allowed || a.Intent.Target == receiptReadCapability || r.Disposition != "validated" {
			return r, ErrConflict
		}
		var winner AdapterResult
		if decode(prior, &winner) != nil || !sameJSON(prior, winner) {
			return r, corrupt("invalid first adapter result")
		}
		if e = validateAdapterResult(a, winner, s.limits); e != nil {
			return r, e
		}
		if winner.Read != nil || winner.Reconciled != nil || winner.RefusalWitness != "" {
			return r, ErrConflict
		}
		// A failed first interaction stays selectable. A later successful
		// receipt can still establish application for this allowed original.
		return r, s.commitReceiptConflict(ctx, tx, a.Intent.ID, prior, b)
	}
	if !errors.Is(e, sql.ErrNoRows) {
		return r, e
	}
	if _, e = tx.ExecContext(ctx, "INSERT INTO adapter_results VALUES(?,?)", a.Intent.ID, b); e != nil {
		return r, e
	}
	if e = s.recordCompositionSource(ctx, tx, compositionExternalResultFact, a.Intent.ID); e != nil {
		return r, e
	}
	return r, s.commitOwnedTx(ctx, tx)
}
func adapterDescriptor(a AdapterAttempt, r AdapterResult) AdmissionDescriptor {
	i := a.Intent
	return AdmissionDescriptor{TransportID: identity("adapter-delivery", i.ID), Kind: "adapter", LogicalID: i.ID, Source: RunID{i.Target, 1}, Target: i.Run.Subject, Generation: i.Run.Generation, Obligation: i.Obligation, Operation: i.ID, Payload: r.Values, IntentID: i.ID}
}
func (s *Store) settleAdapter(ctx context.Context, a AdapterAttempt, r AdapterResult) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.settleAdapterLocked(ctx, a, r)
}

func (s *Store) settleAdapterLocked(ctx context.Context, a AdapterAttempt, r AdapterResult) error {
	if s.closed {
		return sql.ErrConnDone
	}
	tx, e := beginOwnedTx(ctx, s.conn)
	if e != nil {
		return e
	}
	defer tx.Rollback()
	retained, e := loadAdapterResult(ctx, tx, a.Intent.ID)
	if e != nil {
		return e
	}
	if !reflect.DeepEqual(retained, r) {
		return ErrConflict
	}
	old, e := loadAdapterAttempt(ctx, tx, a.Intent.ID)
	if e != nil {
		return e
	}
	if !reflect.DeepEqual(old, a) {
		return ErrConflict
	}
	d := adapterDescriptor(a, r)
	prior, _, e := loadAdmission(ctx, tx, "adapter", d.TransportID)
	if e == nil {
		if !reflect.DeepEqual(prior, d) {
			return ErrConflict
		}
		return s.commitOwnedTx(ctx, tx)
	}
	if !errors.Is(e, sql.ErrNoRows) {
		return e
	}
	bound := a.Intent.Run
	o := observationFor(d, bound)
	if e = insertObservation(ctx, tx, o, s.limits); e != nil {
		return e
	}
	result := AdmissionResult{TransportID: d.TransportID, Accepted: true, Reason: "settled", Bound: &bound, ObservationID: o.ID}
	raw, _ := json.Marshal(d)
	rr, _ := json.Marshal(result)
	if _, e = tx.ExecContext(ctx, "INSERT INTO admissions VALUES(?,?,?,?,?,?)", admissionKey("adapter", d.TransportID), "adapter", d.TransportID, raw, rr, o.ID); e != nil {
		return e
	}
	raw, _ = json.Marshal(r)
	if _, e = tx.ExecContext(ctx, "INSERT INTO settlements VALUES(?,?,?,?)", identity("adapter-outcome", a.Intent.ID), a.Intent.ID, raw, o.ID); e != nil {
		return e
	}
	return s.commitOwnedTx(ctx, tx)
}
func validateAdapterAttempt(ctx context.Context, q queryer, a AdapterAttempt, namespace string, l Limits) error {
	r, i, e := adapterRequest(ctx, q, a.Intent.ID, namespace, l)
	if e != nil {
		return e
	}
	auth, e := loadAuthorization(ctx, q, a.Intent.ID)
	if e != nil {
		return e
	}
	grant, e := adapterGrant(ctx, q, i)
	if e != nil {
		return e
	}
	reason := auth.Reason
	if auth.Allowed && !grant {
		reason = "grant_denied"
	}
	w, e := retainedEffectAuthority(ctx, q, i, a.Authority)
	if e != nil {
		return e
	}
	if w != nil {
		grant = w.Allowed
		reason = auth.Reason
		if auth.Allowed && !grant {
			reason = w.Reason
		}
	}
	allowed, reason, e := retainedCompositionReservation(ctx, q, i.Intent, auth.Allowed && grant, reason)
	if e != nil {
		return e
	}
	if !reflect.DeepEqual(r, a.Prepared.Request) || !reflect.DeepEqual(i.Intent, a.Intent) || a.AuthorizationID != auth.ID || a.Allowed != allowed || a.Reason != reason || a.Prepared.Digest == "" || effects.CheckPrepared(a.Prepared) != nil || a.Prepared.MaxResponseBytes > l.MaxObservationBytes/8 {
		return corrupt("adapter attempt binding")
	}
	return nil
}
func validateAdapterResult(a AdapterAttempt, r AdapterResult, l Limits) error {
	if r.RefusalWitness != "" && (a.Intent.Target != receiptReadCapability || r.Read != nil || r.Reconciled != nil || (r.Disposition != "original_busy" && r.Disposition != "original_unsettled")) {
		return corrupt("misplaced read refusal witness")
	}
	if r.Digest == "" || r.Digest != adapterResultDigest(r) {
		return corrupt("adapter result digest")
	}
	if r.Reconciled != nil {
		if r.Read != nil || !a.Allowed || !reflect.DeepEqual(r.Candidate, effects.Candidate{}) || r.Reconciled.Target != a.Intent.ID || r.Disposition != "validated" || publicschema.ValidateResult(a.Prepared.Request.Output.Record, r.Values) != nil {
			return corrupt("reconciled result envelope")
		}
		return checkSize(r, l.MaxObservationBytes)
	}
	c := r.Candidate
	if c.ID != a.Intent.ID || c.Key != a.Prepared.Request.Key || c.Disposition == "" || c.Disposition == "unknown" {
		return corrupt("adapter result correlation")
	}
	if len(c.Response) > a.Prepared.MaxResponseBytes || len(c.RequestID) > 512 || len(c.ResponseID) > 512 || len(c.ReturnedModel) > 512 {
		return corrupt("adapter response bounds")
	}
	if !a.Allowed {
		expected := "source_denied"
		if a.Reason == "grant_denied" || a.Authority != nil && !a.Authority.Allowed {
			expected = "grant_denied"
		}
		// No adapter ran. Only the synthetic denial made by the runtime can
		// explain this result; even an HTTP status would claim a contact.
		want := effects.Candidate{ID: a.Intent.ID, Key: a.Prepared.Request.Key, Disposition: expected}
		if !reflect.DeepEqual(c, want) || r.Read != nil || r.RefusalWitness != "" {
			return corrupt("denied adapter result")
		}
	}
	values, d := effects.Result(a.Prepared.Request.Output.Record, c)
	if r.Read != nil && d == "validated" {
		values["adoption"] = Text(r.Read.Adoption)
		values["adopted"] = publicschema.Bool(r.Read.Adoption == "adopted")
	}
	if d != r.Disposition || !reflect.DeepEqual(values, r.Values) || publicschema.ValidateResult(a.Prepared.Request.Output.Record, r.Values) != nil {
		return corrupt("adapter result validation")
	}
	return checkSize(r, l.MaxObservationBytes)
}
func validateAdapters(ctx context.Context, q queryer, l Limits) error {
	if _, e := readAssets(ctx, q); e != nil {
		return e
	}
	namespace, e := readNamespace(ctx, q)
	if e != nil {
		return e
	}
	ids, e := stringList(ctx, q, "SELECT intent_id FROM adapter_attempts ORDER BY intent_id")
	if e != nil {
		return e
	}
	for _, id := range ids {
		a, e := loadAdapterAttempt(ctx, q, id)
		if e != nil {
			return e
		}
		if e = validateAdapterAttempt(ctx, q, a, namespace, l); e != nil {
			return e
		}
		r, e := loadAdapterResult(ctx, q, id)
		if errors.Is(e, sql.ErrNoRows) {
			continue
		}
		if e != nil {
			return e
		}
		if e = validateAdapterResult(a, r, l); e != nil {
			return e
		}
		if r.Read != nil || r.Reconciled != nil {
			version, err := schemaNumber(ctx, q)
			if err != nil {
				return err
			}
			if version != reconciliationSchemaVersion {
				return corrupt("receipt proof in legacy schema")
			}
		}
	}
	if e = validateReceiptLedger(ctx, q, namespace, ids); e != nil {
		return e
	}
	return validateAdapterEdges(ctx, q, l)
}

func validateAdapterEdges(ctx context.Context, q queryer, l Limits) error {
	verifiedObservations := map[string]int{}
	for _, query := range []string{
		"SELECT count(*) FROM adapter_results r LEFT JOIN adapter_attempts a ON a.intent_id=r.intent_id WHERE a.intent_id IS NULL",
		"SELECT count(*) FROM adapter_attempts a LEFT JOIN intents i ON i.id=a.intent_id WHERE i.id IS NULL",
	} {
		var n int
		if e := q.QueryRowContext(ctx, query).Scan(&n); e != nil {
			return e
		}
		if n != 0 {
			return corrupt("orphan adapter record")
		}
	}
	ids, e := stringList(ctx, q, "SELECT id FROM admissions WHERE domain='adapter' ORDER BY id")
	if e != nil {
		return e
	}
	for _, id := range ids {
		var raw, resultRaw []byte
		var transport, observation string
		if e = q.QueryRowContext(ctx, "SELECT transport_id,descriptor,result,observation_id FROM admissions WHERE id=?", id).Scan(&transport, &raw, &resultRaw, &observation); e != nil {
			return e
		}
		var d AdmissionDescriptor
		var admitted AdmissionResult
		if decode(raw, &d) != nil || decode(resultRaw, &admitted) != nil {
			return corrupt("adapter admission encoding")
		}
		a, e := loadAdapterAttempt(ctx, q, d.IntentID)
		if e != nil {
			return e
		}
		r, e := loadAdapterResult(ctx, q, d.IntentID)
		if e != nil {
			return e
		}
		expected := adapterDescriptor(a, r)
		bound := a.Intent.Run
		o := observationFor(expected, bound)
		expectedAdmission := AdmissionResult{TransportID: expected.TransportID, Accepted: true, Reason: "settled", Bound: &bound, ObservationID: o.ID}
		if id != admissionKey("adapter", expected.TransportID) || transport != expected.TransportID || observation != o.ID || !sameJSON(raw, expected) || !sameJSON(resultRaw, expectedAdmission) {
			return corrupt("adapter admission identity")
		}
		var retained []byte
		if e = q.QueryRowContext(ctx, "SELECT descriptor FROM observations WHERE id=?", o.ID).Scan(&retained); e != nil {
			return e
		}
		if !sameJSON(retained, o) {
			return corrupt("adapter observation binding")
		}
		var settled []byte
		var linked string
		if e = q.QueryRowContext(ctx, "SELECT descriptor,observation_id FROM settlements WHERE id=? AND intent_id=?", identity("adapter-outcome", d.IntentID), d.IntentID).Scan(&settled, &linked); e != nil {
			return e
		}
		if linked != o.ID || !sameJSON(settled, r) {
			return corrupt("adapter settlement binding")
		}
		verifiedObservations[o.ID]++
	}
	ids, e = stringList(ctx, q, "SELECT id FROM settlements ORDER BY id")
	if e != nil {
		return e
	}
	for _, id := range ids {
		var intent, observation string
		if e = q.QueryRowContext(ctx, "SELECT intent_id,observation_id FROM settlements WHERE id=?", id).Scan(&intent, &observation); e != nil {
			return e
		}
		i, e := loadIntent(ctx, q, intent)
		if e != nil {
			return e
		}
		if i.Kind != "adapter" {
			continue
		}
		if id != identity("adapter-outcome", intent) {
			return corrupt("adapter settlement identity")
		}
		var n int
		if e = q.QueryRowContext(ctx, "SELECT count(*) FROM admissions WHERE domain='adapter' AND observation_id=?", observation).Scan(&n); e != nil {
			return e
		}
		if n != 1 {
			return corrupt("adapter settlement without admission")
		}
	}
	// Forward links alone cannot explain an observation after both ledger edges
	// have been deleted. Reading descriptors is reducer-free and preserves the
	// valid known-result/no-observation state before settlement.
	observations, e := readObservations(ctx, q, l)
	if e != nil {
		return e
	}
	for id, observation := range observations {
		if observation.Provenance == "runtime-adapter" && verifiedObservations[id] != 1 {
			return corrupt("unexplained authenticated adapter observation")
		}
	}
	return nil
}

func adapterResultDigest(r AdapterResult) string {
	r.Digest = ""
	b, _ := json.Marshal(r)
	sum := sha256.Sum256(b)
	return hex.EncodeToString(sum[:])
}
